## Task A5 – Protect Data Integrity (4 marks, K4 – Analyse)

### A5.1 – Design a transaction (2 marks)

**Problem.** Transfer ₹500 from a student's hostel wallet to the canteen wallet using two `UPDATE` statements. If the program stops after the first `UPDATE`, the money has left one wallet and never reached the other.

![Figure 6 – Transfer inside one transaction: both updates become permanent together or not at all](../report/figures/d_a5_tx.png){width=58%}


```text
ALGORITHM Transfer
INPUT : regNo, amount
OUTPUT: true if the transfer was done, false if refused
BEGIN
  1. SET auto-commit OFF                                  // begin a transaction
  2. TRY
  3.     rows ← EXECUTE  UPDATE hostel_wallet SET balance = balance − amount
  4.                     WHERE reg_no = regNo AND balance ≥ amount
  5.     IF rows ≠ 1 THEN ROLLBACK; RETURN false END IF   // insufficient funds or unknown account
  6.     rows ← EXECUTE  UPDATE canteen_wallet SET balance = balance + amount WHERE reg_no = regNo
  7.     IF rows ≠ 1 THEN ROLLBACK; RETURN false END IF
  8.     COMMIT                                             // both changes become permanent together
  9.     RETURN true
 10. CATCH any exception
 11.     ROLLBACK                                           // neither change remains
 12.     RE-THROW the exception
 13. FINALLY
 14.     RESTORE the previous auto-commit setting
END
```

* **Atomicity:** `COMMIT` makes both updates permanent; `ROLLBACK` undoes both. Nothing in between is visible after a failure.
* **Check and update in one statement.** `balance ≥ amount` is inside the `UPDATE`, so two simultaneous transfers cannot both pass a separate "check then update" test – the database locks the row while the update runs.
* **Isolation:** the transaction holds its row locks until `COMMIT` or `ROLLBACK` (the default level of MySQL/InnoDB is REPEATABLE READ).

The behaviour is demonstrated by running programs in Task B3.3.

### A5.2 – Analyse an injection vulnerability (2 marks)

**The vulnerable code.**

```text
sql ← "SELECT * FROM users WHERE id='" + id + "' AND pwd='" + pwd + "'"
EXECUTE sql
```

**Example input and the SQL that results** (real output of Task B2):

| Input | SQL text sent to the database | Effect |
|:---|:---|:---|
| `id = admin'#`, `pwd = anything` | `SELECT * FROM users WHERE id='admin'#' AND pwd='anything'` | `#` starts a comment, so the password test disappears: logged in as admin without a password |
| `id = nobody`, `pwd = ' OR '1'='1` | `SELECT * FROM users WHERE id='nobody' AND pwd='' OR '1'='1'` | `AND` binds tighter than `OR`, so the condition is `(…) OR true`: **every row** is returned |

**Why it works.** The user's text is pasted into the *program text of the query*. The quote character the attacker types closes the string literal, and whatever follows is parsed as SQL code. Data has become code.

**Redesign.**

```text
ALGORITHM Login
INPUT : id, pwd
OUTPUT: true if exactly one matching user
BEGIN
  1. statement ← PREPARE "SELECT * FROM users WHERE id = ? AND pwd = ?"      // the SQL text is fixed
  2. SET parameter 1 of statement to id                                       // sent as data
  3. SET parameter 2 of statement to pwd
  4. rows ← EXECUTE statement
  5. RETURN (rows contains one user)
END
```

The structure of the query is fixed before any input is seen; the bound values are always treated as **literal values**, never as SQL, so `' OR '1'='1` is just a password that matches nobody. Further measures: store a salted hash of the password (never the password), connect with a database user that has only the rights the program needs, and never show raw SQL errors to the user.

### Alternative Concept and Complexity Analysis – two separate auto-commit statements

```text
ALGORITHM TransferAutoCommit
BEGIN
  1. EXECUTE UPDATE hostel_wallet  SET balance = balance − amount ...      // committed immediately
  2. EXECUTE UPDATE canteen_wallet SET balance = balance + amount ...      // committed immediately
END
```

| | One transaction | Two auto-commit statements |
|:---|:---|:---|
| Failure between the updates | rollback: balances unchanged | ₹`amount` has vanished (shown in B3.3) |
| Commits (log flushes to disk) | **1** | **2** |
| Time per transfer | O(1): two updates + one commit | O(1): two updates + two commits |
| Locks | held until commit – a few more microseconds | released after each statement |
| Error handling code | `try / catch / finally` with `rollback` | none – and no protection |

Both are **O(1)** in time and space, but the transaction is not slower: one commit is cheaper than two. In Task B3.3 the measured cost is 0.246 ms per transfer in a transaction against 0.330 ms with auto-commit (5,000 transfers each). Auto-commit saves nothing and removes the safety.

**Evidence expected – covered:** a transaction design with commit/rollback (A5.1) and an injection analysis with a PreparedStatement redesign (A5.2).
