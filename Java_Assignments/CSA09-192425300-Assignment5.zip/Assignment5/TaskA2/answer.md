## Task A2 – Don't Read What You Don't Need (5 marks, K4 – Analyse)

**Problem.** A program reads a 50 MB attendance log one byte at a time with `FileInputStream.read()` to count its lines.

### A2.1 – Predict the cost (2 marks)

**Number of calls.** 50 MB = 50 × 1,048,576 = 52,428,800 bytes. The program makes one `read()` call per byte and one final call that returns −1:

> **calls = 52,428,800 + 1 = 52,428,801**

**Why it is slow.** `FileInputStream.read()` is not a memory access: every call enters native code and asks the operating system for one byte (a system call – a switch from user mode to kernel mode, a lookup in the kernel's file cache, a copy of a single byte and a switch back). The useful work done with the byte – compare it with `'\n'` and add one – costs a fraction of a nanosecond; the system call costs hundreds of times more. The running time is therefore

> **time ≈ number of calls × cost of one call**

and is dominated by the cost of crossing into the kernel, not by the disk (after the first pass the file is in the operating-system cache anyway).

**Prediction.** If one call costs between 0.2 µs and 1 µs on an ordinary computer, the prediction is **about 10 to 50 seconds** for the 50 MB file, and the time grows in direct proportion to the file size (10 times larger file → about 10 times longer). Task B1.3 compares this prediction with measurements.

### A2.2 – Redesign using buffering (2 marks)

Read a large block into a byte array with one call, then scan the array in memory:

```text
ALGORITHM CountLinesBuffered
INPUT : file F, buffer size B (for example 65,536 bytes)
OUTPUT: number of lines
BEGIN
  1. lines ← 0; last ← '\n'; buffer ← array of B bytes
  2. OPEN F
  3. REPEAT
  4.     n ← READ up to B bytes into buffer           // ONE operating-system call per block
  5.     FOR i ← 0 TO n − 1 DO
  6.         IF buffer[i] = '\n' THEN lines ← lines + 1 END IF
  7.     END FOR
  8.     IF n > 0 THEN last ← buffer[n − 1] END IF
  9. UNTIL n = −1
 10. IF last ≠ '\n' THEN lines ← lines + 1 END IF        // final line without a line break
 11. CLOSE F
 12. RETURN lines
END
```

`BufferedInputStream` (default 8 KiB buffer) or `BufferedReader` give the same effect behind a more convenient API. The scanning work (52 million comparisons) is unchanged; what changes is the **number of calls to the operating system**:

| Design | Calls to the operating system for 50 MB |
|:---|--:|
| unbuffered `read()` | 52,428,801 |
| 8 KiB buffer (`BufferedInputStream`, `byte[8192]`) | 52,428,800 ÷ 8,192 = **6,400** (+1) |
| 64 KiB buffer | 52,428,800 ÷ 65,536 = **800** (+1) |

![Figure 1 – Unbuffered reading calls the operating system once per byte; a buffer calls it once per block](../report/figures/d_a2_buffer.png){width=88%}


### A2.3 – When buffering does not help (1 mark)

Buffering gives almost nothing when **the program already reads in large blocks.** `BufferedInputStream` hands a request that is as large as its own buffer straight to the underlying stream, so wrapping a loop that already calls `read(byte[65536])` in another buffer only adds a copy. A second case: **random access.** If a program seeks to a record and reads 92 bytes, a buffer would read thousands of bytes it never uses and throw them away at the next seek – the fixed-length design of Task A1 reads with `RandomAccessFile` directly for this reason.

### Alternative Concept and Complexity Analysis – `Files.readAllLines()`

**Solution.** Read the whole file into a `List<String>` and use its size:

```text
ALGORITHM CountLinesReadAll
INPUT : file F
OUTPUT: number of lines
BEGIN
  1. lines ← READ ALL lines of F into a list                // every line becomes a String object
  2. RETURN size of lines
END
```

| | Buffered stream / block reading | `Files.readAllLines()` |
|:---|:---|:---|
| Time | **O(file size)** – each byte is examined once | **O(file size)** – each byte is read, decoded and copied once, plus one `String` object per line |
| Memory | **O(buffer size)** – a constant 8 KiB to 64 KiB, whatever the file size | **O(file size)** – all lines are alive at the same time; a `String` carries object overhead, so memory is *larger* than the file |
| Code | a loop | one line |
| Appropriate when | the file is large or of unknown size, or the data is processed once as it streams past | the file is small (a few MB), and the program needs *all* lines at once (sorting, random access by line number) |

The measurements for the 50 MB file are in Task B1.3: the block-reading version allocates about 0.100 MB in total, while `readAllLines()` allocates about 95.5 MB – **1.9 times the file size** – and needs a Java heap of at least that size. A file that does not fit in the heap would stop `readAllLines()` with an `OutOfMemoryError`, whereas the streaming version would still run.

**Evidence expected – covered:** a reasoned prediction (A2.1), a redesigned read strategy (A2.2) and a justified limitation (A2.3).
