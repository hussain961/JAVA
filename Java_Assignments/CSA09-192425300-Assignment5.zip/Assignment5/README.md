# CSA09 – Programming in Java · Assignment 5 (CO5) – Data Persistence Engineering

**Student:** D.HUSSAINAIAH  **Register number:** 192425300  **Programme:** B.Tech AIML

One running example – the **university transport office bus-pass records** – is used to decide *where* and *how* Java data should be stored:
a delimited text file with its own integrity check (Part B1), JDBC with `Statement`, `PreparedStatement` and batches (B3), attacks on both (B2), and a measured decision between files, serialization and a database for 12 campuses (B4).

## What is in the repository

| Folder | Contents |
|:---|:---|
| `TaskA1` … `TaskA5` | `answer.md` – Part A design, pseudocode, diagrams, reasoning (identical text to the report). `experiments/` holds the small programs that *measure* a design claim. |
| `TaskB1` | `PassStore.java` (**Complete the Code**), `BusPassFileStore.java` (the A1 design), `PassStoreTest`, `LineCounter`, `BuffBench`, `GrowthBench` |
| `TaskB2` | `LoginDemo` (SQL injection), `BadFileDemo` (damaged files), `EscapingWeakness` |
| `TaskB3` | `PassLoader.java` (**Complete the Code**), `SmallCorrectness`, `LoadBench`, `TransactionDemo`, `InsertStrategies` |
| `TaskB4` | `GenerateMigrationData`, `Migrate`, `DbInfo`, `ConcurrencyDemo`, `ScaleDecision` |
| `common` | `Db` (connection settings), `Bench` (timing/CSV helper), `PassData` (deterministic test data) |
| `db` | `setup_mysql_user.sql` (test database + user), `schema.sql` (tables) |
| `results` | console outputs (`outputs/*.txt`), measurements (`*.csv`), migration report |
| `report` | the assignment report (`Assignment5_Report.docx`), its source parts and figures |
| `tools` | chart, diagram and report builders |
| `VIVA_NOTES.md`, `COMMIT_PLAN.md` | preparation for the viva, suggested commit sequence |

## Requirements

* **JDK 17 or later** (tested with JDK 21) – `javac --release 17`
* **MySQL 8** server on `localhost:3306` (MariaDB also works) and the **MySQL Connector/J** jar in `lib/` (see `lib/README.txt`)
* Optional for the report: Python 3 with `matplotlib` and `python-docx`, `pandoc`, Graphviz

## Setup (once)

```bash
mysql -u root -p < db/setup_mysql_user.sql                      # creates database transport_test and the test user
mysql -u transport -ptransport123 transport_test < db/schema.sql  # creates the tables (re-run any time to reset)
```

The database `transport_test` and its user exist **only for this assignment**; the passwords inside it are made-up test data.
Connection settings can be changed with the environment variables `DB_URL`, `DB_USER`, `DB_PASS` (defaults are in `common/Db.java`).
Default URL: `jdbc:mysql://localhost:3306/transport_test?rewriteBatchedStatements=true` – the option `rewriteBatchedStatements=true` is what makes JDBC batches fast with MySQL Connector/J.

## Run everything

```bash
./run_all.sh          # about 4 minutes; saves outputs to results/outputs and measurements to results/*.csv
./run_all.sh quick    # skips the slowest measurements (50 MB file, 100,000 rows, 800,000 passes)
```

Windows (without Git Bash), one task at a time:

```bat
mkdir out
javac --release 17 -d out -cp "lib\*" common\*.java TaskB1\*.java TaskB2\*.java TaskB3\*.java TaskB4\*.java TaskA1\experiments\*.java TaskA4\experiments\*.java
java -cp "out;lib\*" PassStore
java -cp "out;lib\*" PassStoreTest
java -cp "out;lib\*" LoginDemo
```

Every program is named in the table at the top of its `TaskB*/README.md`.

## Your own evidence (important)

* The numbers in `results/` and in the report were produced on the **reference machine** described in `results/env.txt`.
  **Run `./run_all.sh` on your own computer**, then regenerate the charts and the report:
  ```bash
  python3 tools/make_charts.py
  python3 tools/build_report.py        # writes report/Assignment5_Report.docx with YOUR measurements
  ```
* Take your own screenshots of each program running on your computer and save them in `screenshots/` (for example `B1_3_buffering.png`). A screenshot that shows only a final success message is not enough – show the command *and* the output tables.
* Commit as you go (see `COMMIT_PLAN.md`) – the commit history is part of the evidence.

## Notes on the experiments

* All attacks (SQL injection, damaged files) run against the local test database and local test files only.
* The stacked-statement injection test (`LoginDemo`, case 7) really executes `DROP TABLE users` when `allowMultiQueries=true`; the program re-creates the test table afterwards, and `db/schema.sql` resets everything.
* `LOAD DATA LOCAL INFILE` (in `InsertStrategies`) needs `local_infile=1` on the server and the connection; if it is not enabled the program reports "NOT AVAILABLE" and continues.
