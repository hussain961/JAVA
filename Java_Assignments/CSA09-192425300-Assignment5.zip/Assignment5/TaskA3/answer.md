## Task A3 – Discover the Data-Access Design Pattern (5 marks, K4 – Analyse)

**Problem.** `StudentDB`, `CourseDB` and `MarksDB` each open a connection, build an SQL string, execute it, read the `ResultSet` into objects and close the connection. Large parts of the three classes are almost identical.

### A3.1 – Identify the common pattern (2 marks)

![Figure 2 – The six steps repeated in every data-access class (green = identical in all three, yellow = differs per class)](../report/figures/d_a3_steps.png){width=88%}


| Step | Repeated in all three? | What differs |
|:---|:---|:---|
| 1. Open the connection | identical | – |
| 2. Build the SQL text | structure identical | the **table name, column names and the `WHERE` clause** |
| 3. Create the statement and bind values | identical idea | **which fields** are bound and in which order |
| 4. Execute | identical | – |
| 5. Read the `ResultSet` into objects | identical loop | **how one row becomes an object** (`Student`, `Course` or `Marks`) |
| 6. Close resources, handle `SQLException` | identical | – |

The pattern is the **Data Access Object (DAO)** with a *template method*: the invariant skeleton (steps 1, 4, 6 and the loop of step 5) is written once; only the parts in yellow (SQL text, parameter binding, row mapping) are supplied by each entity.

### A3.2 – Design a generic data-access interface (2 marks)

![Figure 3 – Generic Dao<T, K> with a shared JdbcDao skeleton and one small class per table](../report/figures/d_a3_dao.png){width=88%}


```text
INTERFACE Dao<T, K>                      // T = entity type, K = primary-key type
  insert(T entity)            : void
  findById(K id)              : Optional<T>
  findAll()                   : List<T>
  update(T entity)            : boolean    // true if exactly one row changed
  delete(K id)                : boolean
END INTERFACE
```

```text
ALGORITHM JdbcDao.findById          // written ONCE for every entity
INPUT : id
OUTPUT: the entity, or empty
BEGIN
  1. OPEN connection                                         // try-with-resources: closed automatically
  2. statement ← PREPARE(sqlFindById())                      // supplied by the subclass
  3. SET parameter 1 of statement to id
  4. resultSet ← EXECUTE statement
  5. IF resultSet has a row THEN RETURN Optional(map(resultSet)) // map() supplied by the subclass
  6. RETURN empty
  7. ON SQLException: wrap in an unchecked DataAccessException and rethrow
END
```

**`StudentDao`** supplies only three small pieces:

```text
CLASS StudentDao EXTENDS JdbcDao<Student, String>
  sqlInsert()    ← "INSERT INTO student(reg_no, name, dept, joining_year) VALUES (?, ?, ?, ?)"
  sqlFindById()  ← "SELECT reg_no, name, dept, joining_year FROM student WHERE reg_no = ?"
  bind(statement, s)  ← set parameter 1..4 from s.regNo, s.name, s.dept, s.joiningYear
  map(resultSet)      ← RETURN new Student(rs.reg_no, rs.name, rs.dept, rs.joining_year)
END CLASS
```

`CourseDao` and `MarksDao` are written the same way. The services and the GUI depend only on `Dao<T, K>` and contain no SQL.

### A3.3 – Map objects to tables (1 mark)

| `Student` field (Java) | Column in table `student` | Column type | Constraint |
|:---|:---|:---|:---|
| `String regNo` | `reg_no` | `VARCHAR(12)` | **PRIMARY KEY** |
| `String name` | `name` | `VARCHAR(60)` | NOT NULL |
| `String dept` | `dept` | `VARCHAR(30)` | – |
| `int joiningYear` | `joining_year` | `SMALLINT` | – |

```sql
CREATE TABLE student (
    reg_no        VARCHAR(12) NOT NULL,
    name          VARCHAR(60) NOT NULL,
    dept          VARCHAR(30),
    joining_year  SMALLINT,
    PRIMARY KEY (reg_no)
);
```

One row = one `Student` object; one column = one field; the primary key identifies an object (and is the `K` of `Dao<Student, K>`). Java camelCase names become snake_case column names (`joiningYear` → `joining_year`), and `year` is avoided as a column name because it is a reserved word in SQL.

### Alternative Concept and Complexity Analysis – SQL written directly in the service or GUI classes

**Solution.** Each service or GUI class opens its own connection and writes its own SQL:

```text
ALGORITHM StudentScreen.showStudent(regNo)       // no Dao
BEGIN
  1. OPEN connection
  2. statement ← PREPARE("SELECT reg_no, name, dept FROM student WHERE reg_no = ?")
  3. ... execute, read the row, fill the screen, close ...
END
```

| | Generic `Dao<T, K>` | SQL inside service / GUI classes |
|:---|:---|:---|
| Places that change when the column `dept` is renamed to `department` | **one class** (`StudentDao`; its SQL strings and `map`) | **every class that touches `student`** – each screen, report and service that wrote its own SQL; the compiler finds none of them because the SQL is only text |
| Lines of repeated connection / close code | written once in `JdbcDao` | repeated in every class, each a chance for a leaked connection |
| Changing the database product or adding caching | one place | everywhere |
| Time per database operation | one extra method call (nanoseconds) | none |
| Space per operation | one small `Dao` object, created once and shared | none |

**Time and space.** Both designs send the *same* SQL and make the *same* round trip to the database, so the cost per operation is the same in Big-O terms: **O(1) extra time and O(1) extra space** for the indirection, while the database work (about 59.6 µs per query measured in Task B2) is thousands of times larger than a method call. The Dao design is therefore free in performance and expensive only to *write* once; its benefit is that the number of places to edit on a schema change drops from "all classes that use the table" to **one**.

**Evidence expected – covered:** the repeated pattern (A3.1), a generic data-access design with `StudentDao` (A3.2) and the object–table mapping with primary key (A3.3).
