import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 * Task B2 - the unsafe login check of Task A5.2 versus the PreparedStatement version.
 * Uses the LOCAL TEST database (table users, created by db/schema.sql). All passwords in it are made-up test data.
 */
public class LoginDemo {

    /** Exactly the unsafe check from Task A5.2: user input is pasted into the SQL text. Returns matching rows, or -1 on SQL error. */
    static int unsafeLogin(Connection con, String id, String pwd, String[] sqlOut) {
        String sql = "SELECT * FROM users WHERE id='" + id + "' AND pwd='" + pwd + "'";
        sqlOut[0] = sql;
        try (Statement st = con.createStatement(); ResultSet rs = st.executeQuery(sql)) {
            int n = 0;
            while (rs.next()) n++;
            return n;
        } catch (SQLException e) {
            sqlOut[0] += "   -> " + e.getClass().getSimpleName();
            return -1;
        }
    }

    /** The safe redesign: the SQL text is fixed, the input travels as parameters (data, never code). */
    static int safeLogin(Connection con, String id, String pwd) throws SQLException {
        try (PreparedStatement ps = con.prepareStatement("SELECT * FROM users WHERE id=? AND pwd=?")) {
            ps.setString(1, id);
            ps.setString(2, pwd);
            try (ResultSet rs = ps.executeQuery()) {
                int n = 0;
                while (rs.next()) n++;
                return n;
            }
        }
    }

    static String verdict(int rows) { return rows < 0 ? "ERROR" : rows == 0 ? "REJECT" : "ACCEPT (" + rows + " row" + (rows > 1 ? "s" : "") + ")"; }

    public static void main(String[] args) throws Exception {
        String[][] cases = {
                {"1  valid student",                  "192311001", "pass1234"},
                {"2  wrong password",                 "192311001", "wrong"},
                {"3  comment trick on id",            "admin'#", "anything"},
                {"4  always-true password",           "nobody", "' OR '1'='1"},
                {"5  always-true id",                 "' OR 1=1 #", "x"},
                {"6  UNION forges a row",             "x' UNION SELECT 'admin','x','ADMIN'#", "x"},
        };
        // allowMultiQueries=false is the normal, safe driver setting: one statement per call
        try (Connection con = Db.connectPlain("allowMultiQueries=false")) {
            System.out.println("Database: " + con.getMetaData().getDatabaseProductName() + " " + con.getMetaData().getDatabaseProductVersion()
                    + "  |  driver: " + con.getMetaData().getDriverName() + " " + con.getMetaData().getDriverVersion());
            System.out.printf("%-34s | %-22s | %-22s%n", "Input case (id / password)", "UNSAFE (concatenation)", "SAFE (PreparedStatement)");
            System.out.println("-".repeat(34) + "-+-" + "-".repeat(22) + "-+-" + "-".repeat(24));
            StringBuilder sqls = new StringBuilder();
            for (String[] c : cases) {
                String[] sql = new String[1];
                int u = unsafeLogin(con, c[1], c[2], sql);
                int s = safeLogin(con, c[1], c[2]);
                System.out.printf("%-34s | %-22s | %-22s%n", c[0], verdict(u), verdict(s));
                sqls.append(String.format("%n%s%n   id  = [%s]%n   pwd = [%s]%n   SQL = %s%n", c[0], c[1], c[2], sql[0]));
            }
            System.out.println();
            System.out.println("SQL text that the UNSAFE version really sent to the database:");
            System.out.println(sqls);
        }

        // ---- case 7: a stacked statement. Whether it works depends on the DRIVER setting allowMultiQueries.
        String stackedId = "x'; DROP TABLE users; #";
        System.out.println("7  stacked statement   id = [" + stackedId + "]   pwd = [x]");
        try (Connection con = Db.connectPlain("allowMultiQueries=false")) {
            String[] sql = new String[1];
            int r = unsafeLogin(con, stackedId, "x", sql);
            System.out.println("   allowMultiQueries=false (normal setting): " + verdict(r) + "; users table rows = " + count(con));
        }
        try (Connection con = Db.connectPlain("allowMultiQueries=true")) {
            String[] sql = new String[1];
            int r = unsafeLogin(con, stackedId, "x", sql);
            String after;
            try { after = "users table rows = " + count(con); } catch (SQLException e) { after = "users table is GONE -> " + e.getMessage().replaceAll("^\\(conn=\\d+\\) ", ""); }
            System.out.println("   allowMultiQueries=true  (setting enabled): " + verdict(r) + "; " + after);
        }
        try (Connection con = Db.connectPlain()) {              // restore the test table so later programs still work
            try (Statement st = con.createStatement()) {
                st.executeUpdate("CREATE TABLE IF NOT EXISTS users (id VARCHAR(20) NOT NULL PRIMARY KEY, pwd VARCHAR(30) NOT NULL, role VARCHAR(10) NOT NULL) ENGINE=InnoDB");
                st.executeUpdate("DELETE FROM users");
                st.executeUpdate("INSERT INTO users VALUES ('admin','Adm!n#2026','ADMIN'),('192311001','pass1234','STUDENT'),('192311002','mango77','STUDENT')");
            }
            System.out.println("   (test table re-created with " + count(con) + " rows for the next programs)");
        }
    }

    static int count(Connection con) throws SQLException {
        try (Statement st = con.createStatement(); ResultSet rs = st.executeQuery("SELECT COUNT(*) FROM users")) {
            rs.next();
            return rs.getInt(1);
        }
    }
}
