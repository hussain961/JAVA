# Task B2 – Attack your own program

All attacks target the **local test database** `transport_test` and local test files only.

| File | Purpose | Run |
|:---|:---|:---|
| `LoginDemo.java` | six injection inputs against the unsafe concatenation and the `PreparedStatement` version, plus the stacked-statement test | `java -cp "out:lib/*" LoginDemo` |
| `BadFileDemo.java` | eight damaged / hostile file inputs against `PassStore` and `BusPassFileStore` | `java -cp "out:lib/*" BadFileDemo` |
| `EscapingWeakness.java` | alternative concept: escaping / regex whitelist versus parameters, with cost measurement | `java -cp "out:lib/*" EscapingWeakness` |

Screenshots to take: the result table of `LoginDemo` (and the SQL text), the table of `BadFileDemo`.
