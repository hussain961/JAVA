import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Arrays;
import java.util.List;

/**
 * Task B2 - deliberately damaged bus-pass files. The same eight inputs are given to
 *   (a) the PassStore supplied with the assignment (comma separated, only the field count is checked), and
 *   (b) the BusPassFileStore designed in Task A1 (escaping + CRC + field validation).
 */
public class BadFileDemo {

    static String body(String id, String reg, String name, String route, String amount) {
        return String.join("|", id, reg, name, route, "Guindy", "2027-03-31", amount);
    }

    static String withCrc(String body) { return body + "|" + BusPassFileStore.crcHex(body); }

    public static void main(String[] args) throws Exception {
        // label, line in PassStore (CSV) format, line in BusPassFileStore format
        List<String[]> inputs = Arrays.asList(
                new String[] {"1  valid record",
                        "P5001,192311001,Arun,12,4500.0",
                        withCrc(body("P005001", "192311001", "Arun", "12", "4500.00"))},
                new String[] {"2  too FEW fields",
                        "P5002,192311002,Divya",
                        "P005002|192311002|Divya"},
                new String[] {"3  too MANY fields",
                        "P5003,192311003,Karthik,3,4000.0,EXTRA,MORE",
                        withCrc(body("P005003", "192311003", "Karthik", "3", "4000.00")) + "|EXTRA|MORE"},
                new String[] {"4  non-numeric amount",
                        "P5004,192311004,Meena,5,abc",
                        withCrc(body("P005004", "192311004", "Meena", "5", "abc"))},
                new String[] {"5  empty line",
                        "",
                        ""},
                new String[] {"6  negative amount",
                        "P5006,192311006,Ravi,6,-4500",
                        withCrc(body("P005006", "192311006", "Ravi", "6", "-4500.00"))},
                new String[] {"7  name contains the delimiter",
                        "P5007,192311007,Kumar, Arun,5,4000.0",
                        BusPassFileStore.encode(new BusPassFileStore.Pass("P005007", "192311007", "Kumar, Arun", 5, "Guindy",
                                java.time.LocalDate.of(2027, 3, 31), new java.math.BigDecimal("4000.00")))},
                new String[] {"8  one character changed by hand",
                        "P5008,192311008,Sneha,9,9999.0",
                        "P005008|192311008|Sneha|9|Guindy|2027-03-31|9999.00|" + BusPassFileStore.crcHex(body("P005008", "192311008", "Sneha", "9", "4200.00"))});

        Path csv = Bench.workDir().resolve("bad_csv.txt");
        Path txt = Bench.workDir().resolve("bad_txt.txt");
        StringBuilder c = new StringBuilder(), t = new StringBuilder();
        for (String[] in : inputs) { c.append(in[1]).append('\n'); t.append(in[2]).append('\n'); }
        Files.writeString(csv, c.toString(), StandardCharsets.UTF_8);
        Files.writeString(txt, t.toString(), StandardCharsets.UTF_8);

        PassStore given = new PassStore(csv);
        System.out.printf("%-34s | %-44s | %-22s%n", "Adversarial input", "PassStore (given) find() returns", "BusPassFileStore (A1 design)");
        System.out.println("-".repeat(34) + "-+-" + "-".repeat(44) + "-+-" + "-".repeat(30));
        String[] lines = Files.readAllLines(txt).toArray(new String[0]);
        for (int i = 0; i < inputs.size(); i++) {
            String[] in = inputs.get(i);
            String id = in[1].isEmpty() ? null : in[1].split(",")[0];
            String got = id == null ? "(no id to search for)" : Arrays.toString(given.find(id));
            BusPassFileStore.Result r = BusPassFileStore.decode(lines[i]);
            System.out.printf("%-34s | %-44s | %s%n", in[0], got.length() > 44 ? got.substring(0, 41) + "..." : got,
                    r.ok() ? "accepted" : "REJECTED: " + r.reason);
        }
        BusPassFileStore.ScanReport rep = new BusPassFileStore(txt).verify();
        System.out.println();
        System.out.println("BusPassFileStore.verify() of the same file: " + rep);
        System.out.println("(The record in case 7 is VALID and is accepted; PassStore loses it because its comma splits the name.)");
    }
}
