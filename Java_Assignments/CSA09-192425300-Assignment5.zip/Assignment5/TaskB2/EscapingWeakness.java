import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.List;
import java.util.regex.Pattern;

/**
 * Task B2 alternative concept - "escape the quotes" or "validate with a regular expression" instead of PreparedStatement.
 * Part 1 shows an injection that gets through BOTH defences. Part 2 measures what validation costs per query.
 * Output: results/B2_validation_cost.csv   method, operations, total_ms, per_op_us
 */
public class EscapingWeakness {

    /** The classic quote-escaping defence: double the quotes and the backslashes. */
    static String escape(String s) { return s.replace("\\", "\\\\").replace("'", "''"); }

    static final Pattern WHITELIST = Pattern.compile("[A-Za-z0-9 ]+");

    static int rows(Connection con, String sql) throws Exception {
        try (Statement st = con.createStatement(); ResultSet rs = st.executeQuery(sql)) {
            int n = 0;
            while (rs.next()) n++;
            return n;
        }
    }

    public static void main(String[] args) throws Exception {
        try (Connection con = Db.connect()) {
            // test data: 100 passes spread over routes 1..40
            try (Statement st = con.createStatement()) { st.executeUpdate("DELETE FROM bus_pass"); }
            List<String[]> data = PassData.rows(100);
            try (PreparedStatement ps = con.prepareStatement("INSERT INTO bus_pass(pass_id, reg_no, name, route_no, amount) VALUES (?,?,?,?,?)")) {
                for (String[] r : data) {
                    ps.setString(1, r[0]); ps.setString(2, r[1]); ps.setString(3, r[2]);
                    ps.setInt(4, Integer.parseInt(r[3])); ps.setBigDecimal(5, new java.math.BigDecimal(r[4]));
                    ps.addBatch();
                }
                ps.executeBatch();
            }
            int onRoute = 0;
            for (String[] r : data) if (r[3].equals("7")) onRoute++;

            // ---- Part 1: numeric context. There are no quotes to escape, so escaping does nothing.
            String normal = "7";
            String payload = "7 OR 1";                   // letters, digits and spaces only -> passes the whitelist too
            for (String input : new String[] {normal, payload}) {
                boolean passesRegex = WHITELIST.matcher(input).matches();
                String sql = "SELECT pass_id FROM bus_pass WHERE route_no = " + escape(input);
                int n = rows(con, sql);
                System.out.printf("input [%s]  whitelist regex accepts: %-5s  escaped SQL: %s%n    -> rows returned: %d%s%n",
                        input, passesRegex, sql, n, input.equals(payload) ? "   (route 7 really has " + onRoute + ") <-- INJECTION SUCCEEDED" : "");
            }
            try (PreparedStatement ps = con.prepareStatement("SELECT pass_id FROM bus_pass WHERE route_no = ?")) {
                try {
                    ps.setInt(1, Integer.parseInt(payload));
                    System.out.println("PreparedStatement with setInt(Integer.parseInt(input)) -> (unexpected) accepted");
                } catch (NumberFormatException e) {
                    System.out.println("PreparedStatement version: Integer.parseInt(\"" + payload + "\") fails -> input rejected before any SQL is built");
                }
            }

            // ---- Part 2: cost of validation per query
            Bench.resetCsv("B2_validation_cost.csv", "method,operations,total_ms,per_op_us");
            int regexOps = 1_000_000;
            long[] sink = new long[1];
            for (int i = 0; i < 200000; i++) sink[0] += WHITELIST.matcher("Arun Kumar 12").matches() ? 1 : 0;   // warm-up
            double tRegex = Bench.timeMs(() -> { for (int i = 0; i < regexOps; i++) sink[0] += WHITELIST.matcher("Arun Kumar 12").matches() ? 1 : 0; });
            report("regex validation only", regexOps, tRegex);

            int q = 5000;
            // (a) escaped + regex validated string query
            for (int i = 0; i < 300; i++) rows(con, "SELECT name FROM bus_pass WHERE pass_id = '" + escape(PassData.passId(1 + i % 100)) + "'");
            double tStr = Bench.timeMs(() -> { for (int i = 0; i < q; i++) {
                String id = PassData.passId(1 + i % 100);
                if (!WHITELIST.matcher(id).matches()) throw new IllegalStateException();
                rows(con, "SELECT name FROM bus_pass WHERE pass_id = '" + escape(id) + "'"); } });
            report("regex + escaping + Statement query", q, tStr);
            // (b) PreparedStatement, no extra validation
            double tPs;
            try (PreparedStatement ps = con.prepareStatement("SELECT name FROM bus_pass WHERE pass_id = ?")) {
                for (int i = 0; i < 300; i++) { ps.setString(1, PassData.passId(1 + i % 100)); try (ResultSet rs = ps.executeQuery()) { rs.next(); } }
                tPs = Bench.timeMs(() -> { for (int i = 0; i < q; i++) { ps.setString(1, PassData.passId(1 + i % 100)); try (ResultSet rs = ps.executeQuery()) { rs.next(); } } });
            }
            report("PreparedStatement query", q, tPs);
            System.out.println("(" + sink[0] + " regex matches counted so the JIT cannot remove the loops)");
        }
    }

    static void report(String m, int ops, double ms) {
        System.out.printf("%-40s %9d ops  %10.1f ms total  %9.3f us per operation%n", m, ops, ms, ms * 1000 / ops);
        Bench.csv("B2_validation_cost.csv", m + "," + ops + "," + String.format("%.1f,%.3f", ms, ms * 1000 / ops));
    }
}
