import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * Task B4.3 - the 12-campus scale: 100 x 8,000 = 800,000 passes.
 *   Design A: one shared text file             Design B: 12 serialized files (one per campus)
 *   Design C: one shared database table (primary key + route index)
 * Output: results/B4_3_scale.csv   design, operation, time_ms, size_mb
 * Run with a larger heap, e.g.  java -Xmx2g ScaleDecision
 */
public class ScaleDecision {
    static final int N = 800000, CAMPUSES = 12;

    static void row(String design, String op, double ms, double mb) {
        System.out.printf("%-34s | %-44s | %10.2f ms | %s%n", design, op, ms, mb < 0 ? "" : String.format("%.1f MB", mb));
        Bench.csv("B4_3_scale.csv", "\"" + design + "\",\"" + op + "\"," + String.format("%.2f", ms) + "," + (mb < 0 ? "" : String.format("%.1f", mb)));
    }

    @SuppressWarnings("unchecked")
    public static void main(String[] args) throws Exception {
        Bench.resetCsv("B4_3_scale.csv", "design,operation,time_ms,size_mb");
        List<BusPassFileStore.Pass> all = PassData.passes(N);
        Random rnd = new Random(99);

        // ---------------------------------------------------------------- A: one text file
        Path txt = Bench.workDir().resolve("scale_all.txt");
        Files.deleteIfExists(txt);
        BusPassFileStore store = new BusPassFileStore(txt);
        double tw = Bench.timeMs(() -> store.appendAll(all, false));
        double mbTxt = Files.size(txt) / 1048576.0;
        row("A. one shared text file", "write all " + N + " passes", tw, mbTxt);
        for (int i = 0; i < 3; i++) store.find(PassData.passId(N));
        double tFind = Bench.medianMs(5, () -> store.find(PassData.passId(N - 5)));
        row("A. one shared text file", "find one pass (near the end)", tFind, -1);
        double tAvg = Bench.timeMs(() -> { for (int i = 0; i < 20; i++) store.find(PassData.passId(1 + rnd.nextInt(N))); }) / 20;
        row("A. one shared text file", "find one pass (average of 20 random)", tAvg, -1);

        // ---------------------------------------------------------------- B: 12 serialized campus files
        int per = N / CAMPUSES;
        Path[] ser = new Path[CAMPUSES];
        long bytes = 0;
        double tSave = 0;
        for (int c = 0; c < CAMPUSES; c++) {
            ser[c] = Bench.workDir().resolve("campus_" + (c + 1) + ".ser");
            ArrayList<BusPassFileStore.Pass> part = new ArrayList<>(all.subList(c * per, c == CAMPUSES - 1 ? N : (c + 1) * per));   // last campus takes the remainder
            final Path f = ser[c];
            tSave += Bench.timeMs(() -> { try (ObjectOutputStream o = new ObjectOutputStream(new BufferedOutputStream(Files.newOutputStream(f)))) { o.writeObject(part); } });
            bytes += Files.size(f);
        }
        row("B. 12 serialized campus files", "save 12 files (about 66,667 passes each)", tSave, bytes / 1048576.0);
        // search one pass without knowing its campus: load file after file until found (worst case: last campus)
        String target = PassData.passId(N - 3);
        double tSearchAll = Bench.timeMs(() -> {
            boolean found = false;
            for (int c = 0; c < CAMPUSES && !found; c++) {
                try (ObjectInputStream in = new ObjectInputStream(new BufferedInputStream(Files.newInputStream(ser[c])))) {
                    for (BusPassFileStore.Pass p : (ArrayList<BusPassFileStore.Pass>) in.readObject()) if (p.passId().equals(target)) { found = true; break; }
                }
            }
            if (!found) throw new IllegalStateException("not found");
        });
        row("B. 12 serialized campus files", "find one pass, campus unknown (worst case)", tSearchAll, -1);
        double tOne = Bench.timeMs(() -> { try (ObjectInputStream in = new ObjectInputStream(new BufferedInputStream(Files.newInputStream(ser[CAMPUSES - 1])))) { in.readObject(); } });
        row("B. 12 serialized campus files", "load ONE campus file (campus known)", tOne, -1);

        // ---------------------------------------------------------------- C: database
        try (Connection con = Db.connect(); Statement st = con.createStatement()) {
            st.executeUpdate("DROP TABLE IF EXISTS bus_pass_scale");
            st.executeUpdate("CREATE TABLE bus_pass_scale LIKE bus_pass");
            double tLoad = Bench.timeMs(() -> {
                con.setAutoCommit(false);
                try (PreparedStatement ps = con.prepareStatement("INSERT INTO bus_pass_scale(pass_id, reg_no, name, route_no, boarding_stop, valid_until, amount) VALUES (?,?,?,?,?,?,?)")) {
                    int n = 0;
                    for (BusPassFileStore.Pass p : all) {
                        ps.setString(1, p.passId()); ps.setString(2, p.regNo()); ps.setString(3, p.name()); ps.setInt(4, p.route());
                        ps.setString(5, p.stop()); ps.setDate(6, java.sql.Date.valueOf(p.validUntil())); ps.setBigDecimal(7, p.amount());
                        ps.addBatch();
                        if (++n % 1000 == 0) ps.executeBatch();
                    }
                    ps.executeBatch();
                    con.commit();
                } finally { con.setAutoCommit(true); }
            });
            st.execute("ANALYZE TABLE bus_pass_scale");          // refresh the table statistics so that the size is reported correctly
            double mbDb;
            try (ResultSet rs = st.executeQuery("SELECT (data_length + index_length) / 1048576 FROM information_schema.tables "
                    + "WHERE table_schema = DATABASE() AND table_name = 'bus_pass_scale'")) { rs.next(); mbDb = rs.getDouble(1); }
            row("C. shared database table", "load all " + N + " passes (1 transaction, batches of 1,000)", tLoad, mbDb);
            int q = 20000;
            String[] ids = new String[q];
            for (int i = 0; i < q; i++) ids[i] = PassData.passId(1 + rnd.nextInt(N));
            try (PreparedStatement ps = con.prepareStatement("SELECT name FROM bus_pass_scale WHERE pass_id = ?")) {
                for (int i = 0; i < 2000; i++) { ps.setString(1, ids[i]); try (ResultSet rs = ps.executeQuery()) { rs.next(); } }
                double t = Bench.timeMs(() -> { for (String id : ids) { ps.setString(1, id); try (ResultSet rs = ps.executeQuery()) { if (!rs.next()) throw new IllegalStateException(id); } } });
                row("C. shared database table", "find one pass by primary key (average of " + q + ")", t / q, -1);
            }
            try (PreparedStatement ps = con.prepareStatement("SELECT COUNT(*) FROM bus_pass_scale WHERE route_no = ?")) {
                double t = Bench.timeMs(() -> { for (int i = 1; i <= 40; i++) { ps.setInt(1, i); try (ResultSet rs = ps.executeQuery()) { rs.next(); } } }) / 40;
                row("C. shared database table", "count passes on one route (indexed, average of 40)", t, -1);
            }
            double tl = Bench.timeMs(() -> store.listByRoute(7));
            row("A. one shared text file", "list passes on one route (full scan)", tl, -1);
            st.executeUpdate("DROP TABLE bus_pass_scale");
        }
    }
}
