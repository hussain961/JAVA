# Task B4 – Migrate and decide

| File | Purpose | Run |
|:---|:---|:---|
| `GenerateMigrationData.java` | 100,000-pass text file with exactly 100 injected defects | `java -cp "out:lib/*" GenerateMigrationData` |
| `Migrate.java` | B4.1 – validate, batch-load in one transaction, report rejected lines (`results/B4_1_migration_report.txt`) | `java -cp "out:lib/*" Migrate` |
| `DbInfo.java` | B4.2 – `DatabaseMetaData` report | `java -cp "out:lib/*" DbInfo` |
| `ConcurrencyDemo.java` | B4.3 – 8 counters issuing the same 250 passes: file without lock / with lock / database | `java -cp "out:lib/*" ConcurrencyDemo` |
| `ScaleDecision.java` | B4.3 – 800,000 passes: text file vs 12 serialized files vs database | `java -Xmx2g -cp "out:lib/*" ScaleDecision` |

Screenshots to take: Migrate summary, DbInfo, ConcurrencyDemo table, ScaleDecision table.
