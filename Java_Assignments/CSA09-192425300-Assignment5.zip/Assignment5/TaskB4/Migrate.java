import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.math.BigDecimal;
import java.nio.charset.CodingErrorAction;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.EnumMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

/**
 * Task B4.1 - migrates the bus-pass text file into the bus_pass table.
 *   - every line is validated with BusPassFileStore.decode (fields, CRC, formats)
 *   - duplicate pass ids inside the file are rejected
 *   - valid rows are loaded in batches of 1,000 inside ONE transaction (all or nothing)
 *   - every rejected line is written to results/B4_1_migration_report.txt with its line number and reason
 * Usage: java Migrate [file]     (default work/legacy_passes.txt)
 */
public class Migrate {

    static final int BATCH = 1000;

    public static void main(String[] args) throws Exception {
        Path in = args.length > 0 ? Paths.get(args[0]) : Bench.workDir().resolve("legacy_passes.txt");
        Path report = Paths.get(System.getProperty("results.dir", "results")).resolve("B4_1_migration_report.txt");
        Files.createDirectories(report.getParent());

        Map<BusPassFileStore.Reason, Integer> rejects = new EnumMap<>(BusPassFileStore.Reason.class);
        int duplicates = 0, lineNo = 0, loaded = 0, rejected = 0;
        Set<String> seen = new HashSet<>();
        long t0 = System.nanoTime();

        var dec = StandardCharsets.UTF_8.newDecoder().onMalformedInput(CodingErrorAction.REPLACE).onUnmappableCharacter(CodingErrorAction.REPLACE);
        try (Connection con = Db.connect();
             BufferedReader r = new BufferedReader(new InputStreamReader(Files.newInputStream(in), dec), 1 << 16);
             PrintWriter rep = new PrintWriter(Files.newBufferedWriter(report, StandardCharsets.UTF_8))) {

            try (Statement st = con.createStatement()) { st.executeUpdate("TRUNCATE TABLE bus_pass"); }
            rep.println("MIGRATION REPORT  source=" + in.getFileName() + "  target=bus_pass");
            rep.println("line | reason | text");

            con.setAutoCommit(false);
            try (PreparedStatement ps = con.prepareStatement(
                    "INSERT INTO bus_pass(pass_id, reg_no, name, route_no, boarding_stop, valid_until, amount) VALUES (?,?,?,?,?,?,?)")) {
                int pending = 0;
                String line;
                while ((line = r.readLine()) != null) {
                    lineNo++;
                    BusPassFileStore.Result res = BusPassFileStore.decode(line);
                    String why = null;
                    if (!res.ok()) why = res.reason.name();
                    else if (!seen.add(res.pass.passId())) why = "DUPLICATE_PASS_ID";
                    if (why != null) {
                        rejected++;
                        if (res.ok()) duplicates++; else rejects.merge(res.reason, 1, Integer::sum);
                        rep.println(lineNo + " | " + why + " | " + (line.length() > 70 ? line.substring(0, 70) + "..." : line));
                        continue;
                    }
                    BusPassFileStore.Pass p = res.pass;
                    ps.setString(1, p.passId());
                    ps.setString(2, p.regNo());
                    ps.setString(3, p.name());
                    ps.setInt(4, p.route());
                    ps.setString(5, p.stop());
                    ps.setDate(6, java.sql.Date.valueOf(p.validUntil()));
                    ps.setBigDecimal(7, p.amount());
                    ps.addBatch();
                    loaded++;
                    if (++pending == BATCH) { ps.executeBatch(); pending = 0; }
                }
                if (pending > 0) ps.executeBatch();
                con.commit();                                            // all valid rows become permanent together
            } catch (Exception e) {
                con.rollback();                                          // any database failure: nothing is loaded
                System.out.println("MIGRATION ABORTED and rolled back: " + e);
                throw e;
            }
            int inDb;
            try (Statement st = con.createStatement(); ResultSet rs = st.executeQuery("SELECT COUNT(*) FROM bus_pass")) { rs.next(); inDb = rs.getInt(1); }
            double sec = (System.nanoTime() - t0) / 1e9;
            rep.println("SUMMARY lines=" + lineNo + " loaded=" + loaded + " rejected=" + rejected + " by reason " + rejects + " DUPLICATE_PASS_ID=" + duplicates);
            System.out.printf("Lines read      : %d%n", lineNo);
            System.out.printf("Loaded          : %d  (rows in bus_pass afterwards: %d -> %s)%n", loaded, inDb, inDb == loaded ? "match" : "MISMATCH");
            System.out.printf("Rejected        : %d%n", rejected);
            for (var e : rejects.entrySet()) System.out.printf("   %-18s %d%n", e.getKey(), e.getValue());
            System.out.printf("   %-18s %d%n", "DUPLICATE_PASS_ID", duplicates);
            System.out.printf("Time            : %.2f s  (%.0f lines/s)%n", sec, lineNo / sec);
            System.out.println("Full list of rejected lines: " + report);
            Bench.resetCsv("B4_1_migration.csv", "lines,loaded,rejected,time_s");
            Bench.csv("B4_1_migration.csv", lineNo + "," + loaded + "," + rejected + "," + String.format("%.2f", sec));
        }
    }
}
