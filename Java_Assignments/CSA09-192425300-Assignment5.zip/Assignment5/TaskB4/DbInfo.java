import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.ResultSet;

/** Task B4.2 - reports what the application is connected to, using DatabaseMetaData. */
public class DbInfo {
    public static void main(String[] args) throws Exception {
        try (Connection con = Db.connect()) {
            DatabaseMetaData md = con.getMetaData();
            System.out.println("Database product      : " + md.getDatabaseProductName() + " " + md.getDatabaseProductVersion());
            System.out.println("Driver                : " + md.getDriverName() + " " + md.getDriverVersion());
            System.out.println("JDBC spec             : " + md.getJDBCMajorVersion() + "." + md.getJDBCMinorVersion());
            System.out.println("URL / user            : " + md.getURL().replaceAll("password=[^&]*", "password=***") + " / " + md.getUserName());
            System.out.println("Transactions supported: " + md.supportsTransactions()
                    + "   default isolation: " + isolation(con.getTransactionIsolation()));
            System.out.println("Batch updates         : " + md.supportsBatchUpdates());
            System.out.println("Identifier case       : stores lower=" + md.storesLowerCaseIdentifiers() + " mixed=" + md.storesMixedCaseIdentifiers());
            System.out.println("Max connections       : " + md.getMaxConnections() + " (0 = no fixed limit reported)");
            System.out.println("Catalog (database)    : " + con.getCatalog());
            System.out.println("Tables present:");
            try (ResultSet rs = md.getTables(con.getCatalog(), null, "%", new String[] {"TABLE"})) {
                while (rs.next()) System.out.println("   " + rs.getString("TABLE_NAME"));
            }
            System.out.println("Columns of bus_pass:");
            try (ResultSet rs = md.getColumns(con.getCatalog(), null, "bus_pass", "%")) {
                while (rs.next()) System.out.printf("   %-14s %-10s size=%-4d nullable=%s%n", rs.getString("COLUMN_NAME"),
                        rs.getString("TYPE_NAME"), rs.getInt("COLUMN_SIZE"), rs.getString("IS_NULLABLE"));
            }
            System.out.println("Primary key of bus_pass:");
            try (ResultSet rs = md.getPrimaryKeys(con.getCatalog(), null, "bus_pass")) {
                while (rs.next()) System.out.println("   " + rs.getString("COLUMN_NAME") + " (key " + rs.getString("PK_NAME") + ")");
            }
        }
    }

    static String isolation(int level) {
        switch (level) {
            case Connection.TRANSACTION_READ_UNCOMMITTED: return "READ_UNCOMMITTED";
            case Connection.TRANSACTION_READ_COMMITTED: return "READ_COMMITTED";
            case Connection.TRANSACTION_REPEATABLE_READ: return "REPEATABLE_READ";
            case Connection.TRANSACTION_SERIALIZABLE: return "SERIALIZABLE";
            default: return "NONE";
        }
    }
}
