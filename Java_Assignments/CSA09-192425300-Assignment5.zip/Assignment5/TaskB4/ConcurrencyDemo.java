import java.nio.file.Files;
import java.nio.file.Path;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Task B4.3 - several counters issue passes at the same time. Rule: a pass id may be issued only once.
 * 8 "counters" (threads) all try to issue the same 250 pass ids (a rush at the start of the semester).
 *   A. text file, check-then-append, no lock       -> duplicates appear (race condition)
 *   B. text file, same code inside synchronized    -> correct, but only inside ONE program
 *   C. database, PRIMARY KEY + INSERT              -> correct whichever program or machine the counter runs on
 * Output: results/B4_3_concurrency.csv   design, trial, rows_stored, expected, duplicates, time_ms
 */
public class ConcurrencyDemo {
    static final int COUNTERS = 8, PASSES = 250;
    static final Object LOCK = new Object();

    interface Issue { void issue(int counter, int i) throws Exception; }

    static double runCounters(Issue issue) throws Exception {
        List<Thread> ts = new ArrayList<>();
        Exception[] err = new Exception[1];
        long t0 = System.nanoTime();
        for (int c = 0; c < COUNTERS; c++) {
            final int counter = c;
            Thread t = new Thread(() -> {
                try { for (int i = 1; i <= PASSES; i++) issue.issue(counter, i); }
                catch (Exception e) { synchronized (err) { err[0] = e; } }
            });
            ts.add(t);
            t.start();
        }
        for (Thread t : ts) t.join();
        if (err[0] != null) throw err[0];
        return (System.nanoTime() - t0) / 1e6;
    }

    static BusPassFileStore.Pass pass(int i) {
        return new BusPassFileStore.Pass(PassData.passId(i), String.valueOf(192000000 + i), "Student " + i, 1 + i % 40, "Guindy",
                LocalDate.of(2027, 3, 31), new java.math.BigDecimal("3500.00"));
    }

    static void file(String label, boolean lock, int trials) throws Exception {
        for (int t = 1; t <= trials; t++) {
            Path f = Bench.workDir().resolve("concurrent.txt");
            Files.deleteIfExists(f);
            BusPassFileStore s = new BusPassFileStore(f);
            double ms = runCounters((c, i) -> {
                try {
                    if (lock) { synchronized (LOCK) { s.add(pass(i)); } } else s.add(pass(i));
                } catch (IllegalStateException duplicate) { /* the store itself noticed it: normal, expected */ }
            });
            Set<String> ids = new HashSet<>();
            int lines = 0;
            for (String line : Files.readAllLines(f)) { lines++; ids.add(line.substring(0, line.indexOf('|'))); }
            report(label, t, lines, PASSES, lines - ids.size(), ms);
        }
    }

    static void db() throws Exception {
        try (Connection setup = Db.connect(); Statement st = setup.createStatement()) { st.executeUpdate("TRUNCATE TABLE pass_issue"); }
        int[] rejected = new int[1];
        double ms = runCounters((c, i) -> {
            try (Connection con = pooled()) {
                try (PreparedStatement ps = con.prepareStatement("INSERT INTO pass_issue(reg_no, counter_id) VALUES (?, ?)")) {
                    ps.setString(1, String.valueOf(192000000 + i));
                    ps.setInt(2, c);
                    ps.executeUpdate();
                } catch (SQLException e) {
                    if (e.getSQLState() != null && e.getSQLState().startsWith("23")) synchronized (rejected) { rejected[0]++; }   // duplicate key: already issued
                    else throw e;
                }
            }
        });
        int rows;
        try (Connection con = Db.connect(); Statement st = con.createStatement(); ResultSet rs = st.executeQuery("SELECT COUNT(*) FROM pass_issue")) { rs.next(); rows = rs.getInt(1); }
        report("C. database PRIMARY KEY (" + rejected[0] + " duplicate attempts refused)", 1, rows, PASSES, rows - PASSES, ms);
    }

    /** Each counter thread keeps its own connection (a real application would use a connection pool). */
    static final ThreadLocal<Connection> CONN = new ThreadLocal<>();
    static Connection pooled() throws SQLException {
        Connection c = CONN.get();
        if (c == null) { c = Db.connect(); CONN.set(c); }
        return new NoClose(c).proxy();
    }

    /** Tiny wrapper so try-with-resources does not close the per-thread connection. */
    static final class NoClose {
        final Connection c;
        NoClose(Connection c) { this.c = c; }
        Connection proxy() {
            return (Connection) java.lang.reflect.Proxy.newProxyInstance(Connection.class.getClassLoader(), new Class<?>[] {Connection.class},
                    (p, m, a) -> { if (m.getName().equals("close")) return null;
                        try { return m.invoke(c, a); } catch (java.lang.reflect.InvocationTargetException e) { throw e.getCause(); } });
        }
    }

    static void report(String design, int trial, int rows, int expected, int dups, double ms) {
        System.out.printf("%-62s trial %d: rows stored=%4d (expected %d) duplicates=%4d  %8.1f ms%n", design, trial, rows, expected, dups, ms);
        Bench.csv("B4_3_concurrency.csv", "\"" + design + "\"," + trial + "," + rows + "," + expected + "," + dups + "," + String.format("%.1f", ms));
    }

    public static void main(String[] args) throws Exception {
        Bench.resetCsv("B4_3_concurrency.csv", "design,trial,rows_stored,expected,duplicates,time_ms");
        System.out.println(COUNTERS + " counters, each trying to issue the same " + PASSES + " pass ids");
        file("A. text file, check-then-append, NO lock", false, 5);
        file("B. text file, synchronized (one JVM only)", true, 2);
        db();
    }
}
