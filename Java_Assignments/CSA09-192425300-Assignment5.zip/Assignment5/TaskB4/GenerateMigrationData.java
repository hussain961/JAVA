import java.io.BufferedWriter;
import java.math.BigDecimal;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;

/**
 * Task B4.1 - creates the "existing pass file" for the migration: 100,000 passes in the A1 text format with
 * a KNOWN number of deliberately injected defects, so that the migration report can be checked against the truth.
 *
 *   20 lines with the wrong number of fields      (replace)
 *   20 lines with a non-numeric amount            (replace)
 *   20 lines edited by hand (CRC no longer valid) (replace)
 *   20 empty lines                                (insert)
 *   20 duplicate pass ids                         (append copies of earlier valid lines)
 * Expected result: 99,940 loaded, 100 rejected.
 */
public class GenerateMigrationData {
    public static void main(String[] args) throws Exception {
        int n = 100000;
        Path out = Bench.workDir().resolve("legacy_passes.txt");
        List<BusPassFileStore.Pass> passes = PassData.passes(n);
        int[] wrongCount = new int[20], badAmount = new int[20], badCrc = new int[20];
        for (int i = 0; i < 20; i++) {
            wrongCount[i] = 1000 + i * 4000 + 3;
            badAmount[i] = 1500 + i * 4000 + 5;
            badCrc[i] = 2000 + i * 4000 + 7;
        }
        java.util.Set<Integer> wc = new java.util.HashSet<>(), ba = new java.util.HashSet<>(), bc = new java.util.HashSet<>();
        for (int i : wrongCount) wc.add(i);
        for (int i : badAmount) ba.add(i);
        for (int i : badCrc) bc.add(i);

        int dupCount = 0, emptyCount = 0;
        try (BufferedWriter w = Files.newBufferedWriter(out, StandardCharsets.UTF_8)) {
            for (int i = 0; i < n; i++) {
                BusPassFileStore.Pass p = passes.get(i);
                String line = BusPassFileStore.encode(p);
                if (wc.contains(i)) {
                    line = p.passId() + "|" + p.regNo() + "|" + p.name();
                } else if (ba.contains(i)) {
                    String body = String.join("|", p.passId(), p.regNo(), BusPassFileStore.escape(p.name()), String.valueOf(p.route()),
                            p.stop(), p.validUntil().toString(), "abc");
                    line = body + "|" + BusPassFileStore.crcHex(body);
                } else if (bc.contains(i)) {
                    line = line.replace("|" + p.route() + "|", "|" + (p.route() % 90 + 1 == p.route() ? 99 : p.route() % 90 + 1) + "|");   // change the route only
                }
                w.write(line);
                w.write('\n');
                if (i % 5000 == 4999 && emptyCount < 20) { w.write('\n'); emptyCount++; }
            }
            // 20 duplicates of valid earlier lines, appended at the end
            for (int i = 0; dupCount < 20; i += 997) {
                if (wc.contains(i) || ba.contains(i) || bc.contains(i)) continue;
                w.write(BusPassFileStore.encode(passes.get(i)));
                w.write('\n');
                dupCount++;
            }
        }
        // the injected CRC defects only count if the edited line really differs
        System.out.println("Created " + out + "  (" + Files.size(out) / 1024 + " KB)");
        System.out.println("Injected defects: wrong field count=20, non-numeric amount=20, edited by hand (CRC)=20, empty lines=" + emptyCount
                + ", duplicate pass ids=" + dupCount);
        System.out.println("Expected migration result: loaded=" + (n - 60) + " rejected=" + (60 + emptyCount + dupCount));
    }
}
