import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * Task A4 alternative concept - Java serialization vs CSV vs JSON for n residents.
 * Output: results/A4_formats.csv   n, format, file_kb, save_ms, load_ms
 */
public class SerializationBench {

    static class Res implements Serializable {
        private static final long serialVersionUID = 1L;
        String name, regNo;
        int room;
        Res(String n, String r, int room) { name = n; regNo = r; this.room = room; }
    }

    static List<Res> make(int n) {
        Random r = new Random(11);
        List<Res> l = new ArrayList<>(n);
        for (int i = 0; i < n; i++) {
            l.add(new Res(PassData.FIRST[r.nextInt(PassData.FIRST.length)] + " " + PassData.LAST[r.nextInt(PassData.LAST.length)],
                    String.valueOf(192000000 + i), 100 + r.nextInt(400)));
        }
        return l;
    }

    // ---------------------------------------------------------------- serialization
    static void saveSer(Path f, List<Res> l) throws IOException {
        try (ObjectOutputStream o = new ObjectOutputStream(new java.io.BufferedOutputStream(Files.newOutputStream(f)))) {
            o.writeObject(l);
        }
    }

    @SuppressWarnings("unchecked")
    static List<Res> loadSer(Path f) throws Exception {
        try (ObjectInputStream i = new ObjectInputStream(new java.io.BufferedInputStream(Files.newInputStream(f)))) {
            return (List<Res>) i.readObject();
        }
    }

    // ---------------------------------------------------------------- CSV
    static void saveCsv(Path f, List<Res> l) throws IOException {
        try (BufferedWriter w = Files.newBufferedWriter(f)) {
            for (Res r : l) { w.write(r.name + "," + r.regNo + "," + r.room); w.newLine(); }
        }
    }

    /** A new column is tolerated: missing trailing fields get defaults. */
    static List<Res> loadCsv(Path f) throws IOException {
        List<Res> l = new ArrayList<>();
        try (BufferedReader r = Files.newBufferedReader(f)) {
            String line;
            while ((line = r.readLine()) != null) {
                String[] a = line.split(",", -1);
                l.add(new Res(a[0], a[1], a.length > 2 ? Integer.parseInt(a[2]) : 0));
            }
        }
        return l;
    }

    // ---------------------------------------------------------------- JSON (flat objects, hand-written)
    static void saveJson(Path f, List<Res> l) throws IOException {
        try (BufferedWriter w = Files.newBufferedWriter(f)) {
            w.write("[");
            for (int i = 0; i < l.size(); i++) {
                Res r = l.get(i);
                if (i > 0) w.write(",");
                w.write("\n {\"name\":\"" + r.name.replace("\\", "\\\\").replace("\"", "\\\"") + "\",\"regNo\":\"" + r.regNo + "\",\"room\":" + r.room + "}");
            }
            w.write("\n]\n");
        }
    }

    /** Minimal parser for an array of flat objects with string and integer values. Unknown keys are ignored. */
    static List<Res> loadJson(Path f) throws IOException {
        String s = Files.readString(f);
        List<Res> l = new ArrayList<>();
        int i = 0;
        while ((i = s.indexOf('{', i)) >= 0) {
            int end = s.indexOf('}', i);
            String name = "", reg = "";
            int room = 0;
            int p = i + 1;
            while (p < end) {
                int k0 = s.indexOf('"', p);
                if (k0 < 0 || k0 > end) break;
                int k1 = s.indexOf('"', k0 + 1);
                String key = s.substring(k0 + 1, k1);
                int colon = s.indexOf(':', k1);
                int v = colon + 1;
                String val;
                if (s.charAt(v) == '"') {
                    StringBuilder b = new StringBuilder();
                    int q = v + 1;
                    while (s.charAt(q) != '"') {
                        if (s.charAt(q) == '\\') q++;
                        b.append(s.charAt(q++));
                    }
                    val = b.toString();
                    p = q + 1;
                } else {
                    int q = v;
                    while (q < end && s.charAt(q) != ',') q++;
                    val = s.substring(v, q).trim();
                    p = q + 1;
                }
                if (key.equals("name")) name = val; else if (key.equals("regNo")) reg = val; else if (key.equals("room")) room = Integer.parseInt(val);
            }
            l.add(new Res(name, reg, room));
            i = end + 1;
        }
        return l;
    }

    interface Save { void run(Path f, List<Res> l) throws Exception; }
    interface Load { List<Res> run(Path f) throws Exception; }

    static void run(int n, String fmt, String ext, Save save, Load load, int runs) throws Exception {
        List<Res> data = make(n);
        Path f = Bench.workDir().resolve("hostel_" + n + "." + ext);
        double ts = Bench.medianMs(runs, () -> save.run(f, data));
        double[] tl = new double[runs];
        List<Res>[] hold = new List[1];
        double tlm = Bench.medianMs(runs, () -> hold[0] = load.run(f));
        List<Res> back = hold[0];
        if (back.size() != n || !back.get(n - 1).regNo.equals(data.get(n - 1).regNo)) throw new IllegalStateException(fmt + " round trip failed");
        long kb = Files.size(f) / 1024;
        System.out.printf("n=%7d | %-22s | %7d KB | save %9.1f ms | load %9.1f ms%n", n, fmt, kb, ts, tlm);
        Bench.csv("A4_formats.csv", n + "," + fmt + "," + kb + "," + String.format("%.1f,%.1f", ts, tlm));
    }

    public static void main(String[] args) throws Exception {
        Bench.resetCsv("A4_formats.csv", "n,format,file_kb,save_ms,load_ms");
        // warm-up
        for (int w = 0; w < 3; w++) {
            List<Res> d = make(20000);
            Path f = Bench.workDir().resolve("warm.tmp");
            saveSer(f, d); loadSer(f); saveCsv(f, d); loadCsv(f); saveJson(f, d); loadJson(f);
        }
        for (int n : new int[] {1000, 10000, 100000}) {
            int runs = n >= 100000 ? 3 : 5;
            run(n, "Java serialization", "ser", SerializationBench::saveSer, SerializationBench::loadSer, runs);
            run(n, "CSV text", "csv", SerializationBench::saveCsv, SerializationBench::loadCsv, runs);
            run(n, "JSON text", "json", SerializationBench::saveJson, SerializationBench::loadJson, runs);
        }

        // adding a field: old CSV / JSON files read by a newer program that expects 'room'
        Path oldCsv = Bench.workDir().resolve("old_no_room.csv");
        Files.writeString(oldCsv, "Arun Kumar,192311001\n");
        Path oldJson = Bench.workDir().resolve("old_no_room.json");
        Files.writeString(oldJson, "[{\"name\":\"Arun Kumar\",\"regNo\":\"192311001\"}]");
        System.out.println("New field 'room' read from an OLD CSV : room=" + loadCsv(oldCsv).get(0).room + " (default, no exception)");
        System.out.println("New field 'room' read from an OLD JSON: room=" + loadJson(oldJson).get(0).room + " (default, no exception)");
    }
}
