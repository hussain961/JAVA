import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.NotSerializableException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * Task A4.1 - supporting experiment: what is written when a Hostel object is serialized?
 * Hostel -> List&lt;Room&gt; -> List&lt;Resident&gt;; a Resident has a name, register number, password and a live connection.
 */
public class SerializationDemo {

    static class Hostel implements Serializable {
        private static final long serialVersionUID = 1L;
        String name;
        List<Room> rooms = new ArrayList<>();
        static int instancesCreated = 0;                  // static: belongs to the class, never serialized
    }

    static class Room implements Serializable {
        private static final long serialVersionUID = 1L;
        int number;
        List<Resident> residents = new ArrayList<>();
    }

    static class Resident implements Serializable {
        private static final long serialVersionUID = 1L;
        String name;
        String regNo;
        Room room;                                        // back-reference: Room -> Resident -> Room is a cycle
        transient String password;                        // secret: must not be written to the file
        transient Object connection;                      // live resource: cannot (and must not) be saved
    }

    /** Same as Resident but the connection field is NOT transient (the mistake the task asks about). */
    static class BadResident implements Serializable {
        private static final long serialVersionUID = 1L;
        String name;
        Object connection;
    }

    static byte[] write(Object o) throws IOException {
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        try (ObjectOutputStream out = new ObjectOutputStream(bos)) { out.writeObject(o); }
        return bos.toByteArray();
    }

    static Object read(byte[] b) throws IOException, ClassNotFoundException {
        try (ObjectInputStream in = new ObjectInputStream(new ByteArrayInputStream(b))) { return in.readObject(); }
    }

    public static void main(String[] args) throws Exception {
        // build the object graph
        Hostel h = new Hostel();
        h.name = "Block-A";
        Hostel.instancesCreated = 5;
        Room room = new Room();
        room.number = 101;
        for (String[] nr : new String[][] {{"Arun", "192311001"}, {"Divya", "192311002"}}) {
            Resident r = new Resident();
            r.name = nr[0]; r.regNo = nr[1]; r.room = room;
            r.password = "secret-" + nr[0];
            r.connection = new Object();                  // stands for a live java.sql.Connection
            room.residents.add(r);
        }
        h.rooms.add(room);

        // 1. serialize and deserialize the whole graph with ONE writeObject call
        byte[] bytes = write(h);
        Hostel copy = (Hostel) read(bytes);
        Room cr = copy.rooms.get(0);
        Resident c0 = cr.residents.get(0), c1 = cr.residents.get(1);
        System.out.println("1. Graph written with one writeObject(hostel): " + bytes.length + " bytes");
        System.out.println("   Rooms reachable after reading : " + copy.rooms.size() + ", residents: " + cr.residents.size());
        System.out.println("   Resident names / regNos       : " + c0.name + "/" + c0.regNo + ", " + c1.name + "/" + c1.regNo);
        System.out.println("   Cycle preserved (resident.room == hostel's room): " + (c0.room == cr && c1.room == cr));
        System.out.println("   Original objects are different objects from the copies: " + (copy != h && cr != room));

        // 2. transient fields
        System.out.println("2. transient fields after reading:  password=" + c0.password + "  connection=" + c0.connection
                + "   (before writing: password=" + room.residents.get(0).password + ")");
        Hostel.instancesCreated = 9;                      // change the static AFTER writing, then read the old bytes again
        read(bytes);
        System.out.println("   static field Hostel.instancesCreated was 5 when written, set to 9 before reading: after reading it is "
                + Hostel.instancesCreated + " (not restored from the file - statics belong to the class)");

        // 3. forgetting transient on a live connection
        BadResident bad = new BadResident();
        bad.name = "Arun";
        bad.connection = new Object();
        try {
            write(bad);
            System.out.println("3. (unexpected) no exception");
        } catch (NotSerializableException e) {
            System.out.println("3. Non-transient connection field -> java.io.NotSerializableException: " + e.getMessage());
        }

        // 4. the same Room object referenced twice is written once (shared reference is kept)
        List<Object> twice = new ArrayList<>();
        twice.add(room);
        twice.add(room);
        @SuppressWarnings("unchecked") List<Object> back = (List<Object>) read(write(twice));
        System.out.println("4. Same Room referenced twice in a list: identical after reading = " + (back.get(0) == back.get(1)));
    }
}
