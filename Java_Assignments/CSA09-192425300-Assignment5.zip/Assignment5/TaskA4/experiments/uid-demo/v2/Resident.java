import java.io.Serializable;

/** Version 2 - a phone field was added; still no explicit serialVersionUID. */
public class Resident implements Serializable {
    String name;
    String regNo;
    String phone;
    Resident(String name, String regNo) { this.name = name; this.regNo = regNo; }
    @Override public String toString() { return "Resident[name=" + name + ", regNo=" + regNo + ", phone=" + phone + "]"; }
}
