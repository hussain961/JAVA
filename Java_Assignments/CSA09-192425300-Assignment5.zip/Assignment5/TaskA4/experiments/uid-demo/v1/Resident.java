import java.io.Serializable;

/** Version 1 - no explicit serialVersionUID. */
public class Resident implements Serializable {
    String name;
    String regNo;
    Resident(String name, String regNo) { this.name = name; this.regNo = regNo; }
    @Override public String toString() { return "Resident[name=" + name + ", regNo=" + regNo + "]"; }
}
