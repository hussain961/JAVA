import java.io.Serializable;

/** Version 2 (phone added) with the SAME explicit serialVersionUID. */
public class Resident implements Serializable {
    private static final long serialVersionUID = 1L;
    String name;
    String regNo;
    String phone;
    Resident(String name, String regNo) { this.name = name; this.regNo = regNo; }
    @Override public String toString() { return "Resident[name=" + name + ", regNo=" + regNo + ", phone=" + phone + "]"; }
}
