#!/bin/bash
# Task A4.2 - what happens to an OLD file when a field is added to Resident?
cd "$(dirname "$0")" || exit 1
rm -rf build && mkdir -p build/{v1,v2,v1u,v2u}
for v in v1 v2 v1u v2u; do javac -d build/$v $v/Resident.java Writer.java Reader.java || exit 1; done

echo "== Scenario 1: NO serialVersionUID declared =="
echo "serialver (computed by the JVM from the class structure):"
echo "   v1: $(serialver -classpath build/v1 Resident)"
echo "   v2: $(serialver -classpath build/v2 Resident)"
java -cp build/v1 Writer build/old_v1.ser
java -cp build/v2 Reader build/old_v1.ser

echo
echo "== Scenario 2: serialVersionUID = 1L declared in both versions =="
echo "serialver:"
echo "   v1u: $(serialver -classpath build/v1u Resident)"
echo "   v2u: $(serialver -classpath build/v2u Resident)"
java -cp build/v1u Writer build/old_v1u.ser
java -cp build/v2u Reader build/old_v1u.ser
