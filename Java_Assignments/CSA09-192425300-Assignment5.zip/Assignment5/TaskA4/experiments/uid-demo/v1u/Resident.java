import java.io.Serializable;

/** Version 1 with an explicit serialVersionUID. */
public class Resident implements Serializable {
    private static final long serialVersionUID = 1L;
    String name;
    String regNo;
    Resident(String name, String regNo) { this.name = name; this.regNo = regNo; }
    @Override public String toString() { return "Resident[name=" + name + ", regNo=" + regNo + "]"; }
}
