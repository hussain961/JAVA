import java.io.InvalidClassException;
import java.io.ObjectInputStream;
import java.nio.file.Files;
import java.nio.file.Paths;

/** Reads resident.ser with whatever version of Resident is on the class path. */
public class Reader {
    public static void main(String[] args) throws Exception {
        try (ObjectInputStream i = new ObjectInputStream(Files.newInputStream(Paths.get(args[0])))) {
            System.out.println("read OK: " + i.readObject());
        } catch (InvalidClassException e) {
            System.out.println("read FAILED -> java.io.InvalidClassException: " + e.getMessage());
        }
    }
}
