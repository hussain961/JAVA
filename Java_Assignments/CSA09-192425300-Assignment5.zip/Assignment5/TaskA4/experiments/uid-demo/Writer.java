import java.io.ObjectOutputStream;
import java.nio.file.Files;
import java.nio.file.Paths;

/** Writes one Resident (whatever version of the class is on the class path) to resident.ser. */
public class Writer {
    public static void main(String[] args) throws Exception {
        try (ObjectOutputStream o = new ObjectOutputStream(Files.newOutputStream(Paths.get(args[0])))) {
            o.writeObject(new Resident("Arun", "192311001"));
        }
        System.out.println("written with class version on class path: " + new Resident("Arun", "192311001"));
    }
}
