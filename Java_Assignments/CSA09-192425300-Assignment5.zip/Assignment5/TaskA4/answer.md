## Task A4 – Persist an Object Graph (4 marks, K4 – Analyse)

**Problem.** A hostel program holds a `Hostel` that contains `Room` objects, each containing `Resident` objects. A `Resident` has a name, a register number, a password and a live database connection. The whole hostel must be saved with one call and restored later.

### A4.1 – Decide what is persisted (2 marks)

![Figure 4 – The object graph of a Hostel; transient fields are left out of the file](../report/figures/d_a4_graph.png){width=100%}


| Class / field | Persist? | Reason |
|:---|:---|:---|
| `Hostel.name`, `Hostel.rooms` | yes | the data the program must restore |
| `Room.number`, `Room.residents` | yes | part of the graph |
| `Resident.name`, `Resident.regNo`, `Resident.room` | yes | data; `room` is a back-reference (a cycle) |
| `Resident.password` | **no – `transient`** | a secret must never be written in clear to a file; after reading it is `null` and must be asked for again (or the program stores only a salted hash in the database) |
| `Resident.connection` | **no – `transient`** | a live connection cannot be saved: `Connection` is not `Serializable` (without `transient`, writing fails with `NotSerializableException`), and a connection is meaningless after a restart – it must be re-opened |
| `static` fields | no (automatic) | they belong to the class, not to an object |

**What one `writeObject(hostel)` call writes.** `ObjectOutputStream` writes the object and then, recursively, **everything reachable from it** – the `ArrayList` of rooms, each `Room`, the `ArrayList` of residents, each `Resident`. Three rules follow:

1. **Every class in the graph must implement `Serializable`** (`Hostel`, `Room`, `Resident`; `ArrayList` already does).
2. **An object referenced twice is written once**, and the references are rebuilt on reading. The cycle `Room → Resident → Room` therefore does not loop forever.
3. **`transient` and `static` fields are skipped**; after `readObject` transient fields hold their default value (`null`, `0`, `false`).

```text
ALGORITHM SaveHostel
INPUT : hostel object, file F
BEGIN
  1. OPEN F for writing through an object output stream (buffered)
  2. WRITE the hostel object                  // the whole reachable graph is written
  3. CLOSE F                                  // try-with-resources
END

ALGORITHM LoadHostel
INPUT : file F
OUTPUT: hostel object
BEGIN
  1. OPEN F for reading through an object input stream (buffered)
  2. hostel ← READ one object and cast it to Hostel
  3. FOR EACH resident IN hostel DO
  4.     resident.connection ← open a new database connection      // transient field restored
  5.     resident.password   ← unknown until the user logs in again
  6. END FOR
  7. CLOSE F; RETURN hostel
END
```

**Evidence** (`TaskA4/experiments/SerializationDemo.java`):

```text
1. Graph written with one writeObject(hostel): 407 bytes
   Rooms reachable after reading : 1, residents: 2
   Resident names / regNos       : Arun/192311001, Divya/192311002
   Cycle preserved (resident.room == hostel's room): true
   Original objects are different objects from the copies: true
2. transient fields after reading:  password=null  connection=null   (before writing: password=secret-Arun)
   static field Hostel.instancesCreated was 5 when written, set to 9 before reading: after reading it is 9 (not restored from the file - statics belong to the class)
3. Non-transient connection field -> java.io.NotSerializableException: java.lang.Object
4. Same Room referenced twice in a list: identical after reading = true
```

The whole graph (1 room, 2 residents) occupies 407 bytes; the cycle and the shared object are preserved; the transient password and connection come back as `null`; the non-transient connection throws `NotSerializableException`.

### A4.2 – Plan for change (2 marks)

A `phoneNumber` field is added to `Resident`. Files written by the **old** class must still load.

* **Without `serialVersionUID`** the JVM computes a version number from the shape of the class (fields, methods, modifiers). Adding a field changes the shape, hence the number, and the old file is **rejected** with `InvalidClassException`.
* **With an explicit `serialVersionUID = 1L`** the number does not change. Adding a field is a *compatible* change: the old file loads and the new field receives its default value (`null`).

```text
== Scenario 1: NO serialVersionUID declared ==
serialver (computed by the JVM from the class structure):
   v1: Resident:    private static final long serialVersionUID = -4217321177445906819L;
   v2: Resident:    private static final long serialVersionUID = -8528813912482234793L;
written with class version on class path: Resident[name=Arun, regNo=192311001]
read FAILED -> java.io.InvalidClassException: Resident; local class incompatible: stream classdesc serialVersionUID = -4217321177445906819, local class serialVersionUID = -8528813912482234793

== Scenario 2: serialVersionUID = 1L declared in both versions ==
serialver:
   v1u: Resident:    private static final long serialVersionUID = 1L;
   v2u: Resident:    private static final long serialVersionUID = 1L;
written with class version on class path: Resident[name=Arun, regNo=192311001]
read OK: Resident[name=Arun, regNo=192311001, phone=null]
```

**Plan.** (1) Declare `private static final long serialVersionUID` in every serializable class **from the first version**. (2) Treat changes by compatibility: *adding* fields or methods is compatible; *removing or renaming* a field, *changing its type*, or *changing the class hierarchy* is incompatible and needs a new `serialVersionUID` plus a conversion step. (3) Give new fields a sensible default in `readObject` (for example `""` instead of `null` for `phoneNumber`). (4) Never deserialize files from untrusted sources – deserialization can execute attacker-chosen code paths.

### Alternative Concept and Complexity Analysis – CSV or JSON text instead of Java serialization

```text
ALGORITHM SaveResidentsAsText
INPUT : list of residents, file F, format (CSV line or JSON object)
BEGIN
  1. OPEN F for buffered text writing
  2. FOR EACH resident DO WRITE one line / one object with name, regNo, room number END FOR
  3. CLOSE F
END
// loading: read each line / object, build a Resident, link it to its Room by room number
```

| | Java serialization | CSV / JSON text |
|:---|:---|:---|
| Time to save and load *n* objects | **O(n)** | **O(n)** |
| Space | **O(n)** – class descriptors once, then per-object overhead | **O(n)** – field names repeated per object (JSON) or only values (CSV) |
| Object graph, cycles, shared references | automatic | the programmer must store ids and rebuild links |
| Language / tool independence | Java only, binary | any language, human-readable |
| Adding a field | needs `serialVersionUID` discipline; otherwise old files fail | an old file simply lacks the value: the loader supplies a default |
| Security | deserializing untrusted data is dangerous | parsing text is safe if the parser validates |

**Measured** (`TaskA4/experiments/SerializationBench.java`, 100,000 residents): serialization 3,522 KB, CSV 2,545 KB, JSON 5,475 KB. CSV is smallest; JSON is about 1.6 times the serialized size, because every object repeats its field names; serialization is about 1.4 times larger than CSV. Times for all three grow in proportion to *n*.

| Residents | Format | File size | Save | Load |
| ---: | :--- | ---: | ---: | ---: |
| 1,000 | Java serialization | 35 KB | 2.20 ms | 1.20 ms |
| 1,000 | CSV text | 25 KB | 2.00 ms | 1.30 ms |
| 1,000 | JSON text | 54 KB | 5.00 ms | 1.20 ms |
| 10,000 | Java serialization | 352 KB | 8.70 ms | 20.0 ms |
| 10,000 | CSV text | 254 KB | 6.80 ms | 8.30 ms |
| 10,000 | JSON text | 547 KB | 6.60 ms | 15.5 ms |
| 100,000 | Java serialization | 3,522 KB | 88.6 ms | 129 ms |
| 100,000 | CSV text | 2,545 KB | 50.4 ms | 109 ms |
| 100,000 | JSON text | 5,475 KB | 59.6 ms | 94.1 ms |

Table: Table 2 – Java serialization, CSV and JSON for the same residents


![Figure 5 – File size and save + load time of the three formats](../report/figures/fig_a4_formats.png){width=88%}


Java serialization is therefore **not** the smallest or fastest format here; its value is convenience for a complete graph, and its price is version fragility and Java lock-in. Both text loaders in the experiment accepted an *old* file that lacks the new `room` field and filled in a default.

**Evidence expected – covered:** the persisted-field decision with `transient` (A4.1), the compatibility plan with `serialVersionUID` (A4.2).
