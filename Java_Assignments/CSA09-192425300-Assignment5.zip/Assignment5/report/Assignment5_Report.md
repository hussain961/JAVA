::: {custom-style="CoverSmall"}
SIMATS Engineering
:::

::: {custom-style="CoverTitle"}
Programming in Java (CSA09)
:::

::: {custom-style="CoverTitle2"}
Assignment 5 – CO5
Data Persistence Engineering – Files and Databases
:::

::: {custom-style="CoverSub"}
Java I/O (byte, character and buffered streams, File, serialization) and JDBC (Statement, PreparedStatement, transactions, batch processing, metadata)
:::

::: {custom-style="CoverField"}
**Student name:** D.HUSSAINAIAH

**Register number:** 192425300

**Programme:** B.Tech – Artificial Intelligence and Machine Learning

**Total marks:** 50 (Part A – Design & Pseudocode: 25, Part B – Implementation & Experimental Investigation: 25)

**GitHub repository:** CSA09-192425300-Assignment5  –  *paste your repository link here:* ______________________________________

**Java / database used:** JDK 17 or later · MySQL (JDBC) · local test database `transport_test` created only for this assignment
:::

```{=openxml}
<w:p><w:r><w:br w:type="page"/></w:r></w:p>
```


**Contents**

- **How this report is organised**
    - Test environment and honesty of the measurements
    - Repository map
    - Pseudocode conventions
- **PART A – PERSISTENCE DESIGN & PSEUDOCODE (25 marks)**
    - Task A1 – Design a File Format (7 marks, K4 – Analyse)
    - Task A2 – Don't Read What You Don't Need (5 marks, K4 – Analyse)
    - Task A3 – Discover the Data-Access Design Pattern (5 marks, K4 – Analyse)
    - Task A4 – Persist an Object Graph (4 marks, K4 – Analyse)
    - Task A5 – Protect Data Integrity (4 marks, K4 – Analyse)
- **PART B – IMPLEMENTATION & EXPERIMENTAL INVESTIGATION (25 marks)**
    - Task B1 – Build and Validate the File Store (7 marks, K5 – Evaluate)
    - Task B2 – Attack Your Own Program (5 marks, K5 – Evaluate)
    - Task B3 – Insert Data Three Ways (8 marks, K5 – Evaluate)
    - Task B4 – Migrate and Decide (5 marks, K5 – Evaluate)
- **Conclusion**

```{=openxml}
<w:p><w:r><w:br w:type="page"/></w:r></w:p>
```

# How this report is organised

The assignment asks one question: *how should a Java engineer decide where and how data is stored, and how can the program be made correct, safe and efficient as the data grows?* The report follows the required workflow **Model → Choose a Store → Design → Protect → Implement → Measure → Compare → Decide**, using one running example – the **university transport office bus-pass records** (about 8,000 passes a year today, 100 times more at 12 campuses).

| Part | Tasks | What it contains |
|:---|:---|:---|
| **Part A – Design & Pseudocode (25)** | A1 file format · A2 buffering · A3 data-access pattern · A4 serialization · A5 transactions and injection | Record layouts, pseudocode, diagrams and reasoning. No Java is used in place of pseudocode. Where a design claim can be checked, a small supporting experiment from the repository is quoted as evidence. |
| **Part B – Implementation & Experiments (25)** | B1 file store · B2 adversarial input · B3 Statement / PreparedStatement / batch · B4 final decision | Working Java programs, test tables with expected and actual results, measurements, interpretation and the production decision. |

Every task also contains the required **Alternative Concept and Complexity Analysis**: the alternative is described with pseudocode, its time and space complexity are compared in Big-O notation, and – wherever possible – the comparison is backed by measurements from the repository.

## Test environment and honesty of the measurements

All programs were compiled and executed by the single script `run_all.sh`; the console output of each program is saved in `results/outputs/` and every measurement in `results/*.csv`. **All tables and numbers in this report are read from those files by `tools/build_report.py`**, so the report cannot disagree with the evidence.

| Item | Value |
|:---|:---|
| Reference run | 2026-11-15 09:46 UTC |
| Machine | Linux 6.18.44-fc-v470 x86_64, Intel(R) Xeon(R) Processor @ 2.10GHz x 1 core(s), 3992 MB RAM, openjdk version "21.0.13.0.3" 2026-10-24 |
| Database / driver used for the reference run | MariaDB 10.11.14-MariaDB-0ubuntu0.24.04.1 · MariaDB Connector/J 2.7.6 |

Absolute times depend on the computer, the disk and the database server, so the **conclusions below rest on orders of magnitude and growth trends, not on exact milliseconds**. Re-running `run_all.sh` followed by `python3 tools/build_report.py` regenerates this report with the numbers of the computer it runs on.

## Repository map

```text
CSA09-192425300-Assignment5/
  README.md  run_all.sh  db/ (schema.sql, setup_mysql_user.sql)  common/ (Db, Bench, PassData)
  TaskA1 ... TaskA5/   answer.md (design, pseudocode, reasoning)  + experiments/ where a claim is measured
  TaskB1/  PassStore.java (Complete the Code), BusPassFileStore.java (A1 design), LineCounter, BuffBench, GrowthBench, PassStoreTest
  TaskB2/  LoginDemo, BadFileDemo, EscapingWeakness
  TaskB3/  PassLoader.java (Complete the Code), SmallCorrectness, LoadBench, TransactionDemo, InsertStrategies
  TaskB4/  GenerateMigrationData, Migrate, DbInfo, ConcurrencyDemo, ScaleDecision
  results/ (outputs/*.txt, *.csv, migration report)   report/ (this report, figures)   tools/ (charts, report builder)
```

## Pseudocode conventions

Pseudocode in Part A uses a fixed layout: `ALGORITHM` name, `INPUT`, `OUTPUT`, numbered steps in `BEGIN … END`, upper-case keywords (`IF … THEN … ELSE`, `FOR EACH`, `WHILE`, `RETURN`), `←` for assignment and indentation for nesting. It is language-neutral: stream and class names appear only where the task asks which Java classes to use.


# PART A – PERSISTENCE DESIGN & PSEUDOCODE (25 marks)

## Task A1 – Design a File Format (7 marks, K4 – Analyse)

**Problem.** The transport office issues bus passes. A record has seven fields: pass ID, student register number, name, route number, boarding stop, validity date and amount paid. About 8,000 passes are issued a year. The file must support (i) adding a pass, (ii) finding a pass by pass ID and (iii) listing all passes on a route.

**Sizing.** At roughly 70 bytes per record, one year is about 8,000 × 70 B ≈ 0.55 MB – small enough to be read completely in a few milliseconds. A file is therefore a reasonable store *at today's scale*; Part B measures where it stops being reasonable.

### A1.1 – Represent the record (2 marks)

**(a) Delimited text file – one record per line, UTF-8.**

| # | Field | Format and validation | Example |
|:-:|:---|:---|:---|
| 1 | passId | `P` + 4 to 8 digits | `P000001` |
| 2 | regNo | exactly 9 digits | `192000037` |
| 3 | name | 1–60 characters, not blank | `Vignesh Iyer` |
| 4 | route | integer 1–99 | `23` |
| 5 | boardingStop | 1–40 characters | `Sholinganallur` |
| 6 | validUntil | ISO date `yyyy-MM-dd` | `2027-03-31` |
| 7 | amount | decimal with at most 2 places, 0 – 99,999.99 | `4150.00` |
| 8 | crc | CRC-32 of fields 1–7 (the text before the last `|`) as 8 hex digits | `2c309790` |

Complete line: `P000001|192000037|Vignesh Iyer|23|Sholinganallur|2027-03-31|4150.00|2c309790`

* **Delimiter.** The pipe `|` is used, not the comma. Names such as *Kumar, Arun* are common, and the comma-separated `PassStore` supplied with the assignment loses such a record (test C4 in Task B1).
* **A name that contains the delimiter.** Inside a field three characters are escaped: `|` → `\|`, `\` → `\\`, line break → `\n` (and `\r`). The reader splits only on an *unescaped* `|` and then reverses the escapes, so `Ravi|Kumar, Jr\X` is stored as `Ravi\|Kumar, Jr\\X` and read back unchanged (test T7).
* **Why a CRC field.** The number of fields only proves the *shape* of a line, not that its content is intact. The CRC detects a half-written line, a bit flip or a hand edit (A1.3).

**(b) Binary file written with `DataOutputStream`.** Every record is framed by a length so a reader can skip a damaged record:

| Order | Content | `DataOutputStream` method | Bytes |
|:-:|:---|:---|:--|
| 1 | payload length | `writeInt` | 4 |
| 2 | passId | `writeUTF` | 2 + length |
| 3 | regNo | `writeUTF` | 2 + length |
| 4 | name | `writeUTF` | 2 + length |
| 5 | route | `writeShort` | 2 |
| 6 | boardingStop | `writeUTF` | 2 + length |
| 7 | validUntil (`LocalDate.toEpochDay`) | `writeInt` | 4 |
| 8 | amount in paise (amount × 100, exact – no floating point) | `writeInt` | 4 |
| 9 | CRC-32 of bytes 2–8 | `writeInt` | 4 |

Strings carry their own two-byte length (`writeUTF`), so **no delimiter exists and a name containing `|` needs no escaping.** A real record produced by this layout (68 bytes) and its proof by read-back:

```text
Record P000001 (68 bytes):
  00 00 00 3c 00 07 50 30 30 30 30 30 31 00 09 31 39 32 30 30 30 30 33 37 00 0c 56 69 67 6e 65 73 68 20 49 79 65 72 00 17 00 0e 53 68 6f 6c 69 6e 67 61 6e 61 6c 6c 75 72 00 00 51 ac 00 06 55 18 a7 0c 70 bb
  text form (77 bytes): P000001|192000037|Vignesh Iyer|23|Sholinganallur|2027-03-31|4150.00|2c309790
Round trip: 2000 of 2000 records identical after write + read
Name with | , and \ stored as-is (length-prefixed, no escaping needed): true
Average size: binary 61.6 bytes/record, text 70.4 bytes/record
Corrupted record #2 detected: CRC mismatch - damaged record
```

The binary form is slightly smaller than the text form but cannot be read or repaired with a text editor, and its layout is harder to evolve. For an office whose records must be auditable by hand, the **text layout is chosen** for the main design.

### A1.2 – Design the operations (3 marks)

**Streams chosen (text-file design).**

| Operation | Classes | Why |
|:---|:---|:---|
| Add (append) | `FileChannel` opened with `CREATE, APPEND` + `force(true)` – or `BufferedWriter` over `FileOutputStream(file, true)` when durability per record is not needed | One `write` call per record makes the append a single operation; `force` makes it reach the disk before the method returns. Character streams (`FileWriter`) would hide the character set and give no durability control. |
| Find, List (read) | `BufferedReader` over `InputStreamReader(FileInputStream, UTF-8)` | The file is text, so `readLine()` is the natural unit; buffering reduces operating-system calls by thousands of times (Task A2); the explicit UTF-8 decoder makes the file portable between computers. |
| Byte-level check (tail test) | `RandomAccessFile` (read last byte) | Needed to ask "does the file end with a line break?" without reading the whole file. |

All streams are opened in try-with-resources so they are closed even when an exception occurs.

```text
ALGORITHM AddPass
INPUT : pass (7 fields), file F
OUTPUT: pass appended to F, or an error
BEGIN
  1. line ← ENCODE(pass)                          // escape fields, join with '|', append CRC
  2. IF DECODE(line) is not valid THEN REJECT "invalid pass" END IF     // validate before writing
  3. IF FIND(pass.passId) exists THEN REJECT "duplicate pass id" END IF
  4. IF F exists AND last byte of F is not '\n' THEN        // an earlier write was cut short
         prefix ← '\n'                                      // isolate the damaged tail, never glue to it
     ELSE prefix ← empty
     END IF
  5. OPEN F for append (create if missing)
  6. WRITE prefix + line + '\n' in ONE write operation
  7. FORCE the data to disk
  8. CLOSE F
END
```

```text
ALGORITHM FindPass
INPUT : passId, file F
OUTPUT: the pass, or "not found"
BEGIN
  1. IF F does not exist THEN RETURN "not found" END IF     // a missing file is an empty store
  2. OPEN F for buffered reading (UTF-8)
  3. WHILE a next line exists DO
  4.     IF line begins with passId + '|' THEN               // cheap test before the full check
  5.         result ← DECODE(line)
  6.         IF result is valid THEN CLOSE F; RETURN result.pass END IF
  7.         damagedCount ← damagedCount + 1                  // matching id but damaged line: skip it
  8.     END IF
  9. END WHILE
 10. CLOSE F
 11. RETURN "not found"
END
```

```text
ALGORITHM ListRoute
INPUT : route r, file F
OUTPUT: list of valid passes on route r
BEGIN
  1. result ← empty list
  2. IF F does not exist THEN RETURN result END IF
  3. OPEN F for buffered reading (UTF-8)
  4. WHILE a next line exists DO
  5.     d ← DECODE(line)
  6.     IF d is not valid THEN damagedCount ← damagedCount + 1; CONTINUE END IF
  7.     IF d.pass.route = r THEN ADD d.pass TO result END IF
  8. END WHILE
  9. CLOSE F
 10. RETURN result
END
```

```text
ALGORITHM DECODE
INPUT : line
OUTPUT: a valid pass, or a reason for rejection
BEGIN
  1. IF line is blank THEN RETURN reject EMPTY_LINE
  2. split line at the last unescaped '|' into body and crc
  3. split body at unescaped '|' and undo the escapes      // bad escape → reject BAD_ESCAPE
  4. IF number of fields ≠ 7 THEN RETURN reject WRONG_FIELD_COUNT
  5. IF CRC32(body) ≠ crc THEN RETURN reject CRC_MISMATCH
  6. validate each field (id pattern, 9-digit regNo, route 1-99, date, amount ≥ 0, ≤ 2 decimals)
  7. RETURN the pass, or the first failing field as the reason
END
```

### A1.3 – Design for damaged data (2 marks)

| Failure | How it is detected | How it is handled |
|:---|:---|:---|
| **Damaged line** (edited by hand, bit flip, wrong field count, blank line, impossible date, invalid UTF-8 bytes) | `DECODE` returns a reason: field count, CRC-32, field validation; the reader decodes bytes with *replace* so invalid bytes become U+FFFD and fail the CRC instead of aborting the scan | The line is **skipped, counted and reported** (`verify()` lists the reason per line); search and listing continue with the next line. The system never "repairs" a record by guessing. |
| **Missing file** | `Files.exists` is false | For reading, the store is treated as empty (find → not found, list → empty). The first `AddPass` creates the file. Any other I/O error (permission, disk) is *not* hidden – it is thrown to the caller. |
| **Incomplete write after a power failure** | The last line has no `\n`, and its CRC / field count fail | Complete records before it stay readable. The next append writes a `\n` first so the half line stays an isolated, reported damaged line instead of corrupting the new record. `repairTail()` may truncate the file after the last `\n`. Each record is written in one write call followed by `force(true)`, which limits the damage to at most one record. Rewriting the whole file (not needed here) would use *write to a temporary file, then atomic rename*. |

The tests that prove each row are T8–T17 in Task B1.1.

### Alternative Concept and Complexity Analysis – fixed-length records in a `RandomAccessFile`

**Solution.** Every record gets the same size, so record *i* starts at byte *i × recordSize*. With a 92-byte record (flag 1 B, passId 8, regNo 9, name 40, route 2, stop 24, validUntil 4, amount 4):

```text
ALGORITHM FindBySeek
INPUT : passId (for example "P000042"), file F
OUTPUT: the pass or "not found"
BEGIN
  1. i ← integer value of passId without the letter P, minus 1       // the id carries the record number
  2. SEEK F to position i × 92
  3. READ 92 bytes into rec
  4. IF rec.flag ≠ 1 THEN RETURN "not found" END IF                  // 0 = deleted / unused
  5. RETURN fields unpacked from rec
END
```

| | Delimited text file (chosen) | Fixed-length `RandomAccessFile` |
|:---|:---|:---|
| Find by pass ID – time | **O(n)** – every line up to the match is read | **O(1)** – one seek and one read, *but only because the id encodes the record number*. With arbitrary ids it needs an index (O(1) average, O(n) memory) or a file sorted by id (binary search, O(log n) seeks). |
| List by route – time | O(n) | O(n) – no better without a route index |
| Extra memory | O(1) – only the read buffer | O(1) |
| Space on disk | exactly the bytes used | n × 92 – every field is padded to its maximum |
| Updates in place | rewrite the file | overwrite one record |
| Variable data | any length (up to the 60-character rule) | names longer than 40 bytes must be rejected or truncated |
| Readable with an editor | yes | no |

**Measured** (`TaskA1/experiments/RandomAccessBench.java`):

| Records (n) | Record size | Average real content | Padding wasted | Fixed-length file | Text file | Find by scan (avg) | Find by seek (avg) |
| ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| 8,000 | 92 B | 46.6 B | 49.3 % | 718 KB | 550 KB | 2.56 ms | 3.09 µs |
| 100,000 | 92 B | 46.6 B | 49.4 % | 8,984 KB | 6,871 KB | 8.30 ms | 2.06 µs |

Table: Table 1 – Fixed-length RandomAccessFile versus the delimited text file


The padding wasted is **49.4 %** of the file (average real content 46.6 bytes of a 92-byte record), so the fixed-length file is *larger* (8,984 KB against 6,871 KB for 100,000 records). In exchange a lookup takes about 2.06 µs instead of 8.30 ms – roughly **4,030 times faster**. The text file stays the choice for the current 8,000 records (a whole scan is a few milliseconds and the file is human-readable and self-checking); the fixed-length layout would become attractive only if the office needs very many lookups and can keep ids sequential.

**Evidence expected – covered:** two record layouts (A1.1), pseudocode for the three operations with justified stream choices (A1.2), and a design for damaged data (A1.3).


## Task A2 – Don't Read What You Don't Need (5 marks, K4 – Analyse)

**Problem.** A program reads a 50 MB attendance log one byte at a time with `FileInputStream.read()` to count its lines.

### A2.1 – Predict the cost (2 marks)

**Number of calls.** 50 MB = 50 × 1,048,576 = 52,428,800 bytes. The program makes one `read()` call per byte and one final call that returns −1:

> **calls = 52,428,800 + 1 = 52,428,801**

**Why it is slow.** `FileInputStream.read()` is not a memory access: every call enters native code and asks the operating system for one byte (a system call – a switch from user mode to kernel mode, a lookup in the kernel's file cache, a copy of a single byte and a switch back). The useful work done with the byte – compare it with `'\n'` and add one – costs a fraction of a nanosecond; the system call costs hundreds of times more. The running time is therefore

> **time ≈ number of calls × cost of one call**

and is dominated by the cost of crossing into the kernel, not by the disk (after the first pass the file is in the operating-system cache anyway).

**Prediction.** If one call costs between 0.2 µs and 1 µs on an ordinary computer, the prediction is **about 10 to 50 seconds** for the 50 MB file, and the time grows in direct proportion to the file size (10 times larger file → about 10 times longer). Task B1.3 compares this prediction with measurements.

### A2.2 – Redesign using buffering (2 marks)

Read a large block into a byte array with one call, then scan the array in memory:

```text
ALGORITHM CountLinesBuffered
INPUT : file F, buffer size B (for example 65,536 bytes)
OUTPUT: number of lines
BEGIN
  1. lines ← 0; last ← '\n'; buffer ← array of B bytes
  2. OPEN F
  3. REPEAT
  4.     n ← READ up to B bytes into buffer           // ONE operating-system call per block
  5.     FOR i ← 0 TO n − 1 DO
  6.         IF buffer[i] = '\n' THEN lines ← lines + 1 END IF
  7.     END FOR
  8.     IF n > 0 THEN last ← buffer[n − 1] END IF
  9. UNTIL n = −1
 10. IF last ≠ '\n' THEN lines ← lines + 1 END IF        // final line without a line break
 11. CLOSE F
 12. RETURN lines
END
```

`BufferedInputStream` (default 8 KiB buffer) or `BufferedReader` give the same effect behind a more convenient API. The scanning work (52 million comparisons) is unchanged; what changes is the **number of calls to the operating system**:

| Design | Calls to the operating system for 50 MB |
|:---|--:|
| unbuffered `read()` | 52,428,801 |
| 8 KiB buffer (`BufferedInputStream`, `byte[8192]`) | 52,428,800 ÷ 8,192 = **6,400** (+1) |
| 64 KiB buffer | 52,428,800 ÷ 65,536 = **800** (+1) |

![Figure 1 – Unbuffered reading calls the operating system once per byte; a buffer calls it once per block](report/figures/d_a2_buffer.png){width=88%}


### A2.3 – When buffering does not help (1 mark)

Buffering gives almost nothing when **the program already reads in large blocks.** `BufferedInputStream` hands a request that is as large as its own buffer straight to the underlying stream, so wrapping a loop that already calls `read(byte[65536])` in another buffer only adds a copy. A second case: **random access.** If a program seeks to a record and reads 92 bytes, a buffer would read thousands of bytes it never uses and throw them away at the next seek – the fixed-length design of Task A1 reads with `RandomAccessFile` directly for this reason.

### Alternative Concept and Complexity Analysis – `Files.readAllLines()`

**Solution.** Read the whole file into a `List<String>` and use its size:

```text
ALGORITHM CountLinesReadAll
INPUT : file F
OUTPUT: number of lines
BEGIN
  1. lines ← READ ALL lines of F into a list                // every line becomes a String object
  2. RETURN size of lines
END
```

| | Buffered stream / block reading | `Files.readAllLines()` |
|:---|:---|:---|
| Time | **O(file size)** – each byte is examined once | **O(file size)** – each byte is read, decoded and copied once, plus one `String` object per line |
| Memory | **O(buffer size)** – a constant 8 KiB to 64 KiB, whatever the file size | **O(file size)** – all lines are alive at the same time; a `String` carries object overhead, so memory is *larger* than the file |
| Code | a loop | one line |
| Appropriate when | the file is large or of unknown size, or the data is processed once as it streams past | the file is small (a few MB), and the program needs *all* lines at once (sorting, random access by line number) |

The measurements for the 50 MB file are in Task B1.3: the block-reading version allocates about 0.100 MB in total, while `readAllLines()` allocates about 95.5 MB – **1.9 times the file size** – and needs a Java heap of at least that size. A file that does not fit in the heap would stop `readAllLines()` with an `OutOfMemoryError`, whereas the streaming version would still run.

**Evidence expected – covered:** a reasoned prediction (A2.1), a redesigned read strategy (A2.2) and a justified limitation (A2.3).


## Task A3 – Discover the Data-Access Design Pattern (5 marks, K4 – Analyse)

**Problem.** `StudentDB`, `CourseDB` and `MarksDB` each open a connection, build an SQL string, execute it, read the `ResultSet` into objects and close the connection. Large parts of the three classes are almost identical.

### A3.1 – Identify the common pattern (2 marks)

![Figure 2 – The six steps repeated in every data-access class (green = identical in all three, yellow = differs per class)](report/figures/d_a3_steps.png){width=88%}


| Step | Repeated in all three? | What differs |
|:---|:---|:---|
| 1. Open the connection | identical | – |
| 2. Build the SQL text | structure identical | the **table name, column names and the `WHERE` clause** |
| 3. Create the statement and bind values | identical idea | **which fields** are bound and in which order |
| 4. Execute | identical | – |
| 5. Read the `ResultSet` into objects | identical loop | **how one row becomes an object** (`Student`, `Course` or `Marks`) |
| 6. Close resources, handle `SQLException` | identical | – |

The pattern is the **Data Access Object (DAO)** with a *template method*: the invariant skeleton (steps 1, 4, 6 and the loop of step 5) is written once; only the parts in yellow (SQL text, parameter binding, row mapping) are supplied by each entity.

### A3.2 – Design a generic data-access interface (2 marks)

![Figure 3 – Generic Dao<T, K> with a shared JdbcDao skeleton and one small class per table](report/figures/d_a3_dao.png){width=88%}


```text
INTERFACE Dao<T, K>                      // T = entity type, K = primary-key type
  insert(T entity)            : void
  findById(K id)              : Optional<T>
  findAll()                   : List<T>
  update(T entity)            : boolean    // true if exactly one row changed
  delete(K id)                : boolean
END INTERFACE
```

```text
ALGORITHM JdbcDao.findById          // written ONCE for every entity
INPUT : id
OUTPUT: the entity, or empty
BEGIN
  1. OPEN connection                                         // try-with-resources: closed automatically
  2. statement ← PREPARE(sqlFindById())                      // supplied by the subclass
  3. SET parameter 1 of statement to id
  4. resultSet ← EXECUTE statement
  5. IF resultSet has a row THEN RETURN Optional(map(resultSet)) // map() supplied by the subclass
  6. RETURN empty
  7. ON SQLException: wrap in an unchecked DataAccessException and rethrow
END
```

**`StudentDao`** supplies only three small pieces:

```text
CLASS StudentDao EXTENDS JdbcDao<Student, String>
  sqlInsert()    ← "INSERT INTO student(reg_no, name, dept, joining_year) VALUES (?, ?, ?, ?)"
  sqlFindById()  ← "SELECT reg_no, name, dept, joining_year FROM student WHERE reg_no = ?"
  bind(statement, s)  ← set parameter 1..4 from s.regNo, s.name, s.dept, s.joiningYear
  map(resultSet)      ← RETURN new Student(rs.reg_no, rs.name, rs.dept, rs.joining_year)
END CLASS
```

`CourseDao` and `MarksDao` are written the same way. The services and the GUI depend only on `Dao<T, K>` and contain no SQL.

### A3.3 – Map objects to tables (1 mark)

| `Student` field (Java) | Column in table `student` | Column type | Constraint |
|:---|:---|:---|:---|
| `String regNo` | `reg_no` | `VARCHAR(12)` | **PRIMARY KEY** |
| `String name` | `name` | `VARCHAR(60)` | NOT NULL |
| `String dept` | `dept` | `VARCHAR(30)` | – |
| `int joiningYear` | `joining_year` | `SMALLINT` | – |

```sql
CREATE TABLE student (
    reg_no        VARCHAR(12) NOT NULL,
    name          VARCHAR(60) NOT NULL,
    dept          VARCHAR(30),
    joining_year  SMALLINT,
    PRIMARY KEY (reg_no)
);
```

One row = one `Student` object; one column = one field; the primary key identifies an object (and is the `K` of `Dao<Student, K>`). Java camelCase names become snake_case column names (`joiningYear` → `joining_year`), and `year` is avoided as a column name because it is a reserved word in SQL.

### Alternative Concept and Complexity Analysis – SQL written directly in the service or GUI classes

**Solution.** Each service or GUI class opens its own connection and writes its own SQL:

```text
ALGORITHM StudentScreen.showStudent(regNo)       // no Dao
BEGIN
  1. OPEN connection
  2. statement ← PREPARE("SELECT reg_no, name, dept FROM student WHERE reg_no = ?")
  3. ... execute, read the row, fill the screen, close ...
END
```

| | Generic `Dao<T, K>` | SQL inside service / GUI classes |
|:---|:---|:---|
| Places that change when the column `dept` is renamed to `department` | **one class** (`StudentDao`; its SQL strings and `map`) | **every class that touches `student`** – each screen, report and service that wrote its own SQL; the compiler finds none of them because the SQL is only text |
| Lines of repeated connection / close code | written once in `JdbcDao` | repeated in every class, each a chance for a leaked connection |
| Changing the database product or adding caching | one place | everywhere |
| Time per database operation | one extra method call (nanoseconds) | none |
| Space per operation | one small `Dao` object, created once and shared | none |

**Time and space.** Both designs send the *same* SQL and make the *same* round trip to the database, so the cost per operation is the same in Big-O terms: **O(1) extra time and O(1) extra space** for the indirection, while the database work (about 59.6 µs per query measured in Task B2) is thousands of times larger than a method call. The Dao design is therefore free in performance and expensive only to *write* once; its benefit is that the number of places to edit on a schema change drops from "all classes that use the table" to **one**.

**Evidence expected – covered:** the repeated pattern (A3.1), a generic data-access design with `StudentDao` (A3.2) and the object–table mapping with primary key (A3.3).


## Task A4 – Persist an Object Graph (4 marks, K4 – Analyse)

**Problem.** A hostel program holds a `Hostel` that contains `Room` objects, each containing `Resident` objects. A `Resident` has a name, a register number, a password and a live database connection. The whole hostel must be saved with one call and restored later.

### A4.1 – Decide what is persisted (2 marks)

![Figure 4 – The object graph of a Hostel; transient fields are left out of the file](report/figures/d_a4_graph.png){width=100%}


| Class / field | Persist? | Reason |
|:---|:---|:---|
| `Hostel.name`, `Hostel.rooms` | yes | the data the program must restore |
| `Room.number`, `Room.residents` | yes | part of the graph |
| `Resident.name`, `Resident.regNo`, `Resident.room` | yes | data; `room` is a back-reference (a cycle) |
| `Resident.password` | **no – `transient`** | a secret must never be written in clear to a file; after reading it is `null` and must be asked for again (or the program stores only a salted hash in the database) |
| `Resident.connection` | **no – `transient`** | a live connection cannot be saved: `Connection` is not `Serializable` (without `transient`, writing fails with `NotSerializableException`), and a connection is meaningless after a restart – it must be re-opened |
| `static` fields | no (automatic) | they belong to the class, not to an object |

**What one `writeObject(hostel)` call writes.** `ObjectOutputStream` writes the object and then, recursively, **everything reachable from it** – the `ArrayList` of rooms, each `Room`, the `ArrayList` of residents, each `Resident`. Three rules follow:

1. **Every class in the graph must implement `Serializable`** (`Hostel`, `Room`, `Resident`; `ArrayList` already does).
2. **An object referenced twice is written once**, and the references are rebuilt on reading. The cycle `Room → Resident → Room` therefore does not loop forever.
3. **`transient` and `static` fields are skipped**; after `readObject` transient fields hold their default value (`null`, `0`, `false`).

```text
ALGORITHM SaveHostel
INPUT : hostel object, file F
BEGIN
  1. OPEN F for writing through an object output stream (buffered)
  2. WRITE the hostel object                  // the whole reachable graph is written
  3. CLOSE F                                  // try-with-resources
END

ALGORITHM LoadHostel
INPUT : file F
OUTPUT: hostel object
BEGIN
  1. OPEN F for reading through an object input stream (buffered)
  2. hostel ← READ one object and cast it to Hostel
  3. FOR EACH resident IN hostel DO
  4.     resident.connection ← open a new database connection      // transient field restored
  5.     resident.password   ← unknown until the user logs in again
  6. END FOR
  7. CLOSE F; RETURN hostel
END
```

**Evidence** (`TaskA4/experiments/SerializationDemo.java`):

```text
1. Graph written with one writeObject(hostel): 407 bytes
   Rooms reachable after reading : 1, residents: 2
   Resident names / regNos       : Arun/192311001, Divya/192311002
   Cycle preserved (resident.room == hostel's room): true
   Original objects are different objects from the copies: true
2. transient fields after reading:  password=null  connection=null   (before writing: password=secret-Arun)
   static field Hostel.instancesCreated was 5 when written, set to 9 before reading: after reading it is 9 (not restored from the file - statics belong to the class)
3. Non-transient connection field -> java.io.NotSerializableException: java.lang.Object
4. Same Room referenced twice in a list: identical after reading = true
```

The whole graph (1 room, 2 residents) occupies 407 bytes; the cycle and the shared object are preserved; the transient password and connection come back as `null`; the non-transient connection throws `NotSerializableException`.

### A4.2 – Plan for change (2 marks)

A `phoneNumber` field is added to `Resident`. Files written by the **old** class must still load.

* **Without `serialVersionUID`** the JVM computes a version number from the shape of the class (fields, methods, modifiers). Adding a field changes the shape, hence the number, and the old file is **rejected** with `InvalidClassException`.
* **With an explicit `serialVersionUID = 1L`** the number does not change. Adding a field is a *compatible* change: the old file loads and the new field receives its default value (`null`).

```text
== Scenario 1: NO serialVersionUID declared ==
serialver (computed by the JVM from the class structure):
   v1: Resident:    private static final long serialVersionUID = -4217321177445906819L;
   v2: Resident:    private static final long serialVersionUID = -8528813912482234793L;
written with class version on class path: Resident[name=Arun, regNo=192311001]
read FAILED -> java.io.InvalidClassException: Resident; local class incompatible: stream classdesc serialVersionUID = -4217321177445906819, local class serialVersionUID = -8528813912482234793

== Scenario 2: serialVersionUID = 1L declared in both versions ==
serialver:
   v1u: Resident:    private static final long serialVersionUID = 1L;
   v2u: Resident:    private static final long serialVersionUID = 1L;
written with class version on class path: Resident[name=Arun, regNo=192311001]
read OK: Resident[name=Arun, regNo=192311001, phone=null]
```

**Plan.** (1) Declare `private static final long serialVersionUID` in every serializable class **from the first version**. (2) Treat changes by compatibility: *adding* fields or methods is compatible; *removing or renaming* a field, *changing its type*, or *changing the class hierarchy* is incompatible and needs a new `serialVersionUID` plus a conversion step. (3) Give new fields a sensible default in `readObject` (for example `""` instead of `null` for `phoneNumber`). (4) Never deserialize files from untrusted sources – deserialization can execute attacker-chosen code paths.

### Alternative Concept and Complexity Analysis – CSV or JSON text instead of Java serialization

```text
ALGORITHM SaveResidentsAsText
INPUT : list of residents, file F, format (CSV line or JSON object)
BEGIN
  1. OPEN F for buffered text writing
  2. FOR EACH resident DO WRITE one line / one object with name, regNo, room number END FOR
  3. CLOSE F
END
// loading: read each line / object, build a Resident, link it to its Room by room number
```

| | Java serialization | CSV / JSON text |
|:---|:---|:---|
| Time to save and load *n* objects | **O(n)** | **O(n)** |
| Space | **O(n)** – class descriptors once, then per-object overhead | **O(n)** – field names repeated per object (JSON) or only values (CSV) |
| Object graph, cycles, shared references | automatic | the programmer must store ids and rebuild links |
| Language / tool independence | Java only, binary | any language, human-readable |
| Adding a field | needs `serialVersionUID` discipline; otherwise old files fail | an old file simply lacks the value: the loader supplies a default |
| Security | deserializing untrusted data is dangerous | parsing text is safe if the parser validates |

**Measured** (`TaskA4/experiments/SerializationBench.java`, 100,000 residents): serialization 3,522 KB, CSV 2,545 KB, JSON 5,475 KB. CSV is smallest; JSON is about 1.6 times the serialized size, because every object repeats its field names; serialization is about 1.4 times larger than CSV. Times for all three grow in proportion to *n*.

| Residents | Format | File size | Save | Load |
| ---: | :--- | ---: | ---: | ---: |
| 1,000 | Java serialization | 35 KB | 2.20 ms | 1.20 ms |
| 1,000 | CSV text | 25 KB | 2.00 ms | 1.30 ms |
| 1,000 | JSON text | 54 KB | 5.00 ms | 1.20 ms |
| 10,000 | Java serialization | 352 KB | 8.70 ms | 20.0 ms |
| 10,000 | CSV text | 254 KB | 6.80 ms | 8.30 ms |
| 10,000 | JSON text | 547 KB | 6.60 ms | 15.5 ms |
| 100,000 | Java serialization | 3,522 KB | 88.6 ms | 129 ms |
| 100,000 | CSV text | 2,545 KB | 50.4 ms | 109 ms |
| 100,000 | JSON text | 5,475 KB | 59.6 ms | 94.1 ms |

Table: Table 2 – Java serialization, CSV and JSON for the same residents


![Figure 5 – File size and save + load time of the three formats](report/figures/fig_a4_formats.png){width=88%}


Java serialization is therefore **not** the smallest or fastest format here; its value is convenience for a complete graph, and its price is version fragility and Java lock-in. Both text loaders in the experiment accepted an *old* file that lacks the new `room` field and filled in a default.

**Evidence expected – covered:** the persisted-field decision with `transient` (A4.1), the compatibility plan with `serialVersionUID` (A4.2).


## Task A5 – Protect Data Integrity (4 marks, K4 – Analyse)

### A5.1 – Design a transaction (2 marks)

**Problem.** Transfer ₹500 from a student's hostel wallet to the canteen wallet using two `UPDATE` statements. If the program stops after the first `UPDATE`, the money has left one wallet and never reached the other.

![Figure 6 – Transfer inside one transaction: both updates become permanent together or not at all](report/figures/d_a5_tx.png){width=58%}


```text
ALGORITHM Transfer
INPUT : regNo, amount
OUTPUT: true if the transfer was done, false if refused
BEGIN
  1. SET auto-commit OFF                                  // begin a transaction
  2. TRY
  3.     rows ← EXECUTE  UPDATE hostel_wallet SET balance = balance − amount
  4.                     WHERE reg_no = regNo AND balance ≥ amount
  5.     IF rows ≠ 1 THEN ROLLBACK; RETURN false END IF   // insufficient funds or unknown account
  6.     rows ← EXECUTE  UPDATE canteen_wallet SET balance = balance + amount WHERE reg_no = regNo
  7.     IF rows ≠ 1 THEN ROLLBACK; RETURN false END IF
  8.     COMMIT                                             // both changes become permanent together
  9.     RETURN true
 10. CATCH any exception
 11.     ROLLBACK                                           // neither change remains
 12.     RE-THROW the exception
 13. FINALLY
 14.     RESTORE the previous auto-commit setting
END
```

* **Atomicity:** `COMMIT` makes both updates permanent; `ROLLBACK` undoes both. Nothing in between is visible after a failure.
* **Check and update in one statement.** `balance ≥ amount` is inside the `UPDATE`, so two simultaneous transfers cannot both pass a separate "check then update" test – the database locks the row while the update runs.
* **Isolation:** the transaction holds its row locks until `COMMIT` or `ROLLBACK` (the default level of MySQL/InnoDB is REPEATABLE READ).

The behaviour is demonstrated by running programs in Task B3.3.

### A5.2 – Analyse an injection vulnerability (2 marks)

**The vulnerable code.**

```text
sql ← "SELECT * FROM users WHERE id='" + id + "' AND pwd='" + pwd + "'"
EXECUTE sql
```

**Example input and the SQL that results** (real output of Task B2):

| Input | SQL text sent to the database | Effect |
|:---|:---|:---|
| `id = admin'#`, `pwd = anything` | `SELECT * FROM users WHERE id='admin'#' AND pwd='anything'` | `#` starts a comment, so the password test disappears: logged in as admin without a password |
| `id = nobody`, `pwd = ' OR '1'='1` | `SELECT * FROM users WHERE id='nobody' AND pwd='' OR '1'='1'` | `AND` binds tighter than `OR`, so the condition is `(…) OR true`: **every row** is returned |

**Why it works.** The user's text is pasted into the *program text of the query*. The quote character the attacker types closes the string literal, and whatever follows is parsed as SQL code. Data has become code.

**Redesign.**

```text
ALGORITHM Login
INPUT : id, pwd
OUTPUT: true if exactly one matching user
BEGIN
  1. statement ← PREPARE "SELECT * FROM users WHERE id = ? AND pwd = ?"      // the SQL text is fixed
  2. SET parameter 1 of statement to id                                       // sent as data
  3. SET parameter 2 of statement to pwd
  4. rows ← EXECUTE statement
  5. RETURN (rows contains one user)
END
```

The structure of the query is fixed before any input is seen; the bound values are always treated as **literal values**, never as SQL, so `' OR '1'='1` is just a password that matches nobody. Further measures: store a salted hash of the password (never the password), connect with a database user that has only the rights the program needs, and never show raw SQL errors to the user.

### Alternative Concept and Complexity Analysis – two separate auto-commit statements

```text
ALGORITHM TransferAutoCommit
BEGIN
  1. EXECUTE UPDATE hostel_wallet  SET balance = balance − amount ...      // committed immediately
  2. EXECUTE UPDATE canteen_wallet SET balance = balance + amount ...      // committed immediately
END
```

| | One transaction | Two auto-commit statements |
|:---|:---|:---|
| Failure between the updates | rollback: balances unchanged | ₹`amount` has vanished (shown in B3.3) |
| Commits (log flushes to disk) | **1** | **2** |
| Time per transfer | O(1): two updates + one commit | O(1): two updates + two commits |
| Locks | held until commit – a few more microseconds | released after each statement |
| Error handling code | `try / catch / finally` with `rollback` | none – and no protection |

Both are **O(1)** in time and space, but the transaction is not slower: one commit is cheaper than two. In Task B3.3 the measured cost is 0.246 ms per transfer in a transaction against 0.330 ms with auto-commit (5,000 transfers each). Auto-commit saves nothing and removes the safety.

**Evidence expected – covered:** a transaction design with commit/rollback (A5.1) and an injection analysis with a PreparedStatement redesign (A5.2).


# PART B – IMPLEMENTATION & EXPERIMENTAL INVESTIGATION (25 marks)

## Task B1 – Build and Validate the File Store (7 marks, K5 – Evaluate)

Files: `TaskB1/PassStore.java` (Complete the Code), `TaskB1/BusPassFileStore.java` (implementation of the Task A1 design), `PassStoreTest`, `LineCounter`, `BuffBench`, `GrowthBench`.

### B1.1 – Implement and validate (2 marks)

`BusPassFileStore` implements the A1 design (escaping, CRC-32, validation, `add`, `find`, `listByRoute`, `verify`, `repairTail`). `PassStoreTest` runs 22 checks and prints one row per check with the expected and the actual value; the program exits with an error code if any check fails.

```text
ID   | Scenario                                                               | Result    
-----+------------------------------------------------------------------------+-----------
T1   | add then find an existing pass (P001003)                               | PASS      
T2   | list all passes on route 12                                            | PASS      
T3   | find a pass id that does not exist                                     | PASS      
T4   | find when the file does not exist                                      | PASS      
T5   | add a pass whose id already exists                                     | PASS      
T6   | add a pass with route 0                                                | PASS      
T7   | name containing | , and \ survives a round trip                        | PASS      
T8   | verify(): lines / valid / damaged                                      | PASS      
T9   | damaged reasons recorded                                               | PASS      
T10  | a valid pass AFTER the damaged lines is still found                    | PASS      
T11  | a pass whose line is damaged (bad crc) is not returned                 | PASS      
T12  | damaged line with matching id is counted as skipped                    | PASS      
T13  | half-written tail is detected (file does not end with newline)         | PASS      
T14  | all complete records before the tail are still readable                | PASS      
T15  | next add is not glued to the half line                                 | PASS      
T16  | repairTail() removes the half line                                     | PASS      
T17  | invalid UTF-8 bytes: scan continues, 2 valid / 1 damaged               | PASS      
C1   | PassStore: find an existing pass                                       | PASS      
C2   | PassStore: find an id that does not exist                              | PASS      
C3   | PassStore: damaged line (2 fields) is skipped, not returned            | PASS      
C4   | PassStore: name with a comma makes a valid pass unfindable             | LIMITATION
C5   | PassStore: a line with a non-numeric amount is accepted as valid       | LIMITATION
```

What the groups of checks prove:

| Checks | Scenario | Result |
|:---|:---|:---|
| T1–T4 | add and find, list by route, unknown id, missing file | normal behaviour is correct |
| T5–T6 | duplicate id, invalid pass (route 0) | rejected **before** anything is written |
| T7 | name containing `\|`, `,` and `\` | stored and read back unchanged |
| T8–T12 | wrong field count, blank line, bad amount, edited line (CRC), impossible date | each damaged line gets its own reason; valid records *after* the damage are still found |
| T13–T16 | half-written last line (simulated power failure) | detected; next `add` is not glued to it; `repairTail()` removes it |
| T17 | invalid UTF-8 bytes inside the file | scan continues, line is counted as damaged |
| C1–C5 | the supplied comma-based `PassStore` | C1–C3 pass; **C4 and C5 are marked LIMITATION** – they show weaknesses of the given design (a name with a comma makes a valid pass unfindable; a non-numeric amount is accepted), discussed in Task B2 |

### B1.2 – Compare the implementation with the design (1 mark)

| Part A design (A1.2 / A1.3) | Implementation | Difference and reason |
|:---|:---|:---|
| `FindPass` step 4: test `line begins with passId + '\|'` before `DECODE` | `line.startsWith(prefix)` then `decode` | Identical behaviour. The pre-check avoids splitting and validating every non-matching line; it is the reason `BusPassFileStore.find` is faster than the supplied `PassStore.find` (Task B1.4). |
| `DECODE` (7 fields + CRC) | `BusPassFileStore.decode` with 11 rejection reasons | Matches. The reasons are an enum so tests and reports can name them. |
| "READ lines (UTF-8)" | `InputStreamReader` with a decoder set to **REPLACE** | The pseudocode does not say what happens to invalid bytes. `Files.newBufferedReader` would throw `MalformedInputException` and abort the whole scan, so the implementation replaces them; the CRC then rejects only that line (test T17). |
| `AddPass` step 4–7: isolate a half-written tail, one write, `force` | `append()` with `FileChannel` (`CREATE, APPEND`) and `force(true)` | Matches (tests T13–T15). |
| Seven fields per record | `BusPassFileStore` stores seven; the **supplied** `PassStore` stores five, comma-separated | The assignment fixes the skeleton, so `PassStore` is completed as asked. It cannot satisfy A1 (no validation, comma delimiter), which is why the design is implemented in a second class and the two are compared. |
| Missing file → empty store | `Files.exists` test in `find` / `listByRoute`; `add` creates the file | Matches (test T4). |

### B1.3 – Measure the effect of buffering (2 marks)

`LineCounter` counts the lines of 64-byte-per-line attendance logs of **1 MB, 10 MB and 50 MB** with five methods (the median of 3–5 runs is shown). It also records the number of read calls and the memory allocated.

| File | Method | OS-level read calls | Time | Memory allocated |
| :--- | :--- | ---: | ---: | ---: |
| 1 MB | unbuffered read() one byte | 1,048,577 | 336 ms | 0 MB |
| 1 MB | BufferedInputStream.read() 8 KiB | 129 | 22.6 ms | 0 MB |
| 1 MB | FileInputStream + byte[8192] | 129 | 0.400 ms | 0 MB |
| 1 MB | FileInputStream + byte[65536] | 17 | 0.400 ms | 0.100 MB |
| 1 MB | BufferedReader.readLine() | 129 | 2.20 ms | 1.70 MB |
| 1 MB | Files.readAllLines() | 129 | 2.70 ms | 1.90 MB |
| 10 MB | unbuffered read() one byte | 10,485,761 | 3.0 s | 0 MB |
| 10 MB | BufferedInputStream.read() 8 KiB | 1,281 | 233 ms | 0 MB |
| 10 MB | FileInputStream + byte[8192] | 1,281 | 4.20 ms | 0 MB |
| 10 MB | FileInputStream + byte[65536] | 161 | 3.90 ms | 0.100 MB |
| 10 MB | BufferedReader.readLine() | 1,281 | 25.7 ms | 16.3 MB |
| 10 MB | Files.readAllLines() | 1,281 | 33.4 ms | 19.1 MB |
| 50 MB | unbuffered read() one byte | 52,428,801 | 15.6 s | 0 MB |
| 50 MB | BufferedInputStream.read() 8 KiB | 6,401 | 1.1 s | 0 MB |
| 50 MB | FileInputStream + byte[8192] | 6,401 | 22.7 ms | 0 MB |
| 50 MB | FileInputStream + byte[65536] | 801 | 32.6 ms | 0.100 MB |
| 50 MB | BufferedReader.readLine() | 6,401 | 55.8 ms | 81.6 MB |
| 50 MB | Files.readAllLines() | 6,401 | 197 ms | 95.5 MB |

Table: Table 3 – Line counting with and without buffering (read calls are counted at operating-system level for buffered methods)


![Figure 7 – Time to count lines (logarithmic scale)](report/figures/fig_b1_3_buffering.png){width=88%}


**Prediction versus measurement (A2.1).**

| | Predicted (A2.1) | Measured |
|:---|:---|:---|
| `read()` calls for 50 MB | 52,428,801 | **52,428,801** (counted by the program) |
| Time for 50 MB | about 10 – 50 s | **15.6 s** (0.30 µs per call) |
| Growth with file size | proportional | 1 MB took 336 ms; the 50 times larger file took 47 times longer |

The prediction of the call count is exact and the time falls inside the predicted range. **Interpretation.** Buffering with a 64 KiB array cut the operating-system calls by a factor of **65,454** (52,428,801 → 801) and the time from 15.6 s to 32.6 ms, a speed-up of about **480×**. `BufferedInputStream` with the *same one-byte `read()` loop* made only 6,401 operating-system calls and took 1.1 s (about 14× faster), but it is still slower than block reading, because each of the 52 million single-byte `read()` calls still passes through a lock-protected Java method. Two costs were being paid: the operating-system call (removed by any buffer) and the per-byte method call (removed only by working on a block). `readAllLines()` was fast but allocated 95.5 MB for a 50 MB file.

### B1.4 – Measure growth (2 marks)

The pass file grows from 1,000 to 100,000 records. For each size the program measures `find` for the first, middle and last record and for an id that is not in the file (median of 11 runs after a JIT warm-up); both the supplied `PassStore` and `BusPassFileStore` are measured.

| Records | File size | PassStore: last (ms) | BusPassFileStore: first (ms) | middle (ms) | last (ms) | not found (ms) |
| ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| 1,000 | 68 KB | 0.158 | 0.077 | 0.118 | 0.147 | 0.098 |
| 5,000 | 343 KB | 0.894 | 0.071 | 0.455 | 0.565 | 0.533 |
| 10,000 | 687 KB | 1.58 | 0.051 | 0.541 | 1.01 | 0.843 |
| 50,000 | 3,436 KB | 7.10 | 0.036 | 3.05 | 4.31 | 4.57 |
| 100,000 | 6,871 KB | 14.5 | 0.062 | 4.29 | 10.8 | 9.02 |

Table: Table 4 – Time of one find (ms) as the file grows


![Figure 8 – Find time against file size (log-log): the scan grows linearly, a HashMap lookup stays flat](report/figures/fig_b1_4_growth.png){width=88%}


**Interpretation.** The time for the last record (the worst case, and also the case of an id that is not present) grows in proportion to the number of records: from 10,000 to 100,000 records (×10) it grows from 1.01 ms to 10.8 ms (×10.7). From 1,000 to 100,000 records the growth is only ×73 instead of ×100, because opening the file costs a fixed amount that dominates the smallest file. This is the **O(n)** behaviour predicted in Task A1: about 108 ns per record. Finding the *first* record takes 0.062 ms even at 100,000 records, so the average depends on where the record is. The supplied `PassStore.find` is about 1.3 times slower than `BusPassFileStore.find`, because it allocates arrays with `split(",")` for every line.

### Complete the Code – `PassStore.find`

TODO 1 is completed; no other line of the program was changed.

```java
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.util.Arrays;
public class PassStore {
    private final Path file;
    PassStore(Path file) { this.file = file; }
    public void add(String passId, String regNo, String name, int route, double amount)
            throws IOException {
        try (BufferedWriter w = Files.newBufferedWriter(file,
                StandardOpenOption.CREATE, StandardOpenOption.APPEND)) {
            w.write(String.join(",", passId, regNo, name,
                    String.valueOf(route), String.valueOf(amount)));
            w.newLine();
        }
    }
    /** Returns the five fields of the pass with the given ID, or null if not found. */
    public String[] find(String passId) throws IOException {
        // TODO 1 (completed): Read the file line by line with a BufferedReader inside try-with-
        // resources; skip damaged lines (not exactly 5 fields); return the fields of
        // the matching pass
        try (BufferedReader r = Files.newBufferedReader(file)) {
            String line;
            while ((line = r.readLine()) != null) {
                String[] f = line.split(",", -1);   // -1 keeps trailing empty fields, so the count is exact
                if (f.length != 5) {
                    continue;                       // damaged line: skip it and keep searching
                }
                if (f[0].equals(passId)) {
                    return f;                       // first matching pass wins
                }
            }
        }
        return null;
    }
    public static void main(String[] args) throws IOException {
        Path f = Files.createTempFile("passes", ".csv");
        PassStore store = new PassStore(f);
        store.add("P1001", "192311001", "Arun", 12, 4500);
        Files.writeString(f, "P1002,DAMAGED LINE\n",
                StandardOpenOption.APPEND);
        store.add("P1003", "192311003", "Divya", 7, 3800);
        System.out.println(Arrays.toString(store.find("P1003")));
        System.out.println(Arrays.toString(store.find("P1002")));
        Files.delete(f);
    }
}
```

Output of the unchanged `main`:

```text
[P1003, 192311003, Divya, 7, 3800.0]
null
```

**Why a damaged line cannot stop the search.** `split(",", -1)` never throws, so a damaged line only produces an array whose length is not 5. The `continue` statement jumps to the next iteration of the `while` loop, so the loop keeps reading until a line with five fields *and* the requested id is found, or until the end of the file. The limit `-1` keeps trailing empty fields, so a line such as `P1,x,y,,` is counted as five fields instead of three. The `try-with-resources` block closes the reader in every case, including when `readLine` throws an exception.

### Alternative Concept and Complexity Analysis – read the file once into a `HashMap`

```text
ALGORITHM LoadIndex
INPUT : file F
OUTPUT: map from passId to pass
BEGIN
  1. map ← empty hash map
  2. FOR EACH valid line of F DO map[passId] ← pass END FOR      // one pass over the file
  3. RETURN map
END

ALGORITHM FindInMap(map, passId)
BEGIN  RETURN map[passId]  END                                    // O(1) on average
```

| | Scan the file for every search | Load once into a `HashMap` |
|:---|:---|:---|
| Time for *q* searches | **O(q · n)** | **O(n + q)** |
| Memory | **O(1)** (a read buffer) | **O(n)** – every record is a set of objects in the heap |
| Freshness | always sees the file as it is | goes stale if another program changes the file |

| Records (n) | Searches (q) | q scans of the file | Read once into HashMap (build) | q lookups | HashMap total | Heap used by map |
| ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| 1,000 | 100 | 23.2 ms | 2.00 ms | 0.04 ms | 2.10 ms | 0 MB |
| 5,000 | 100 | 94.0 ms | 1.80 ms | 0.04 ms | 1.80 ms | 1.00 MB |
| 10,000 | 100 | 123 ms | 10.0 ms | 0.03 ms | 10.0 ms | 1.90 MB |
| 50,000 | 100 | 377 ms | 38.3 ms | 0.04 ms | 38.4 ms | 16.1 MB |
| 100,000 | 100 | 743 ms | 183 ms | 0.08 ms | 183 ms | 30.4 MB |

Table: Table 5 – q = 100 searches: scanning the file every time versus a HashMap


At 100,000 records, 100 scans took 743 ms; loading the map once and doing 100 lookups took 183 ms (183 ms of it is the one-time load), so the map is about **4.1 times faster** already for 100 searches and the advantage grows with every further search. The price is memory: the map used about **30.4 MB** of heap for a 6.71 MB file (4.5 times the file size). For a process that answers many lookups the map pays off; for a one-off lookup, or a file that other programs change, scanning is simpler and safer – and neither remains adequate for several programs working on 800,000 records (Task B4).


## Task B2 – Attack Your Own Program (5 marks, K5 – Evaluate)

All attacks run against the **local test database `transport_test`**, created by `db/setup_mysql_user.sql` only for this assignment, with made-up test users and passwords. Nothing here touches any real system.

### B2.1 – SQL injection against the login check

`LoginDemo` runs six inputs through the unsafe concatenation of Task A5.2 and through the `PreparedStatement` redesign.

```text
Database: MariaDB 10.11.14-MariaDB-0ubuntu0.24.04.1  |  driver: MariaDB Connector/J 2.7.6
Input case (id / password)         | UNSAFE (concatenation) | SAFE (PreparedStatement)
-----------------------------------+------------------------+-------------------------
1  valid student                   | ACCEPT (1 row)         | ACCEPT (1 row)        
2  wrong password                  | REJECT                 | REJECT                
3  comment trick on id             | ACCEPT (1 row)         | REJECT                
4  always-true password            | ACCEPT (3 rows)        | REJECT                
5  always-true id                  | ACCEPT (3 rows)        | REJECT                
6  UNION forges a row              | ACCEPT (1 row)         | REJECT                
```

The SQL text that the unsafe version really sent:

| Case | id / password | SQL sent to the database |
|:---|:---|:---|
| 3 | `admin'#` / `anything` | `… WHERE id='admin'#' AND pwd='anything'` |
| 4 | `nobody` / `' OR '1'='1` | `… WHERE id='nobody' AND pwd='' OR '1'='1'` |
| 5 | `' OR 1=1 #` / `x` | `… WHERE id='' OR 1=1 #' AND pwd='x'` |
| 6 | `x' UNION SELECT 'admin','x','ADMIN'#` / `x` | `… WHERE id='x' UNION SELECT 'admin','x','ADMIN'#' AND pwd='x'` |

**What each case reveals.** Case 3: the input ends the string and a comment removes the password test – *authentication bypass*. Cases 4 and 5: an always-true condition returns every user (three rows) – the program accepts it because "at least one row" means "logged in". Case 6: `UNION` lets the attacker *invent* a user row that never existed. The `PreparedStatement` version rejects all of them, because the bound text is compared as a literal value.

**Stacked statements (case 7).** `x'; DROP TABLE users; #` tests whether the attacker can run a second command:

| Driver setting | Result |
|:---|:---|
| `allowMultiQueries=false` (normal) | the statement is refused; the `users` table keeps its 3 rows |
| `allowMultiQueries=true` | the `DROP TABLE` **is executed**; the table is gone (the program re-creates it afterwards) |

During development of this demo, an early version used a connection URL that contained `rewriteBatchedStatements=true` (needed for fast batches in Task B3); with this MariaDB driver the stacked `DROP TABLE` was then executed and destroyed the test table. The final demo therefore sets `allowMultiQueries` explicitly. The lesson is that **a driver option chosen for performance can silently widen the attack surface** – whether a given driver allows several statements per call depends on its settings and should be checked in its documentation – and that the real defence is not relying on such a setting at all but using `PreparedStatement`.

### B2.2 – Damaged and hostile data files

`BadFileDemo` writes eight deliberately bad inputs and feeds them to the supplied `PassStore` and to the A1 `BusPassFileStore`:

```text
Adversarial input                  | PassStore (given) find() returns             | BusPassFileStore (A1 design)
-----------------------------------+----------------------------------------------+-------------------------------
1  valid record                    | [P5001, 192311001, Arun, 12, 4500.0]         | accepted
2  too FEW fields                  | null                                         | REJECTED: WRONG_FIELD_COUNT
3  too MANY fields                 | null                                         | REJECTED: WRONG_FIELD_COUNT
4  non-numeric amount              | [P5004, 192311004, Meena, 5, abc]            | REJECTED: BAD_AMOUNT
5  empty line                      | (no id to search for)                        | REJECTED: EMPTY_LINE
6  negative amount                 | [P5006, 192311006, Ravi, 6, -4500]           | REJECTED: BAD_AMOUNT
7  name contains the delimiter     | null                                         | accepted
8  one character changed by hand   | [P5008, 192311008, Sneha, 9, 9999.0]         | REJECTED: CRC_MISMATCH

BusPassFileStore.verify() of the same file: lines=8 valid=2 damaged=6 endsWithNewline=true {EMPTY_LINE=1, WRONG_FIELD_COUNT=2, CRC_MISMATCH=1, BAD_AMOUNT=2}
(The record in case 7 is VALID and is accepted; PassStore loses it because its comma splits the name.)
```

| Input | What `PassStore` (field-count check only) does | What it reveals |
|:---|:---|:---|
| 2, 3 too few / too many fields | skips them | the field count is the *only* defence – it works for these two |
| 4 `abc` as amount | **accepts** the record and returns `abc` as an amount | right *shape*, wrong *meaning*; the failure appears later, far from the cause |
| 5 empty line | skipped (one field) | harmless here, but only by accident |
| 6 negative amount | **accepts** `-4500` | no value validation at all |
| 7 name `Kumar, Arun` | **loses a valid record** (six fields) | the delimiter may occur inside data; the format has no escaping |
| 8 one digit changed (4200 → 9999) | **accepts the tampered value** | no integrity check: a silent edit looks identical to a genuine record |

`BusPassFileStore` rejects 2–6 and 8 with a named reason and accepts the valid record 7, which is what the A1 design (field validation, escaping and CRC) promised.

### B2.3 – Reflection

* **Concatenation turns data into code.** The vulnerability is in how the SQL text is *built*, not in the database. The fix – parameters – changes the structure of the program, not the validation of the input.
* **Shape is not meaning.** Counting fields, the only check of the supplied `PassStore`, passes records whose content is nonsense. Each field needs its own validation and the line needs an integrity check.
* **Defence in depth.** Parameters, field validation, least-privilege database accounts, hashed passwords and a driver configured without multi-statement execution all matter; no single one is enough.

### Alternative Concept and Complexity Analysis – escape the quotes or validate with a regular expression

```text
ALGORITHM LoginByEscaping
BEGIN
  1. IF id or pwd does not match the pattern [A-Za-z0-9 ]+ THEN REJECT END IF       // whitelist
  2. sql ← "SELECT * FROM users WHERE id='" + ESCAPE(id) + "' AND pwd='" + ESCAPE(pwd) + "'"
  3. EXECUTE sql
END       // ESCAPE doubles every ' and every \
```

**It is not sufficient.** `EscapingWeakness` builds a numeric query, where there are no quotes to escape:

```text
SELECT pass_id FROM bus_pass WHERE route_no = <input>        input: 7 OR 1
```

The input `7 OR 1` contains only letters, digits and spaces, so it **passes the whitelist**; escaping changes nothing; and the query returns **all 100 passes instead of the 1 on route 7**. A parameter would have turned the text `7 OR 1` into an integer conversion error before any SQL was built. Escaping depends on knowing the quoting context, the character set and every special character of one database product; a regular expression that is strict enough to be safe also rejects legitimate input (a name like *O'Brien*), and one that is loose enough to be usable lets payloads through.

**Cost.**

| | Time | Space |
|:---|:---|:---|
| Regular-expression check on a string of length *m* | O(m) | O(1) |
| Escaping | O(m) | O(m) – new string |
| `PreparedStatement` parameter binding | O(m) – the value is copied once | O(m) |

| Operation | Repetitions | Total time | Time per operation |
| :--- | ---: | ---: | ---: |
| regex validation only | 1,000,000 | 167 ms | 0.17 µs |
| regex + escaping + Statement query | 5,000 | 434 ms | 86.81 µs |
| PreparedStatement query | 5,000 | 298 ms | 59.58 µs |

Table: Table 6 – Cost of validation compared with the database round trip


The validation costs 0.167 µs; a database query costs about 59.6 µs, so the check is 0.28 % of one query. **Performance is therefore not a reason to avoid `PreparedStatement`**: both are O(m) in the length of the input, and the database round trip dominates either way. Only the `PreparedStatement` is also *correct*.


## Task B3 – Insert Data Three Ways (8 marks, K5 – Evaluate)

Files: `TaskB3/PassLoader.java` (Complete the Code), `SmallCorrectness`, `LoadBench`, `TransactionDemo`, `InsertStrategies`. The table is `bus_pass(pass_id PK, reg_no, name, route_no, boarding_stop, valid_until, amount)` with an index on `route_no` (`db/schema.sql`).

### B3.1 – Small-scale correctness (2 marks)

Ten records are inserted with a `Statement` (SQL built by concatenation, quotes escaped), with a `PreparedStatement` executed per row, and with a `PreparedStatement` batch. After each approach the table is read back with `SELECT` and compared with the ten generated records; the column names and types come from `ResultSetMetaData`.

```text
Approach 1: Statement
   rows in table: 10   equal to the 10 generated records: true
Approach 2: PreparedStatement
   rows in table: 10   equal to the 10 generated records: true
Approach 3: PreparedStatement + batch
   executeBatch() reported 10 of 10 statements successful
   ResultSetMetaData of SELECT * FROM bus_pass:
   #   column         SQL type   precision  nullable 
   1   pass_id        VARCHAR    10         NO       
   2   reg_no         VARCHAR    12         NO       
   3   name           VARCHAR    60         NO       
   4   route_no       INTEGER    11         NO       
   5   boarding_stop  VARCHAR    40         YES      
   6   valid_until    DATE       10         YES      
   7   amount         DECIMAL    10         NO       
   rows in table: 10   equal to the 10 generated records: true

All three approaches produce identical table contents: true
Table contents (from the last approach):
   P000001|192000037|Vignesh Iyer|23|4150.00
   P000002|192000074|Meena Kumar|17|3850.00
   P000003|192000111|Divya Reddy|30|4500.00
```

All three approaches produce **identical table contents**, equal to the generated data, with the expected column types (`VARCHAR`, `INT`, `DECIMAL(10,2)`).

### B3.2 – Time the three approaches (3 marks)

1,000, 10,000 and 100,000 passes are inserted into an empty table. The three required measurements use JDBC's default **auto-commit ON**; as an additional experiment the same three approaches are repeated inside **one transaction**, to separate the effect of *how the SQL is sent* from the effect of *how often the database commits*. Times of the fast cases are medians of three runs.

| Rows | Approach | Auto-commit: time | rows/s | One transaction: time | rows/s |
| ---: | :--- | ---: | ---: | ---: | ---: |
| 1,000 | Statement | 167 ms | 5,992 | 37.3 ms | 26,839 |
| 1,000 | PreparedStatement | 146 ms | 6,840 | 44.2 ms | 22,648 |
| 1,000 | PreparedStatement + batch | 11.7 ms | 85,550 | 8.20 ms | 121,489 |
| 10,000 | Statement | 1.4 s | 7,264 | 281 ms | 35,567 |
| 10,000 | PreparedStatement | 1.3 s | 7,501 | 263 ms | 38,024 |
| 10,000 | PreparedStatement + batch | 91.9 ms | 108,802 | 71.0 ms | 140,839 |
| 100,000 | Statement | 14.0 s | 7,140 | 2.3 s | 43,509 |
| 100,000 | PreparedStatement | 12.8 s | 7,809 | 2.3 s | 43,836 |
| 100,000 | PreparedStatement + batch | 625 ms | 160,028 | 565 ms | 176,942 |

Table: Table 7 – Insert time for Statement, PreparedStatement and batch


![Figure 9 – Total insert time (logarithmic scale)](report/figures/fig_b3_2_inserts.png){width=88%}


**Interpretation.**

1. **Commit frequency is the biggest factor.** With auto-commit every row is its own transaction: the database must write its log to disk for *each* row. For 100,000 rows a `Statement` took 14.0 s (7,140 rows/s, 0.140 ms per row). Putting the same statements into one transaction took 2.3 s, **6.1 times faster**, without changing a line of SQL.
2. **`Statement` and `PreparedStatement` are equally fast here** (14.0 s against 12.8 s; ratio 1.09). Executed one row at a time, both still make one round trip per row, so the `PreparedStatement` gains nothing in speed here. It is chosen for **safety** (Task B2); a speed advantage can appear when the server reuses a compiled statement many times, which this experiment does not measure.
3. **Batching removes the per-row round trip.** The batch took 625 ms (160,026 rows/s), **22 times faster than `Statement`** with auto-commit; the driver sends 1,000 rows at a time. It is also 4.1 times faster than the per-row approaches even when they are inside a transaction (565 ms against 2.3 s).
4. **The same advantage appears at every size.** At 1,000 rows the batch was already 14 times faster than `Statement` with auto-commit, so the result does not depend on the amount of data.

*Driver note.* With MySQL Connector/J the same effect needs the URL option `rewriteBatchedStatements=true` (set in the default URL of `Db.java`); the reference run used the MariaDB driver listed in the introduction, which batches by default. Absolute numbers on another computer will differ; the order of the three approaches should not.

### B3.3 – Break it on purpose (2 marks)

**Part 1 – a failure in the middle of a load.** A list of 5,000 passes contains a bad row half-way: either a non-numeric amount at row 2,501 (rejected by the program) or a duplicate pass id at row 3,001 (rejected by the database). The load is run with auto-commit ON and with `PassLoader.loadAll`, which uses one transaction.

| Scenario | Mode | Exception | Rows left in table |
| :--- | :--- | :--- | ---: |
| invalid amount at row 2,501 | batch, auto-commit ON | NumberFormatException | 2000 |
| invalid amount at row 2,501 | PassLoader.loadAll (transaction) | NumberFormatException | 0 |
| duplicate pass id at row 3,001 | batch, auto-commit ON | BatchUpdateException | 3000 |
| duplicate pass id at row 3,001 | PassLoader.loadAll (transaction) | BatchUpdateException | 0 |

Table: Table 8 – Rows left in bus_pass after a failed load


With auto-commit, rows already sent stay in the table – **2000 rows** after the invalid amount and **3000 rows** after the duplicate id – a half-finished load that nobody asked for. With the transaction, `rollback()` removes everything: **0 rows** remain in both cases, and the original exception is re-thrown to the caller.

**Part 2 – the wallet transfer of Task A5.1.** ₹500 is moved from the hostel wallet to the canteen wallet; a simulated crash is thrown between the two `UPDATE`s.

```text
PART 2 - transfer Rs 500 from hostel wallet to canteen wallet (account 192311001)
start                                   : hostel=2000.00 canteen=100.00 total=2100.00
   crash: simulated power failure between the two updates
auto-commit, crash between updates      : hostel=1500.00 canteen=100.00 total=1600.00   <-- Rs 500 has vanished
   crash: simulated power failure between the two updates
transaction, crash between updates      : hostel=2000.00 canteen=100.00 total=2100.00   <-- rolled back, nothing lost
transaction, no failure (returned true)  : hostel=1500.00 canteen=600.00 total=2100.00
transaction, insufficient funds (returned false): hostel=2000.00 canteen=100.00 total=2100.00   <-- refused, unchanged
```

Without a transaction the crash leaves **₹500 missing** (total 2,100 → 1,600): debited, never credited. With the transaction the balances are exactly as before. The last two lines show the normal success path and the refusal of an impossible transfer (₹5,000 from a wallet holding ₹2,000), which also changes nothing.

**Part 3 – is safety expensive?** 5,000 transfers of two `UPDATE`s each:

| Mode | Transfers | Total time | Per transfer |
| :--- | ---: | ---: | ---: |
| auto-commit (2 commits) | 5,000 | 1.7 s | 0.330 ms |
| transaction (1 commit) | 5,000 | 1.2 s | 0.246 ms |

Table: Table 9 – Cost of a transfer with auto-commit and with a transaction


The transaction is **1.34 times faster** per transfer than two auto-commit statements, because it needs one commit instead of two.

### B3.4 – Engineering trade-off (1 mark)

| Situation | Choice | Reason |
|:---|:---|:---|
| **Nightly import of 100,000 passes** | validated rows → `PreparedStatement` **batch inside one transaction** (as in `PassLoader`) | measured 565 ms for 100,000 rows against 14.0 s with the naive approach; a failure leaves the table untouched; parameters keep the import injection-safe; rejected rows can be reported (Task B4.1). `LOAD DATA` is faster still, but needs a file on the client, a server privilege and gives poorer per-row error reports – suitable for trusted bulk loads. |
| **A counter issuing one pass for one student** | one `PreparedStatement` insert, auto-commit (or one tiny transaction if more tables are touched) | a batch cannot help with one row; the 0.140 ms of one auto-committed insert is invisible to the user; what matters is **immediate success/failure feedback** (duplicate pass, invalid amount) and parameter binding against injection. |

### Complete the Code – `PassLoader.loadAll`

TODO 1, 2 and 3 are completed; the rest of the class is unchanged.

```java
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;
public class PassLoader {
    /** Loads all passes in one transaction, in batches of 1,000 rows.
     * Returns the number of rows loaded. */
    public static int loadAll(Connection con, List<String[]> passes)
            throws SQLException {
        String sql = "INSERT INTO bus_pass(pass_id, reg_no, name, route_no, amount) "
                + "VALUES (?, ?, ?, ?, ?)";
        boolean oldAutoCommit = con.getAutoCommit();
        con.setAutoCommit(false);
        try (PreparedStatement ps = con.prepareStatement(sql)) {
            int n = 0;
            for (String[] p : passes) {
                // TODO 1 (completed): Set the five parameters from p (route as int, amount as
                // double), add the row to the batch, and execute the batch after every
                // 1,000 rows
                ps.setString(1, p[0]);
                ps.setString(2, p[1]);
                ps.setString(3, p[2]);
                ps.setInt(4, Integer.parseInt(p[3]));          // route as int  (NumberFormatException if invalid)
                ps.setDouble(5, Double.parseDouble(p[4]));     // amount as double
                ps.addBatch();
                n++;
                if (n % 1000 == 0) {
                    ps.executeBatch();                         // send a full batch of 1,000 rows
                }
            }
            ps.executeBatch();
            // TODO 2 (completed): Make all inserted rows permanent and return the number of rows
            // loaded
            con.commit();
            return n;
        } catch (SQLException | RuntimeException e) {
            // TODO 3 (completed): Undo every insert made in this transaction, then re-throw the
            // exception
            try {
                con.rollback();                                // nothing from this call stays in the table
            } catch (SQLException rollbackFailure) {
                e.addSuppressed(rollbackFailure);              // keep the original error as the main one
            }
            throw e;
        } finally {
            con.setAutoCommit(oldAutoCommit);
        }
    }
}
```

**Why this is correct.** The batch is sent after every 1,000 rows and once more at the end for the remainder; nothing is visible to other connections until `commit()`. Every failure – a `SQLException` from the database or a `RuntimeException` such as the `NumberFormatException` for an amount like `12x0` – reaches the `catch` block, where `rollback()` undoes all inserts of the call; if the rollback itself fails, that error is attached with `addSuppressed` so the original cause is not lost. `finally` restores the caller's auto-commit setting in all cases. Part 1 of B3.3 is the proof: **0 rows** remain after a failure half-way.

### Alternative Concept and Complexity Analysis – multi-row `INSERT` and `LOAD DATA`

```text
ALGORITHM InsertMultiRow
INPUT : rows, rows per statement b
BEGIN
  1. SET auto-commit OFF
  2. FOR EACH group of b rows DO
  3.     build one statement "INSERT … VALUES (?,?,?,?,?),(?,?,?,?,?), …" with b groups of placeholders
  4.     bind 5·b parameters; EXECUTE
  5. END FOR
  6. COMMIT
END

ALGORITHM LoadData
BEGIN  write all rows to a delimited file; EXECUTE "LOAD DATA LOCAL INFILE … INTO TABLE bus_pass"; COMMIT  END
```

| | Batch of *b* prepared rows | Multi-row `INSERT` of *b* rows | `LOAD DATA` |
|:---|:---|:---|:---|
| Time for *n* rows | **O(n)** with n/b round trips | **O(n)** with n/b round trips | **O(n)**, one statement, one data stream |
| Memory held at a time | **O(b)** rows buffered by the driver | **O(b)** – one long SQL text with 5·b parameters | **O(1)** – the server streams the file |
| Validation / error reports per row | good (each row is bound and checked in Java) | the whole statement fails for one bad row | poor – the server skips or aborts |
| Needs | nothing special | a limit on statement size (`max_allowed_packet`) | file access, `local_infile`, privileges |

| Method | Rows | Rows per statement/batch (b) | Time | Memory allocated |
| :--- | ---: | ---: | ---: | ---: |
| PreparedStatement batch | 100,000 | 100 | 808 ms | 60.8 MB |
| PreparedStatement batch | 100,000 | 1000 | 708 ms | 74.0 MB |
| PreparedStatement batch | 100,000 | 10000 | 654 ms | 72.1 MB |
| multi-row INSERT | 100,000 | 100 | 1.2 s | 82.9 MB |
| multi-row INSERT | 100,000 | 1000 | 588 ms | 94.3 MB |
| multi-row INSERT | 100,000 | 10000 | 566 ms | 92.3 MB |
| LOAD DATA LOCAL INFILE | 100,000 | - | 497 ms | 78.0 MB |

Table: Table 10 – 100,000 rows: batch, multi-row INSERT and LOAD DATA (memory = total bytes allocated by the Java thread during the run)


![Figure 10 – Time to insert 100,000 rows with each strategy](report/figures/fig_b3_alt.png){width=88%}


At *b* = 1,000, the batch took 708 ms, the multi-row insert 588 ms and `LOAD DATA` 497 ms. All are within a small factor of each other and **all are tens of times faster than inserting row by row** with auto-commit (14.0 s). Making a batch larger helps up to a point (the round-trip count drops) while the memory held per batch grows in direct proportion to *b*; around 1,000 rows per batch is a sensible balance. The "memory" column is the total allocated during the whole run, which includes garbage that is collected; the peak held at one time is proportional to *b* only.


## Task B4 – Migrate and Decide (5 marks, K5 – Evaluate)

### B4.1 – Migrate the text file into the database (2 marks)

`Migrate` reads the pass file in the A1 format, validates **every line** with the same `decode` method as the file store, rejects duplicate pass ids found in the file, and loads the valid rows with a `PreparedStatement` batch (1,000 rows per batch) inside **one transaction**: any database failure rolls the migration back and leaves the table empty. Every rejected line is written to a report with its line number and reason.

```text
ALGORITHM Migrate
INPUT : text file F
OUTPUT: rows in bus_pass, report of rejected lines
BEGIN
  1. SET auto-commit OFF;  seen ← empty set
  2. FOR EACH line (with its line number) of F DO
  3.     d ← DECODE(line)
  4.     IF d is invalid THEN WRITE line number, reason, text TO report; CONTINUE END IF
  5.     IF d.passId IN seen THEN WRITE line number, "DUPLICATE_PASS_ID" TO report; CONTINUE END IF
  6.     ADD d.passId TO seen;  ADD d TO the current batch
  7.     IF the batch has 1,000 rows THEN EXECUTE the batch END IF
  8. END FOR
  9. EXECUTE the last partial batch;  COMMIT
 10. ON any exception: ROLLBACK, report "migration aborted", RE-THROW
 11. VERIFY: SELECT COUNT(*) equals the number of rows loaded
END
```

**Test data with a known answer.** `GenerateMigrationData` creates a 100,000-pass file and injects **exactly 100 defects**: 20 lines with the wrong number of fields, 20 with a non-numeric amount, 20 edited by hand (CRC), 20 blank lines and 20 duplicate pass ids. The expected result is therefore 99,940 rows loaded and 100 lines rejected.

```text
Created work/legacy_passes.txt  (6871 KB)
Injected defects: wrong field count=20, non-numeric amount=20, edited by hand (CRC)=20, empty lines=20, duplicate pass ids=20
Expected migration result: loaded=99940 rejected=100
```

```text
Lines read      : 100040
Loaded          : 99940  (rows in bus_pass afterwards: 99940 -> match)
Rejected        : 100
   EMPTY_LINE         20
   WRONG_FIELD_COUNT  20
   CRC_MISMATCH       20
   BAD_AMOUNT         20
   DUPLICATE_PASS_ID  20
Time            : 4.22 s  (23705 lines/s)
Full list of rejected lines: results/B4_1_migration_report.txt
```

The migration loaded **99,940** rows from 100,040 lines in 4.22 s, rejected **100** lines – exactly 20 of each kind of defect – and the row count in the table matches. The start of the report file:

```text
MIGRATION REPORT  source=legacy_passes.txt  target=bus_pass
line | reason | text
1004 | WRONG_FIELD_COUNT | P001004|192037148|Arun Reddy
1506 | BAD_AMOUNT | P001506|192055722|Arun Babu|35|Sholinganallur|2027-03-31|abc|660cf20d
2008 | CRC_MISMATCH | P002008|192074296|Bharath Devi|18|Vadapalani|2027-03-31|3850.00|b800d4...
5001 | EMPTY_LINE | 
5005 | WRONG_FIELD_COUNT | P005004|192085148|Sneha Nair
5507 | BAD_AMOUNT | P005506|192003722|Naveen Devi|12|Ambattur|2027-03-31|abc|a52a7b8c
6009 | CRC_MISMATCH | P006008|192022296|Arun Sharma|34|Avadi|2027-03-31|4650.00|a03cf2ba
9005 | WRONG_FIELD_COUNT | P009004|192033148|Suresh Nair
```

### B4.2 – Report what you are connected to (1 mark)

`DbInfo` uses `DatabaseMetaData` to print the database product and version, the driver, supported features, the isolation level, the tables and the columns and primary key of `bus_pass`:

```text
Database product      : MariaDB 10.11.14-MariaDB-0ubuntu0.24.04.1
Driver                : MariaDB Connector/J 2.7.6
JDBC spec             : 4.2
URL / user            : jdbc:mariadb://localhost:3306/transport_test?rewriteBatchedStatements=true / transport
Transactions supported: true   default isolation: REPEATABLE_READ
Batch updates         : true
Identifier case       : stores lower=false mixed=false
Max connections       : 0 (0 = no fixed limit reported)
Catalog (database)    : transport_test
Tables present:
   bus_pass
   canteen_wallet
   hostel_wallet
   pass_issue
   users
Columns of bus_pass:
   pass_id        VARCHAR    size=10   nullable=NO
   reg_no         VARCHAR    size=12   nullable=NO
   name           VARCHAR    size=60   nullable=NO
   route_no       INT        size=10   nullable=NO
   boarding_stop  VARCHAR    size=40   nullable=YES
   valid_until    DATE       size=10   nullable=YES
   amount         DECIMAL    size=10   nullable=NO
Primary key of bus_pass:
   pass_id (key PRIMARY)
```

**Why this matters in practice.** Code that runs on a laboratory MySQL server today may run on a different product or version tomorrow. The metadata lets the program (a) refuse to start, or log a warning, when the server or driver version is not the one it was tested with; (b) check capabilities before relying on them – `supportsTransactions()` before using `commit/rollback`, `supportsBatchUpdates()` before batching; (c) learn the default **isolation level** that the concurrency behaviour depends on; (d) adapt to naming rules such as identifier case; and (e) verify after a migration that the expected tables, columns and primary key really exist. The program prints MySQL's own name and version when it runs against MySQL.

### B4.3 – The production decision (2 marks)

**The requirement.** The pass system grows to **12 campuses × about 8,000 passes a year ≈ 100 times the present load; 800,000 passes** over the retention period, issued at several counters at the same time. Three designs are compared with measurements: **A** one shared text file, **B** twelve serialized files (one per campus), **C** one shared database table (primary key on `pass_id`, index on `route_no`).

![Figure 11 – Recommended architecture: all campuses use one service and one MySQL database](report/figures/d_b4_arch.png){width=88%}


**Search at 800,000 passes.**

| Design | Operation | Time | Size |
| :--- | :--- | ---: | ---: |
| A. one shared text file | write all 800000 passes | 1.8 s | 53.7 MB |
| A. one shared text file | find one pass (near the end) | 99.4 ms |  |
| A. one shared text file | find one pass (average of 20 random) | 41.6 ms |  |
| B. 12 serialized campus files | save 12 files (about 66,667 passes each) | 3.4 s | 90.1 MB |
| B. 12 serialized campus files | find one pass, campus unknown (worst case) | 2.8 s |  |
| B. 12 serialized campus files | load ONE campus file (campus known) | 106 ms |  |
| C. shared database table | load all 800000 passes (1 transaction, batches of 1,000) | 7.2 s | 75.1 MB |
| C. shared database table | find one pass by primary key (average of 20000) | 0.060 ms |  |
| C. shared database table | count passes on one route (indexed, average of 40) | 4.94 ms |  |
| A. one shared text file | list passes on one route (full scan) | 3.1 s |  |

Table: Table 11 – Cost of the three designs for 800,000 passes


![Figure 12 – Time to find one pass (logarithmic scale)](report/figures/fig_b4_3_scale.png){width=88%}


* **A. One text file:** a lookup takes about 41.6 ms on average (99.4 ms near the end) – **24 lookups per second** for the whole system at best, because each lookup reads the file; listing one route takes 3.1 s.
* **B. Twelve serialized files:** if the campus of a pass is unknown, up to twelve files must be loaded one after another – 2.8 s in the worst case; even a known campus costs 106 ms just to load its file, and **every change means rewriting that whole file**. Space: 90.1 MB against 53.7 MB for the text file.
* **C. Database:** a primary-key lookup takes about **60 µs**, about 694 times faster than scanning the text file and 46,225 times faster than searching the serialized files; a route count takes 4.94 ms through the index (against 3.1 s for the file). The table uses 75.1 MB including its indexes; loading all 800,000 rows took 7.2 s once.

**Concurrent counters.** Eight counters (threads) all try to issue the same 250 pass ids – a rush at the start of the semester – under the rule "a pass id is issued once".

| Design | Trial | Rows stored | Expected | Duplicates | Time |
| :--- | ---: | ---: | ---: | ---: | ---: |
| A. text file, check-then-append, NO lock | 1 | 282 | 250 | 32 | 929 ms |
| A. text file, check-then-append, NO lock | 2 | 254 | 250 | 4 | 257 ms |
| A. text file, check-then-append, NO lock | 3 | 266 | 250 | 16 | 257 ms |
| A. text file, check-then-append, NO lock | 4 | 253 | 250 | 3 | 228 ms |
| A. text file, check-then-append, NO lock | 5 | 254 | 250 | 4 | 223 ms |
| B. text file, synchronized (one JVM only) | 1 | 250 | 250 | 0 | 1.1 s |
| B. text file, synchronized (one JVM only) | 2 | 250 | 250 | 0 | 641 ms |
| C. database PRIMARY KEY (1750 duplicate attempts refused) | 1 | 250 | 250 | 0 | 356 ms |

Table: Table 12 – Eight counters issuing the same 250 pass ids


![Figure 13 – Duplicate passes stored per trial](report/figures/fig_b4_3_concurrency.png){width=88%}


Design A (check, then append, no lock) produced **duplicates in 5 of 5 trials** (3 to 32 duplicate passes): two counters both found "not issued yet" and both wrote. A `synchronized` block fixes it *inside one program*, but twelve campuses are separate computers and separate programs: no Java lock reaches across them, and an operating-system file lock on a shared network file is only advisory. The database enforces the rule itself: with `pass_id` as the primary key, exactly 250 rows were stored and the 1750 duplicate attempts were refused by the database – whichever machine they came from.

**Decision: design C – one MySQL (InnoDB) database accessed through `PreparedStatement`, with transactions, a primary key on `pass_id` and an index on `route_no`.** Text files remain useful for **import/export and backups** (the migration of B4.1 reads them), and Java serialization is **not** used for shared business data.

| Requirement | Why design C satisfies it | Why A and B do not |
|:---|:---|:---|
| Many counters write at once | row-level locking, atomic commit, uniqueness enforced by the primary key | check-then-append races (measured); one writer per serialized file |
| Fast search at 800,000 records | an index: about 60 µs | a full scan or load: tens of milliseconds to seconds |
| Integrity (no lost, half-written or duplicate passes) | transactions, constraints (`CHECK amount >= 0`), crash recovery by the server | only what the program itself checks (Task B2: a CRC detects damage but cannot prevent a race) |
| Security | `PreparedStatement`, database accounts with limited rights, hashed passwords | file permissions only; deserialization of untrusted files is dangerous |
| Evolution | schema changes with SQL; old rows remain valid | `serialVersionUID` discipline (A4); reformatting the file |

**Trade-offs accepted.** A database server needs installation, backups, monitoring and a connection pool; each request pays a network round trip, which the *localhost* measurements do not include; schema changes need planned migrations; and the team needs SQL skills. For an office with 8,000 passes and a single desk, the file store of Part B1 is simpler and sufficient – the decision changes with the **scale and the number of concurrent writers**, not with fashion.

**Limits of this evidence.** All numbers come from one single-core computer with the database on the same machine; the concurrency race is probabilistic (the number of duplicates changed from trial to trial, but it was not zero in a single trial of design A). Absolute times will differ elsewhere; the *orders of magnitude* (milliseconds against microseconds; duplicates against none) are what the decision rests on.

### Alternative Concept and Complexity Analysis – one serialized file per campus

```text
ALGORITHM FindPassAcrossCampuses
INPUT : passId
BEGIN
  1. FOR EACH campus file C of the 12 files DO
  2.     list ← READ the serialized list from C             // whole file is loaded
  3.     IF list contains passId THEN RETURN that pass END IF
  4. END FOR
  5. RETURN "not found"
END
```

| | Per-campus serialized files | Shared database with index |
|:---|:---|:---|
| Find one pass, campus known | **O(n/12)** – load one file | **O(log n)** – B-tree search |
| Find one pass, campus unknown | **O(n)** – load up to 12 files | **O(log n)** |
| Update one pass | **O(n/12)** – rewrite the file | **O(log n)** – one index/row change |
| Memory while searching | **O(n/12)** – one list in the heap at a time (O(n) if all are kept) | **O(1)** on the application side |
| Several writers | not possible within one file; no uniqueness *across* campuses | supported with locking and constraints |

The measurements above confirm the table: 106 ms to load one campus file and 2.8 s to search all twelve, against 60 µs for the database lookup.


# Conclusion

The design decisions of Part A were each tested in Part B, and in several places the test changed or sharpened the decision:

| Question | Decision | Evidence |
|:---|:---|:---|
| Text or binary records? | delimited text with escaping and CRC | binary round-trips and is smaller, but the text file is auditable and self-checking (A1, B1.1, B2.2) |
| Read byte by byte? | never – buffer or read blocks | 52,428,801 calls and 15.6 s against 801 calls and 32.6 ms (B1.3) |
| How far does a file scale? | O(n): comfortable at 8,000 records, not at 800,000 with many users | B1.4, B4.3 |
| Where does SQL live? | in one DAO class per table | A3 |
| How is data protected? | `PreparedStatement` for every query, transactions for every multi-step change | B2.1, B3.3 |
| How are many rows inserted? | a prepared batch in one transaction | 22 times faster than naive inserts at 100,000 rows (B3.2) |
| What is the production store? | MySQL / InnoDB | B4.3 |

**What the experiments taught beyond the questions asked:** a driver option chosen for speed (`rewriteBatchedStatements`) changed whether a stacked `DROP TABLE` executed; the supplied `PassStore` accepted a tampered amount and lost a valid record; the "obvious" cost of a transaction turned out to be a *saving* (one commit instead of two); and the strongest argument for a database was not raw speed but the duplicate passes produced by concurrent counters.

**Reproducing everything.** `./run_all.sh` compiles and runs every program and saves the outputs; `python3 tools/make_charts.py` redraws the charts and `python3 tools/build_report.py` rebuilds this report from the saved measurements.
