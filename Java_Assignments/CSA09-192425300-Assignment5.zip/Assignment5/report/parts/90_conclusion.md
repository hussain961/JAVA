# Conclusion

The design decisions of Part A were each tested in Part B, and in several places the test changed or sharpened the decision:

| Question | Decision | Evidence |
|:---|:---|:---|
| Text or binary records? | delimited text with escaping and CRC | binary round-trips and is smaller, but the text file is auditable and self-checking (A1, B1.1, B2.2) |
| Read byte by byte? | never – buffer or read blocks | {{v:unbuf_calls}} calls and {{v:unbuf_ms}} against {{v:chunk_calls}} calls and {{v:chunk_ms}} (B1.3) |
| How far does a file scale? | O(n): comfortable at 8,000 records, not at 800,000 with many users | B1.4, B4.3 |
| Where does SQL live? | in one DAO class per table | A3 |
| How is data protected? | `PreparedStatement` for every query, transactions for every multi-step change | B2.1, B3.3 |
| How are many rows inserted? | a prepared batch in one transaction | {{v:i_batch_vs_stmt}} times faster than naive inserts at {{v:i_n}} rows (B3.2) |
| What is the production store? | MySQL / InnoDB | B4.3 |

**What the experiments taught beyond the questions asked:** a driver option chosen for speed (`rewriteBatchedStatements`) changed whether a stacked `DROP TABLE` executed; the supplied `PassStore` accepted a tampered amount and lost a valid record; the "obvious" cost of a transaction turned out to be a *saving* (one commit instead of two); and the strongest argument for a database was not raw speed but the duplicate passes produced by concurrent counters.

**Reproducing everything.** `./run_all.sh` compiles and runs every program and saves the outputs; `python3 tools/make_charts.py` redraws the charts and `python3 tools/build_report.py` rebuilds this report from the saved measurements.
