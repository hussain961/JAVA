::: {custom-style="CoverSmall"}
SIMATS Engineering
:::

::: {custom-style="CoverTitle"}
Programming in Java (CSA09)
:::

::: {custom-style="CoverTitle2"}
Assignment 5 – CO5
Data Persistence Engineering – Files and Databases
:::

::: {custom-style="CoverSub"}
Java I/O (byte, character and buffered streams, File, serialization) and JDBC (Statement, PreparedStatement, transactions, batch processing, metadata)
:::

::: {custom-style="CoverField"}
**Student name:** D.HUSSAINAIAH

**Register number:** 192425300

**Programme:** B.Tech – Artificial Intelligence and Machine Learning

**Total marks:** 50 (Part A – Design & Pseudocode: 25, Part B – Implementation & Experimental Investigation: 25)

**GitHub repository:** CSA09-192425300-Assignment5  –  *paste your repository link here:* ______________________________________

**Java / database used:** JDK 17 or later · MySQL (JDBC) · local test database `transport_test` created only for this assignment
:::

```{=openxml}
<w:p><w:r><w:br w:type="page"/></w:r></w:p>
```
