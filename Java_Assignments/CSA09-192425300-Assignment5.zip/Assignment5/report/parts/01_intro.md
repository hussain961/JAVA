# How this report is organised

The assignment asks one question: *how should a Java engineer decide where and how data is stored, and how can the program be made correct, safe and efficient as the data grows?* The report follows the required workflow **Model → Choose a Store → Design → Protect → Implement → Measure → Compare → Decide**, using one running example – the **university transport office bus-pass records** (about 8,000 passes a year today, 100 times more at 12 campuses).

| Part | Tasks | What it contains |
|:---|:---|:---|
| **Part A – Design & Pseudocode (25)** | A1 file format · A2 buffering · A3 data-access pattern · A4 serialization · A5 transactions and injection | Record layouts, pseudocode, diagrams and reasoning. No Java is used in place of pseudocode. Where a design claim can be checked, a small supporting experiment from the repository is quoted as evidence. |
| **Part B – Implementation & Experiments (25)** | B1 file store · B2 adversarial input · B3 Statement / PreparedStatement / batch · B4 final decision | Working Java programs, test tables with expected and actual results, measurements, interpretation and the production decision. |

Every task also contains the required **Alternative Concept and Complexity Analysis**: the alternative is described with pseudocode, its time and space complexity are compared in Big-O notation, and – wherever possible – the comparison is backed by measurements from the repository.

## Test environment and honesty of the measurements

All programs were compiled and executed by the single script `run_all.sh`; the console output of each program is saved in `results/outputs/` and every measurement in `results/*.csv`. **All tables and numbers in this report are read from those files by `tools/build_report.py`**, so the report cannot disagree with the evidence.

| Item | Value |
|:---|:---|
| Reference run | {{v:env_date}} |
| Machine | {{v:env_line}} |
| Database / driver used for the reference run | {{v:db_product}} · {{v:db_driver}} |

Absolute times depend on the computer, the disk and the database server, so the **conclusions below rest on orders of magnitude and growth trends, not on exact milliseconds**. Re-running `run_all.sh` followed by `python3 tools/build_report.py` regenerates this report with the numbers of the computer it runs on.

## Repository map

```text
CSA09-192425300-Assignment5/
  README.md  run_all.sh  db/ (schema.sql, setup_mysql_user.sql)  common/ (Db, Bench, PassData)
  TaskA1 ... TaskA5/   answer.md (design, pseudocode, reasoning)  + experiments/ where a claim is measured
  TaskB1/  PassStore.java (Complete the Code), BusPassFileStore.java (A1 design), LineCounter, BuffBench, GrowthBench, PassStoreTest
  TaskB2/  LoginDemo, BadFileDemo, EscapingWeakness
  TaskB3/  PassLoader.java (Complete the Code), SmallCorrectness, LoadBench, TransactionDemo, InsertStrategies
  TaskB4/  GenerateMigrationData, Migrate, DbInfo, ConcurrencyDemo, ScaleDecision
  results/ (outputs/*.txt, *.csv, migration report)   report/ (this report, figures)   tools/ (charts, report builder)
```

## Pseudocode conventions

Pseudocode in Part A uses a fixed layout: `ALGORITHM` name, `INPUT`, `OUTPUT`, numbered steps in `BEGIN … END`, upper-case keywords (`IF … THEN … ELSE`, `FOR EACH`, `WHILE`, `RETURN`), `←` for assignment and indentation for nesting. It is language-neutral: stream and class names appear only where the task asks which Java classes to use.
