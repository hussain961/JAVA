Put your own screenshots here (one per task run), e.g. B1_3_buffering.png. See README.md.
