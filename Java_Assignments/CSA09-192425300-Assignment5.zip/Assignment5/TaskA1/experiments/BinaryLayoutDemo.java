import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.math.BigDecimal;
import java.nio.charset.StandardCharsets;
import java.time.LocalDate;
import java.util.List;
import java.util.zip.CRC32;

/**
 * Task A1.1(b) - supporting experiment. Writes bus-pass records with DataOutputStream using the binary layout
 * designed in Task A1 and proves the layout by reading them back:
 *
 *   int  payloadLength              (bytes of fields 2..8)
 *   UTF  passId, regNo, name        (writeUTF: 2-byte length + modified-UTF-8 bytes)
 *   short route
 *   UTF  boardingStop
 *   int  validUntil                 (LocalDate.toEpochDay)
 *   int  amountPaise                (amount x 100, exact - no floating point)
 *   int  crc32                      (of the payload bytes)
 */
public class BinaryLayoutDemo {

    static byte[] encode(BusPassFileStore.Pass p) throws IOException {
        ByteArrayOutputStream payload = new ByteArrayOutputStream();
        DataOutputStream d = new DataOutputStream(payload);
        d.writeUTF(p.passId());
        d.writeUTF(p.regNo());
        d.writeUTF(p.name());
        d.writeShort(p.route());
        d.writeUTF(p.stop());
        d.writeInt((int) p.validUntil().toEpochDay());
        d.writeInt(p.amount().movePointRight(2).intValueExact());
        byte[] body = payload.toByteArray();
        CRC32 crc = new CRC32();
        crc.update(body);
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        DataOutputStream o = new DataOutputStream(out);
        o.writeInt(body.length);
        o.write(body);
        o.writeInt((int) crc.getValue());
        return out.toByteArray();
    }

    static BusPassFileStore.Pass decode(DataInputStream in) throws IOException {
        int len = in.readInt();
        byte[] body = new byte[len];
        in.readFully(body);
        int stored = in.readInt();
        CRC32 crc = new CRC32();
        crc.update(body);
        if ((int) crc.getValue() != stored) throw new IOException("CRC mismatch - damaged record");
        DataInputStream d = new DataInputStream(new ByteArrayInputStream(body));
        String id = d.readUTF(), reg = d.readUTF(), name = d.readUTF();
        int route = d.readShort();
        String stop = d.readUTF();
        LocalDate valid = LocalDate.ofEpochDay(d.readInt());
        BigDecimal amount = BigDecimal.valueOf(d.readInt(), 2);
        return new BusPassFileStore.Pass(id, reg, name, route, stop, valid, amount);
    }

    static String hex(byte[] b, int max) {
        StringBuilder s = new StringBuilder();
        for (int i = 0; i < Math.min(b.length, max); i++) s.append(String.format("%02x ", b[i]));
        return s.toString().trim();
    }

    public static void main(String[] args) throws Exception {
        List<BusPassFileStore.Pass> passes = PassData.passes(2000);
        BusPassFileStore.Pass tricky = new BusPassFileStore.Pass("P009999", "192311999", "Ravi|Kumar, Jr\\X",
                12, "Anna Nagar", LocalDate.of(2027, 3, 31), new BigDecimal("4500.00"));

        // 1. one record, byte by byte
        byte[] one = encode(passes.get(0));
        System.out.println("Record P000001 (" + one.length + " bytes):");
        System.out.println("  " + hex(one, 80));
        System.out.println("  text form (" + (BusPassFileStore.encode(passes.get(0)).getBytes(StandardCharsets.UTF_8).length + 1) + " bytes): "
                + BusPassFileStore.encode(passes.get(0)));

        // 2. round trip of 2,000 records + the tricky name
        ByteArrayOutputStream file = new ByteArrayOutputStream();
        long textBytes = 0;
        for (BusPassFileStore.Pass p : passes) {
            file.write(encode(p));
            textBytes += BusPassFileStore.encode(p).getBytes(StandardCharsets.UTF_8).length + 1;
        }
        file.write(encode(tricky));
        DataInputStream in = new DataInputStream(new ByteArrayInputStream(file.toByteArray()));
        int ok = 0;
        BusPassFileStore.Pass last = null;
        for (int i = 0; i < passes.size(); i++) {
            BusPassFileStore.Pass back = decode(in);
            if (back.equals(passes.get(i))) ok++;
        }
        last = decode(in);
        System.out.println("Round trip: " + ok + " of " + passes.size() + " records identical after write + read");
        System.out.println("Name with | , and \\ stored as-is (length-prefixed, no escaping needed): " + last.name().equals(tricky.name()));
        System.out.printf("Average size: binary %.1f bytes/record, text %.1f bytes/record%n",
                (file.size() - encode(tricky).length) / (double) passes.size(), textBytes / (double) passes.size());

        // 3. damage detection: flip one byte inside a record
        byte[] all = file.toByteArray();
        all[one.length + 20] ^= 0x55;                       // corrupt record #2
        DataInputStream bad = new DataInputStream(new ByteArrayInputStream(all));
        decode(bad);                                        // record 1 is fine
        try { decode(bad); System.out.println("damage NOT detected"); }
        catch (IOException e) { System.out.println("Corrupted record #2 detected: " + e.getMessage()); }
    }
}
