import java.io.IOException;
import java.io.RandomAccessFile;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.Random;

/**
 * Task A1 alternative concept - fixed-length records in a RandomAccessFile.
 *
 * Record layout (92 bytes): flag(1) passId(8) regNo(9) name(40) route(2) stop(24) validUntil(4) amountPaise(4)
 * Record i lives at byte offset i * 92, so a pass whose id carries its sequence number (P000042 -> record 41)
 * is found with ONE seek instead of a scan.
 *
 * Output: results/A1_randomaccess.csv  n, record_bytes, avg_content_bytes, padding_pct, ra_file_kb, text_file_kb,
 *                                      scan_find_ms, seek_find_us
 */
public class RandomAccessBench {
    static final int REC = 92;

    static void putAscii(byte[] rec, int off, int width, String s) {
        byte[] b = s.getBytes(StandardCharsets.UTF_8);
        if (b.length > width) throw new IllegalArgumentException("'" + s + "' longer than " + width + " bytes");
        System.arraycopy(b, 0, rec, off, b.length);               // the rest stays 0x00 = padding
    }

    static String getString(byte[] rec, int off, int width) {
        int end = off;
        while (end < off + width && rec[end] != 0) end++;
        return new String(rec, off, end - off, StandardCharsets.UTF_8);
    }

    static byte[] pack(BusPassFileStore.Pass p) {
        byte[] r = new byte[REC];
        r[0] = 1;                                                  // 1 = record in use
        putAscii(r, 1, 8, p.passId());
        putAscii(r, 9, 9, p.regNo());
        putAscii(r, 18, 40, p.name());
        r[58] = (byte) (p.route() >> 8); r[59] = (byte) p.route();
        putAscii(r, 60, 24, p.stop());
        int day = (int) p.validUntil().toEpochDay();
        for (int i = 0; i < 4; i++) r[84 + i] = (byte) (day >> (24 - 8 * i));
        int paise = p.amount().movePointRight(2).intValueExact();
        for (int i = 0; i < 4; i++) r[88 + i] = (byte) (paise >> (24 - 8 * i));
        return r;
    }

    static int contentBytes(BusPassFileStore.Pass p) {
        return 1 + p.passId().length() + p.regNo().length() + p.name().getBytes(StandardCharsets.UTF_8).length
                + 2 + p.stop().getBytes(StandardCharsets.UTF_8).length + 4 + 4;
    }

    /** O(1): the record number is derived from the id. */
    static String findBySeek(RandomAccessFile raf, String passId) throws IOException {
        long index = Long.parseLong(passId.substring(1)) - 1;
        raf.seek(index * REC);
        byte[] rec = new byte[REC];
        raf.readFully(rec);
        if (rec[0] != 1) return null;
        return getString(rec, 1, 8) + "," + getString(rec, 9, 9) + "," + getString(rec, 18, 40);
    }

    public static void main(String[] args) throws Exception {
        Bench.resetCsv("A1_randomaccess.csv",
                "n,record_bytes,avg_content_bytes,padding_pct,ra_file_kb,text_file_kb,scan_find_ms,seek_find_us");
        for (int n : new int[] {8000, 100000}) {
            List<BusPassFileStore.Pass> passes = PassData.passes(n);
            // names containing | or , are fine here (fixed width, no delimiter); all names are < 40 bytes
            Path ra = Bench.workDir().resolve("passes_fixed_" + n + ".bin");
            Path txt = Bench.workDir().resolve("passes_text_" + n + ".txt");
            Files.deleteIfExists(txt);
            long content = 0;
            try (RandomAccessFile raf = new RandomAccessFile(ra.toFile(), "rw")) {
                raf.setLength(0);
                java.io.ByteArrayOutputStream buf = new java.io.ByteArrayOutputStream(n * REC);
                for (BusPassFileStore.Pass p : passes) { buf.write(pack(p)); content += contentBytes(p); }
                raf.write(buf.toByteArray());
            }
            new BusPassFileStore(txt).appendAll(passes, false);

            // correctness: every record found by seek matches
            Random r = new Random(5);
            int bad = 0;
            try (RandomAccessFile raf = new RandomAccessFile(ra.toFile(), "r")) {
                for (int i = 0; i < 2000; i++) {
                    int id = 1 + r.nextInt(n);
                    String got = findBySeek(raf, PassData.passId(id));
                    BusPassFileStore.Pass p = passes.get(id - 1);
                    if (got == null || !got.equals(p.passId() + "," + p.regNo() + "," + p.name())) bad++;
                }
            }
            if (bad != 0) throw new IllegalStateException(bad + " records differ");

            // timing: scan with BusPassFileStore vs seek
            BusPassFileStore store = new BusPassFileStore(txt);
            for (int i = 0; i < 20; i++) store.find(PassData.passId(n));
            String[] ids = new String[20];
            for (int i = 0; i < ids.length; i++) ids[i] = PassData.passId(1 + r.nextInt(n));
            double scanMs = Bench.timeMs(() -> { for (String id : ids) store.find(id); }) / ids.length;

            int q = 20000;
            String[] sid = new String[q];
            for (int i = 0; i < q; i++) sid[i] = PassData.passId(1 + r.nextInt(n));
            double seekUs;
            try (RandomAccessFile raf = new RandomAccessFile(ra.toFile(), "r")) {
                for (int i = 0; i < 2000; i++) findBySeek(raf, sid[i]);       // warm-up
                seekUs = Bench.timeMs(() -> { for (String id : sid) findBySeek(raf, id); }) * 1000.0 / q;
            }
            double avgContent = content / (double) n;
            double padPct = 100.0 * (REC - avgContent) / REC;
            System.out.printf("n=%6d | record=%d B, average real content=%.1f B -> padding %.1f%% | fixed file %d KB vs text file %d KB | "
                            + "average find: scan %.3f ms vs seek %.2f us (%.0fx)%n",
                    n, REC, avgContent, padPct, Files.size(ra) / 1024, Files.size(txt) / 1024, scanMs, seekUs, scanMs * 1000 / seekUs);
            Bench.csv("A1_randomaccess.csv", String.format("%d,%d,%.1f,%.1f,%d,%d,%.3f,%.2f", n, REC, avgContent, padPct,
                    Files.size(ra) / 1024, Files.size(txt) / 1024, scanMs, seekUs));
        }
    }
}
