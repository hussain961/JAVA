# PART A – PERSISTENCE DESIGN & PSEUDOCODE (25 marks)

## Task A1 – Design a File Format (7 marks, K4 – Analyse)

**Problem.** The transport office issues bus passes. A record has seven fields: pass ID, student register number, name, route number, boarding stop, validity date and amount paid. About 8,000 passes are issued a year. The file must support (i) adding a pass, (ii) finding a pass by pass ID and (iii) listing all passes on a route.

**Sizing.** At roughly 70 bytes per record, one year is about 8,000 × 70 B ≈ 0.55 MB – small enough to be read completely in a few milliseconds. A file is therefore a reasonable store *at today's scale*; Part B measures where it stops being reasonable.

### A1.1 – Represent the record (2 marks)

**(a) Delimited text file – one record per line, UTF-8.**

| # | Field | Format and validation | Example |
|:-:|:---|:---|:---|
| 1 | passId | `P` + 4 to 8 digits | `P000001` |
| 2 | regNo | exactly 9 digits | `192000037` |
| 3 | name | 1–60 characters, not blank | `Vignesh Iyer` |
| 4 | route | integer 1–99 | `23` |
| 5 | boardingStop | 1–40 characters | `Sholinganallur` |
| 6 | validUntil | ISO date `yyyy-MM-dd` | `2027-03-31` |
| 7 | amount | decimal with at most 2 places, 0 – 99,999.99 | `4150.00` |
| 8 | crc | CRC-32 of fields 1–7 (the text before the last `|`) as 8 hex digits | `2c309790` |

Complete line: `P000001|192000037|Vignesh Iyer|23|Sholinganallur|2027-03-31|4150.00|2c309790`

* **Delimiter.** The pipe `|` is used, not the comma. Names such as *Kumar, Arun* are common, and the comma-separated `PassStore` supplied with the assignment loses such a record (test C4 in Task B1).
* **A name that contains the delimiter.** Inside a field three characters are escaped: `|` → `\|`, `\` → `\\`, line break → `\n` (and `\r`). The reader splits only on an *unescaped* `|` and then reverses the escapes, so `Ravi|Kumar, Jr\X` is stored as `Ravi\|Kumar, Jr\\X` and read back unchanged (test T7).
* **Why a CRC field.** The number of fields only proves the *shape* of a line, not that its content is intact. The CRC detects a half-written line, a bit flip or a hand edit (A1.3).

**(b) Binary file written with `DataOutputStream`.** Every record is framed by a length so a reader can skip a damaged record:

| Order | Content | `DataOutputStream` method | Bytes |
|:-:|:---|:---|:--|
| 1 | payload length | `writeInt` | 4 |
| 2 | passId | `writeUTF` | 2 + length |
| 3 | regNo | `writeUTF` | 2 + length |
| 4 | name | `writeUTF` | 2 + length |
| 5 | route | `writeShort` | 2 |
| 6 | boardingStop | `writeUTF` | 2 + length |
| 7 | validUntil (`LocalDate.toEpochDay`) | `writeInt` | 4 |
| 8 | amount in paise (amount × 100, exact – no floating point) | `writeInt` | 4 |
| 9 | CRC-32 of bytes 2–8 | `writeInt` | 4 |

Strings carry their own two-byte length (`writeUTF`), so **no delimiter exists and a name containing `|` needs no escaping.** A real record produced by this layout (68 bytes) and its proof by read-back:

```text
Record P000001 (68 bytes):
  00 00 00 3c 00 07 50 30 30 30 30 30 31 00 09 31 39 32 30 30 30 30 33 37 00 0c 56 69 67 6e 65 73 68 20 49 79 65 72 00 17 00 0e 53 68 6f 6c 69 6e 67 61 6e 61 6c 6c 75 72 00 00 51 ac 00 06 55 18 a7 0c 70 bb
  text form (77 bytes): P000001|192000037|Vignesh Iyer|23|Sholinganallur|2027-03-31|4150.00|2c309790
Round trip: 2000 of 2000 records identical after write + read
Name with | , and \ stored as-is (length-prefixed, no escaping needed): true
Average size: binary 61.6 bytes/record, text 70.4 bytes/record
Corrupted record #2 detected: CRC mismatch - damaged record
```

The binary form is slightly smaller than the text form but cannot be read or repaired with a text editor, and its layout is harder to evolve. For an office whose records must be auditable by hand, the **text layout is chosen** for the main design.

### A1.2 – Design the operations (3 marks)

**Streams chosen (text-file design).**

| Operation | Classes | Why |
|:---|:---|:---|
| Add (append) | `FileChannel` opened with `CREATE, APPEND` + `force(true)` – or `BufferedWriter` over `FileOutputStream(file, true)` when durability per record is not needed | One `write` call per record makes the append a single operation; `force` makes it reach the disk before the method returns. Character streams (`FileWriter`) would hide the character set and give no durability control. |
| Find, List (read) | `BufferedReader` over `InputStreamReader(FileInputStream, UTF-8)` | The file is text, so `readLine()` is the natural unit; buffering reduces operating-system calls by thousands of times (Task A2); the explicit UTF-8 decoder makes the file portable between computers. |
| Byte-level check (tail test) | `RandomAccessFile` (read last byte) | Needed to ask "does the file end with a line break?" without reading the whole file. |

All streams are opened in try-with-resources so they are closed even when an exception occurs.

```text
ALGORITHM AddPass
INPUT : pass (7 fields), file F
OUTPUT: pass appended to F, or an error
BEGIN
  1. line ← ENCODE(pass)                          // escape fields, join with '|', append CRC
  2. IF DECODE(line) is not valid THEN REJECT "invalid pass" END IF     // validate before writing
  3. IF FIND(pass.passId) exists THEN REJECT "duplicate pass id" END IF
  4. IF F exists AND last byte of F is not '\n' THEN        // an earlier write was cut short
         prefix ← '\n'                                      // isolate the damaged tail, never glue to it
     ELSE prefix ← empty
     END IF
  5. OPEN F for append (create if missing)
  6. WRITE prefix + line + '\n' in ONE write operation
  7. FORCE the data to disk
  8. CLOSE F
END
```

```text
ALGORITHM FindPass
INPUT : passId, file F
OUTPUT: the pass, or "not found"
BEGIN
  1. IF F does not exist THEN RETURN "not found" END IF     // a missing file is an empty store
  2. OPEN F for buffered reading (UTF-8)
  3. WHILE a next line exists DO
  4.     IF line begins with passId + '|' THEN               // cheap test before the full check
  5.         result ← DECODE(line)
  6.         IF result is valid THEN CLOSE F; RETURN result.pass END IF
  7.         damagedCount ← damagedCount + 1                  // matching id but damaged line: skip it
  8.     END IF
  9. END WHILE
 10. CLOSE F
 11. RETURN "not found"
END
```

```text
ALGORITHM ListRoute
INPUT : route r, file F
OUTPUT: list of valid passes on route r
BEGIN
  1. result ← empty list
  2. IF F does not exist THEN RETURN result END IF
  3. OPEN F for buffered reading (UTF-8)
  4. WHILE a next line exists DO
  5.     d ← DECODE(line)
  6.     IF d is not valid THEN damagedCount ← damagedCount + 1; CONTINUE END IF
  7.     IF d.pass.route = r THEN ADD d.pass TO result END IF
  8. END WHILE
  9. CLOSE F
 10. RETURN result
END
```

```text
ALGORITHM DECODE
INPUT : line
OUTPUT: a valid pass, or a reason for rejection
BEGIN
  1. IF line is blank THEN RETURN reject EMPTY_LINE
  2. split line at the last unescaped '|' into body and crc
  3. split body at unescaped '|' and undo the escapes      // bad escape → reject BAD_ESCAPE
  4. IF number of fields ≠ 7 THEN RETURN reject WRONG_FIELD_COUNT
  5. IF CRC32(body) ≠ crc THEN RETURN reject CRC_MISMATCH
  6. validate each field (id pattern, 9-digit regNo, route 1-99, date, amount ≥ 0, ≤ 2 decimals)
  7. RETURN the pass, or the first failing field as the reason
END
```

### A1.3 – Design for damaged data (2 marks)

| Failure | How it is detected | How it is handled |
|:---|:---|:---|
| **Damaged line** (edited by hand, bit flip, wrong field count, blank line, impossible date, invalid UTF-8 bytes) | `DECODE` returns a reason: field count, CRC-32, field validation; the reader decodes bytes with *replace* so invalid bytes become U+FFFD and fail the CRC instead of aborting the scan | The line is **skipped, counted and reported** (`verify()` lists the reason per line); search and listing continue with the next line. The system never "repairs" a record by guessing. |
| **Missing file** | `Files.exists` is false | For reading, the store is treated as empty (find → not found, list → empty). The first `AddPass` creates the file. Any other I/O error (permission, disk) is *not* hidden – it is thrown to the caller. |
| **Incomplete write after a power failure** | The last line has no `\n`, and its CRC / field count fail | Complete records before it stay readable. The next append writes a `\n` first so the half line stays an isolated, reported damaged line instead of corrupting the new record. `repairTail()` may truncate the file after the last `\n`. Each record is written in one write call followed by `force(true)`, which limits the damage to at most one record. Rewriting the whole file (not needed here) would use *write to a temporary file, then atomic rename*. |

The tests that prove each row are T8–T17 in Task B1.1.

### Alternative Concept and Complexity Analysis – fixed-length records in a `RandomAccessFile`

**Solution.** Every record gets the same size, so record *i* starts at byte *i × recordSize*. With a 92-byte record (flag 1 B, passId 8, regNo 9, name 40, route 2, stop 24, validUntil 4, amount 4):

```text
ALGORITHM FindBySeek
INPUT : passId (for example "P000042"), file F
OUTPUT: the pass or "not found"
BEGIN
  1. i ← integer value of passId without the letter P, minus 1       // the id carries the record number
  2. SEEK F to position i × 92
  3. READ 92 bytes into rec
  4. IF rec.flag ≠ 1 THEN RETURN "not found" END IF                  // 0 = deleted / unused
  5. RETURN fields unpacked from rec
END
```

| | Delimited text file (chosen) | Fixed-length `RandomAccessFile` |
|:---|:---|:---|
| Find by pass ID – time | **O(n)** – every line up to the match is read | **O(1)** – one seek and one read, *but only because the id encodes the record number*. With arbitrary ids it needs an index (O(1) average, O(n) memory) or a file sorted by id (binary search, O(log n) seeks). |
| List by route – time | O(n) | O(n) – no better without a route index |
| Extra memory | O(1) – only the read buffer | O(1) |
| Space on disk | exactly the bytes used | n × 92 – every field is padded to its maximum |
| Updates in place | rewrite the file | overwrite one record |
| Variable data | any length (up to the 60-character rule) | names longer than 40 bytes must be rejected or truncated |
| Readable with an editor | yes | no |

**Measured** (`TaskA1/experiments/RandomAccessBench.java`):

| Records (n) | Record size | Average real content | Padding wasted | Fixed-length file | Text file | Find by scan (avg) | Find by seek (avg) |
| ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| 8,000 | 92 B | 46.6 B | 49.3 % | 718 KB | 550 KB | 2.56 ms | 3.09 µs |
| 100,000 | 92 B | 46.6 B | 49.4 % | 8,984 KB | 6,871 KB | 8.30 ms | 2.06 µs |

Table: Table 1 – Fixed-length RandomAccessFile versus the delimited text file


The padding wasted is **49.4 %** of the file (average real content 46.6 bytes of a 92-byte record), so the fixed-length file is *larger* (8,984 KB against 6,871 KB for 100,000 records). In exchange a lookup takes about 2.06 µs instead of 8.30 ms – roughly **4,030 times faster**. The text file stays the choice for the current 8,000 records (a whole scan is a few milliseconds and the file is human-readable and self-checking); the fixed-length layout would become attractive only if the office needs very many lookups and can keep ids sequential.

**Evidence expected – covered:** two record layouts (A1.1), pseudocode for the three operations with justified stream choices (A1.2), and a design for damaged data (A1.3).
