# Task B3 – Insert data three ways

Table: `bus_pass` (see `../db/schema.sql`). Needs the MySQL test database and the JDBC jar in `../lib`.

| File | Purpose | Run |
|:---|:---|:---|
| `PassLoader.java` | **Complete the Code** – TODO 1, 2, 3 completed (batch of 1,000, commit, rollback + re-throw) | used by the demos |
| `SmallCorrectness.java` | B3.1 – 10 records with Statement / PreparedStatement / batch, `SELECT` + `ResultSetMetaData` | `java -cp "out:lib/*" SmallCorrectness` |
| `LoadBench.java` | B3.2 – 1,000 / 10,000 / 100,000 rows, auto-commit and one transaction | `java -cp "out:lib/*" LoadBench` (`LoadBench 1000 10000` for a quick run) |
| `TransactionDemo.java` | B3.3 – failure half-way (rows left), wallet transfer with crash, transaction speed | `java -cp "out:lib/*" TransactionDemo` |
| `InsertStrategies.java` | alternative concept – multi-row INSERT and `LOAD DATA LOCAL INFILE` | `java -cp "out:lib/*" InsertStrategies` |

Screenshots to take: SmallCorrectness output; LoadBench table; the "rows left" table and the wallet lines of TransactionDemo.
