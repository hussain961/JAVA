import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;

/**
 * Task B3.2 - insert 1,000 / 10,000 / 100,000 passes with (a) Statement, (b) PreparedStatement,
 * (c) PreparedStatement + addBatch()/executeBatch(). Each approach is timed with auto-commit ON (the JDBC default,
 * the three rows asked for in the task) and, as an extra, inside one transaction to separate the effect of
 * "how the SQL is sent" from "how often the database commits".
 * Output: results/B3_2_inserts.csv   rows, approach, commit_mode, time_ms, rows_per_sec, runs
 */
public class LoadBench {

    interface Insert { void run(Connection con, List<String[]> rows) throws SQLException; }

    static String q(String s) { return "'" + s.replace("\\", "\\\\").replace("'", "''") + "'"; }

    static void statement(Connection con, List<String[]> rows) throws SQLException {
        try (Statement st = con.createStatement()) {
            for (String[] r : rows) {
                st.executeUpdate("INSERT INTO bus_pass(pass_id, reg_no, name, route_no, amount) VALUES ("
                        + q(r[0]) + "," + q(r[1]) + "," + q(r[2]) + "," + r[3] + "," + r[4] + ")");
            }
        }
    }

    static PreparedStatement prep(Connection con) throws SQLException {
        return con.prepareStatement("INSERT INTO bus_pass(pass_id, reg_no, name, route_no, amount) VALUES (?,?,?,?,?)");
    }

    static void bind(PreparedStatement ps, String[] r) throws SQLException {
        ps.setString(1, r[0]); ps.setString(2, r[1]); ps.setString(3, r[2]);
        ps.setInt(4, Integer.parseInt(r[3])); ps.setBigDecimal(5, new BigDecimal(r[4]));
    }

    static void prepared(Connection con, List<String[]> rows) throws SQLException {
        try (PreparedStatement ps = prep(con)) {
            for (String[] r : rows) { bind(ps, r); ps.executeUpdate(); }
        }
    }

    static void batch(Connection con, List<String[]> rows) throws SQLException {
        try (PreparedStatement ps = prep(con)) {
            int n = 0;
            for (String[] r : rows) {
                bind(ps, r);
                ps.addBatch();
                if (++n % 1000 == 0) ps.executeBatch();
            }
            ps.executeBatch();
        }
    }

    static double once(Connection con, List<String[]> rows, Insert ins, boolean tx) throws SQLException {
        try (Statement st = con.createStatement()) { st.executeUpdate("TRUNCATE TABLE bus_pass"); }
        long t0 = System.nanoTime();
        if (tx) {
            con.setAutoCommit(false);
            try { ins.run(con, rows); con.commit(); } finally { con.setAutoCommit(true); }
        } else {
            ins.run(con, rows);
        }
        double ms = (System.nanoTime() - t0) / 1e6;
        try (Statement st = con.createStatement(); ResultSet rs = st.executeQuery("SELECT COUNT(*) FROM bus_pass")) {
            rs.next();
            if (rs.getInt(1) != rows.size()) throw new IllegalStateException("expected " + rows.size() + " rows, found " + rs.getInt(1));
        }
        return ms;
    }

    public static void main(String[] args) throws Exception {
        Bench.resetCsv("B3_2_inserts.csv", "rows,approach,commit_mode,time_ms,rows_per_sec,runs");
        int[] sizes = args.length > 0 ? java.util.Arrays.stream(args).mapToInt(Integer::parseInt).toArray() : new int[] {1000, 10000, 100000};
        String[] names = {"Statement", "PreparedStatement", "PreparedStatement + batch"};
        Insert[] fns = {LoadBench::statement, LoadBench::prepared, LoadBench::batch};
        try (Connection con = Db.connect()) {
            System.out.println("Database: " + con.getMetaData().getDatabaseProductName() + " " + con.getMetaData().getDatabaseProductVersion()
                    + " | driver " + con.getMetaData().getDriverName() + " " + con.getMetaData().getDriverVersion());
            // warm-up (JIT + connection)
            List<String[]> w = PassData.rows(2000);
            for (Insert f : fns) { once(con, w, f, true); once(con, w, f, false); }

            for (int n : sizes) {
                List<String[]> rows = PassData.rows(n);
                for (boolean tx : new boolean[] {false, true}) {
                    for (int a = 0; a < 3; a++) {
                        double first = once(con, rows, fns[a], tx);
                        double med = first;
                        int runs = 1;
                        if (first < 8000) {                       // repeat fast cases and take the median of three
                            double[] t = {first, once(con, rows, fns[a], tx), once(con, rows, fns[a], tx)};
                            java.util.Arrays.sort(t);
                            med = t[1]; runs = 3;
                        }
                        System.out.printf("%7d rows | %-26s | %-11s | %10.1f ms | %10.0f rows/s | runs=%d%n",
                                n, names[a], tx ? "1 transaction" : "auto-commit", med, n / (med / 1000.0), runs);
                        Bench.csv("B3_2_inserts.csv", n + "," + names[a] + "," + (tx ? "transaction" : "autocommit") + ","
                                + String.format("%.1f,%.0f,%d", med, n / (med / 1000.0), runs));
                    }
                }
            }
        }
    }
}
