import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/**
 * Task B3.3 (and A5 alternative concept) - auto-commit versus one transaction when something fails half-way.
 *  Part 1: a 5,000-pass load that hits a bad row half-way (client-side: invalid amount; database-side: duplicate key)
 *  Part 2: the Rs 500 wallet transfer with a simulated crash between the two UPDATEs
 *  Part 3: speed of 5,000 two-update transfers, auto-commit vs one transaction each
 * Output: results/B3_3_failure.csv (scenario, mode, exception, rows_left)  results/B3_3_transfer_speed.csv
 */
public class TransactionDemo {

    static int count(Connection con, String table) throws SQLException {
        try (Statement st = con.createStatement(); ResultSet rs = st.executeQuery("SELECT COUNT(*) FROM " + table)) { rs.next(); return rs.getInt(1); }
    }

    /** Same loop as PassLoader.loadAll but with auto-commit left ON: every executeBatch() is committed immediately. */
    static int loadAllAutoCommit(Connection con, List<String[]> passes) throws SQLException {
        try (PreparedStatement ps = con.prepareStatement(
                "INSERT INTO bus_pass(pass_id, reg_no, name, route_no, amount) VALUES (?, ?, ?, ?, ?)")) {
            int n = 0;
            for (String[] p : passes) {
                ps.setString(1, p[0]); ps.setString(2, p[1]); ps.setString(3, p[2]);
                ps.setInt(4, Integer.parseInt(p[3])); ps.setDouble(5, Double.parseDouble(p[4]));
                ps.addBatch();
                n++;
                if (n % 1000 == 0) ps.executeBatch();
            }
            ps.executeBatch();
            return n;
        }
    }

    interface Loader { int load(Connection con, List<String[]> rows) throws SQLException; }

    static String attempt(Connection con, Loader l, List<String[]> rows) throws SQLException {
        try (Statement st = con.createStatement()) { st.executeUpdate("TRUNCATE TABLE bus_pass"); }
        String ex;
        try { int n = l.load(con, rows); ex = "none (" + n + " loaded)"; }
        catch (Exception e) { ex = e.getClass().getSimpleName(); }
        return ex;
    }

    // ------------------------------------------------------------------ wallets
    static void resetWallets(Connection con) throws SQLException {
        try (Statement st = con.createStatement()) {
            st.executeUpdate("UPDATE hostel_wallet SET balance = 2000.00 WHERE reg_no = '192311001'");
            st.executeUpdate("UPDATE canteen_wallet SET balance = 100.00 WHERE reg_no = '192311001'");
        }
    }

    static String balances(Connection con) throws SQLException {
        try (Statement st = con.createStatement();
             ResultSet rs = st.executeQuery("SELECT h.balance, c.balance FROM hostel_wallet h, canteen_wallet c "
                     + "WHERE h.reg_no = '192311001' AND c.reg_no = '192311001'")) {
            rs.next();
            BigDecimal h = rs.getBigDecimal(1), c = rs.getBigDecimal(2);
            return "hostel=" + h.toPlainString() + " canteen=" + c.toPlainString() + " total=" + h.add(c).toPlainString();
        }
    }

    /** Two independent auto-commit statements. */
    static void transferAutoCommit(Connection con, String regNo, BigDecimal amt, boolean crashBetween) throws SQLException {
        try (PreparedStatement debit = con.prepareStatement("UPDATE hostel_wallet SET balance = balance - ? WHERE reg_no = ?");
             PreparedStatement credit = con.prepareStatement("UPDATE canteen_wallet SET balance = balance + ? WHERE reg_no = ?")) {
            debit.setBigDecimal(1, amt); debit.setString(2, regNo); debit.executeUpdate();     // committed immediately
            if (crashBetween) throw new IllegalStateException("simulated power failure between the two updates");
            credit.setBigDecimal(1, amt); credit.setString(2, regNo); credit.executeUpdate();  // committed immediately
        }
    }

    /** One transaction: both updates become permanent together or not at all. */
    static boolean transferTx(Connection con, String regNo, BigDecimal amt, boolean crashBetween) throws SQLException {
        boolean old = con.getAutoCommit();
        con.setAutoCommit(false);
        try (PreparedStatement debit = con.prepareStatement("UPDATE hostel_wallet SET balance = balance - ? WHERE reg_no = ? AND balance >= ?");
             PreparedStatement credit = con.prepareStatement("UPDATE canteen_wallet SET balance = balance + ? WHERE reg_no = ?")) {
            debit.setBigDecimal(1, amt); debit.setString(2, regNo); debit.setBigDecimal(3, amt);
            if (debit.executeUpdate() != 1) { con.rollback(); return false; }                  // insufficient funds / unknown account
            if (crashBetween) throw new IllegalStateException("simulated power failure between the two updates");
            credit.setBigDecimal(1, amt); credit.setString(2, regNo);
            if (credit.executeUpdate() != 1) { con.rollback(); return false; }
            con.commit();
            return true;
        } catch (SQLException | RuntimeException e) {
            try { con.rollback(); } catch (SQLException ignore) { e.addSuppressed(ignore); }
            throw e;
        } finally {
            con.setAutoCommit(old);
        }
    }

    public static void main(String[] args) throws Exception {
        Bench.resetCsv("B3_3_failure.csv", "scenario,mode,exception,rows_left");
        Bench.resetCsv("B3_3_transfer_speed.csv", "mode,transfers,time_ms,ms_per_transfer");
        try (Connection con = Db.connect()) {
            // ---------------------------------------------------------------- Part 1
            List<String[]> bad1 = PassData.rows(5000);
            bad1.get(2500)[4] = "12x0";                                    // invalid amount in the middle of the list
            List<String[]> bad2 = PassData.rows(5000);
            bad2.set(3000, bad2.get(10).clone());                          // duplicate primary key P000011 at position 3000

            System.out.println("PART 1 - 5,000 passes, one bad row half-way");
            System.out.printf("%-34s | %-30s | %-22s | %s%n", "Scenario", "Mode", "Exception", "Rows left in table");
            String[][] sc = {{"invalid amount at row 2,501", null}, {"duplicate pass id at row 3,001", null}};
            List<List<String[]>> data = List.of(bad1, bad2);
            for (int i = 0; i < 2; i++) {
                for (int m = 0; m < 2; m++) {
                    Loader l = m == 0 ? TransactionDemo::loadAllAutoCommit : PassLoader::loadAll;
                    String mode = m == 0 ? "batch, auto-commit ON" : "PassLoader.loadAll (transaction)";
                    String ex = attempt(con, l, data.get(i));
                    int left = count(con, "bus_pass");
                    System.out.printf("%-34s | %-30s | %-22s | %d%n", sc[i][0], mode, ex, left);
                    Bench.csv("B3_3_failure.csv", "\"" + sc[i][0] + "\",\"" + mode + "\",\"" + ex + "\"," + left);
                }
            }

            // ---------------------------------------------------------------- Part 2
            System.out.println();
            System.out.println("PART 2 - transfer Rs 500 from hostel wallet to canteen wallet (account 192311001)");
            resetWallets(con);
            System.out.println("start                                   : " + balances(con));
            try { transferAutoCommit(con, "192311001", new BigDecimal("500.00"), true); } catch (IllegalStateException e) { System.out.println("   crash: " + e.getMessage()); }
            System.out.println("auto-commit, crash between updates      : " + balances(con) + "   <-- Rs 500 has vanished");
            resetWallets(con);
            try { transferTx(con, "192311001", new BigDecimal("500.00"), true); } catch (IllegalStateException e) { System.out.println("   crash: " + e.getMessage()); }
            System.out.println("transaction, crash between updates      : " + balances(con) + "   <-- rolled back, nothing lost");
            resetWallets(con);
            boolean ok = transferTx(con, "192311001", new BigDecimal("500.00"), false);
            System.out.println("transaction, no failure (returned " + ok + ")  : " + balances(con));
            resetWallets(con);
            boolean big = transferTx(con, "192311001", new BigDecimal("5000.00"), false);
            System.out.println("transaction, insufficient funds (returned " + big + "): " + balances(con) + "   <-- refused, unchanged");

            // ---------------------------------------------------------------- Part 3
            System.out.println();
            int n = 5000;
            for (int w = 0; w < 300; w++) { transferAutoCommit(con, "192311002", new BigDecimal("0.01"), false); transferTx(con, "192311002", new BigDecimal("0.01"), false); }
            try (Statement st = con.createStatement()) { st.executeUpdate("UPDATE hostel_wallet SET balance = 300.00 WHERE reg_no='192311002'"); st.executeUpdate("UPDATE canteen_wallet SET balance = 50.00 WHERE reg_no='192311002'"); }
            double tAuto = Bench.timeMs(() -> { for (int i = 0; i < n; i++) transferAutoCommit(con, "192311002", new BigDecimal("0.01"), false); });
            double tTx = Bench.timeMs(() -> { for (int i = 0; i < n; i++) transferTx(con, "192311002", new BigDecimal("0.01"), false); });
            System.out.printf("PART 3 - %d transfers of two UPDATEs each%n", n);
            System.out.printf("   two auto-commit statements: %8.1f ms  (%.3f ms per transfer, 2 commits each)%n", tAuto, tAuto / n);
            System.out.printf("   one transaction           : %8.1f ms  (%.3f ms per transfer, 1 commit each)%n", tTx, tTx / n);
            Bench.csv("B3_3_transfer_speed.csv", "auto-commit (2 commits)," + n + "," + String.format("%.1f,%.3f", tAuto, tAuto / n));
            Bench.csv("B3_3_transfer_speed.csv", "transaction (1 commit)," + n + "," + String.format("%.1f,%.3f", tTx, tTx / n));
            resetWallets(con);
        }
    }
}
