import java.io.BufferedWriter;
import java.math.BigDecimal;
import java.nio.file.Files;
import java.nio.file.Path;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;

/**
 * Task B3 alternative concept - instead of PreparedStatement batches:
 *   (1) one multi-row INSERT statement per b rows, (2) LOAD DATA LOCAL INFILE.
 * Output: results/B3_alt_inserts.csv   method, rows, b, time_ms, allocated_mb
 */
public class InsertStrategies {

    static void batch(Connection con, List<String[]> rows, int b) throws SQLException {
        con.setAutoCommit(false);
        try (PreparedStatement ps = con.prepareStatement("INSERT INTO bus_pass(pass_id, reg_no, name, route_no, amount) VALUES (?,?,?,?,?)")) {
            int n = 0;
            for (String[] r : rows) {
                ps.setString(1, r[0]); ps.setString(2, r[1]); ps.setString(3, r[2]);
                ps.setInt(4, Integer.parseInt(r[3])); ps.setBigDecimal(5, new BigDecimal(r[4]));
                ps.addBatch();
                if (++n % b == 0) ps.executeBatch();
            }
            ps.executeBatch();
            con.commit();
        } finally { con.setAutoCommit(true); }
    }

    /** One INSERT ... VALUES (?,?,?,?,?),(?,?,?,?,?),... statement carrying b rows (parameters still bound, so still injection-safe). */
    static void multiRow(Connection con, List<String[]> rows, int b) throws SQLException {
        con.setAutoCommit(false);
        try {
            String head = "INSERT INTO bus_pass(pass_id, reg_no, name, route_no, amount) VALUES ";
            int i = 0;
            while (i < rows.size()) {
                int k = Math.min(b, rows.size() - i);
                StringBuilder sql = new StringBuilder(head);
                for (int j = 0; j < k; j++) sql.append(j == 0 ? "(?,?,?,?,?)" : ",(?,?,?,?,?)");
                try (PreparedStatement ps = con.prepareStatement(sql.toString())) {
                    int p = 1;
                    for (int j = 0; j < k; j++) {
                        String[] r = rows.get(i + j);
                        ps.setString(p++, r[0]); ps.setString(p++, r[1]); ps.setString(p++, r[2]);
                        ps.setInt(p++, Integer.parseInt(r[3])); ps.setBigDecimal(p++, new BigDecimal(r[4]));
                    }
                    ps.executeUpdate();
                }
                i += k;
            }
            con.commit();
        } finally { con.setAutoCommit(true); }
    }

    static void loadData(Connection con, List<String[]> rows) throws Exception {
        Path f = Bench.workDir().resolve("passes_load.csv").toAbsolutePath();
        try (BufferedWriter w = Files.newBufferedWriter(f)) {
            for (String[] r : rows) {
                w.write(r[0] + "," + r[1] + ",\"" + r[2].replace("\\", "\\\\").replace("\"", "\\\"") + "\"," + r[3] + "," + r[4]);
                w.write('\n');
            }
        }
        con.setAutoCommit(false);
        try (Statement st = con.createStatement()) {
            st.execute("LOAD DATA LOCAL INFILE '" + f.toString().replace("\\", "/") + "' INTO TABLE bus_pass "
                    + "FIELDS TERMINATED BY ',' OPTIONALLY ENCLOSED BY '\"' ESCAPED BY '\\\\' LINES TERMINATED BY '\\n' "
                    + "(pass_id, reg_no, name, route_no, amount)");
            con.commit();
        } finally { con.setAutoCommit(true); }
    }

    interface Job { void run() throws Exception; }

    static void measure(Connection con, String method, int n, int b, Job job) throws Exception {
        try (Statement st = con.createStatement()) { st.executeUpdate("TRUNCATE TABLE bus_pass"); }
        long a0 = Bench.allocatedBytes();
        double ms;
        try { ms = Bench.timeMs(job::run); }
        catch (RuntimeException e) {
            Throwable c = e.getCause() != null ? e.getCause() : e;
            System.out.printf("%-28s | b=%-6s | NOT AVAILABLE: %s%n", method, b == 0 ? "-" : b, c.getMessage().split("\n")[0]);
            Bench.csv("B3_alt_inserts.csv", method + "," + n + "," + b + ",NA,NA");
            return;
        }
        double mb = (Bench.allocatedBytes() - a0) / 1048576.0;
        try (Statement st = con.createStatement(); ResultSet rs = st.executeQuery("SELECT COUNT(*) FROM bus_pass")) {
            rs.next();
            if (rs.getInt(1) != n) throw new IllegalStateException(method + ": expected " + n + " rows, found " + rs.getInt(1));
        }
        System.out.printf("%-28s | b=%-6s | %9.1f ms | %10.0f rows/s | allocated %8.1f MB%n", method, b == 0 ? "-" : b, ms, n / (ms / 1000), mb);
        Bench.csv("B3_alt_inserts.csv", method + "," + n + "," + b + "," + String.format("%.1f,%.1f", ms, mb));
    }

    public static void main(String[] args) throws Exception {
        Bench.resetCsv("B3_alt_inserts.csv", "method,rows,b,time_ms,allocated_mb");
        int n = 100000;
        List<String[]> rows = PassData.rows(n);
        try (Connection con = Db.connect()) {
            List<String[]> w = PassData.rows(3000);
            for (int i = 0; i < 2; i++) { try (Statement st = con.createStatement()) { st.executeUpdate("TRUNCATE TABLE bus_pass"); } batch(con, w, 1000); }
            for (int i = 0; i < 2; i++) { try (Statement st = con.createStatement()) { st.executeUpdate("TRUNCATE TABLE bus_pass"); } multiRow(con, w, 1000); }
            for (int b : new int[] {100, 1000, 10000}) measure(con, "PreparedStatement batch", n, b, () -> batch(con, rows, b));
            for (int b : new int[] {100, 1000, 10000}) measure(con, "multi-row INSERT", n, b, () -> multiRow(con, rows, b));
            measure(con, "LOAD DATA LOCAL INFILE", n, 0, () -> loadData(con, rows));
            System.out.println("Row size used for the memory estimate: about " + (rows.get(0)[0].length() + rows.get(0)[1].length() + rows.get(0)[2].length() + 12 + 3 * 5)
                    + " characters of SQL text per row (so a batch of b rows buffers roughly b x 60 bytes of SQL + the driver's own copies)");
        }
    }
}
