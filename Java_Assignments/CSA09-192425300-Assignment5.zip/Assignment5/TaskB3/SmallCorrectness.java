import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/**
 * Task B3.1 - insert 10 records with Statement, PreparedStatement and a batch; check with SELECT and ResultSetMetaData
 * that every approach produces exactly the same table contents and the expected column types.
 */
public class SmallCorrectness {

    static String quote(String s) { return "'" + s.replace("\\", "\\\\").replace("'", "''") + "'"; }

    static void viaStatement(Connection con, List<String[]> rows) throws SQLException {
        try (Statement st = con.createStatement()) {
            for (String[] r : rows) {
                st.executeUpdate("INSERT INTO bus_pass(pass_id, reg_no, name, route_no, amount) VALUES ("
                        + quote(r[0]) + "," + quote(r[1]) + "," + quote(r[2]) + "," + r[3] + "," + r[4] + ")");
            }
        }
    }

    static void viaPrepared(Connection con, List<String[]> rows) throws SQLException {
        try (PreparedStatement ps = con.prepareStatement(
                "INSERT INTO bus_pass(pass_id, reg_no, name, route_no, amount) VALUES (?,?,?,?,?)")) {
            for (String[] r : rows) {
                bind(ps, r);
                ps.executeUpdate();
            }
        }
    }

    static void viaBatch(Connection con, List<String[]> rows) throws SQLException {
        try (PreparedStatement ps = con.prepareStatement(
                "INSERT INTO bus_pass(pass_id, reg_no, name, route_no, amount) VALUES (?,?,?,?,?)")) {
            for (String[] r : rows) {
                bind(ps, r);
                ps.addBatch();
            }
            int[] counts = ps.executeBatch();
            int ok = 0;
            for (int c : counts) if (c >= 0 || c == Statement.SUCCESS_NO_INFO) ok++;
            System.out.println("   executeBatch() reported " + ok + " of " + rows.size() + " statements successful");
        }
    }

    static void bind(PreparedStatement ps, String[] r) throws SQLException {
        ps.setString(1, r[0]);
        ps.setString(2, r[1]);
        ps.setString(3, r[2]);
        ps.setInt(4, Integer.parseInt(r[3]));
        ps.setBigDecimal(5, new BigDecimal(r[4]));
    }

    /** Reads the whole table back; returns one text line per row (pass_id|reg_no|name|route|amount). */
    static List<String> dump(Connection con, boolean printMeta) throws SQLException {
        List<String> out = new ArrayList<>();
        try (Statement st = con.createStatement(); ResultSet rs = st.executeQuery("SELECT * FROM bus_pass ORDER BY pass_id")) {
            ResultSetMetaData md = rs.getMetaData();
            if (printMeta) {
                System.out.println("   ResultSetMetaData of SELECT * FROM bus_pass:");
                System.out.printf("   %-3s %-14s %-10s %-10s %-9s%n", "#", "column", "SQL type", "precision", "nullable");
                for (int i = 1; i <= md.getColumnCount(); i++) {
                    System.out.printf("   %-3d %-14s %-10s %-10d %-9s%n", i, md.getColumnName(i), md.getColumnTypeName(i),
                            md.getPrecision(i), md.isNullable(i) == ResultSetMetaData.columnNullable ? "YES" : "NO");
                }
            }
            while (rs.next()) {
                out.add(rs.getString("pass_id") + "|" + rs.getString("reg_no") + "|" + rs.getString("name") + "|"
                        + rs.getInt("route_no") + "|" + rs.getBigDecimal("amount").toPlainString());
            }
        }
        return out;
    }

    public static void main(String[] args) throws Exception {
        List<String[]> rows = PassData.rows(10);
        List<String> expected = new ArrayList<>();
        for (String[] r : rows) expected.add(r[0] + "|" + r[1] + "|" + r[2] + "|" + r[3] + "|" + r[4]);
        // PassData names for ids 97.. contain commas, but with 10 rows all names are plain; both are valid for SQL anyway.

        String[] names = {"Statement", "PreparedStatement", "PreparedStatement + batch"};
        List<List<String>> results = new ArrayList<>();
        try (Connection con = Db.connect()) {
            for (int a = 0; a < 3; a++) {
                try (Statement st = con.createStatement()) { st.executeUpdate("DELETE FROM bus_pass"); }
                System.out.println("Approach " + (a + 1) + ": " + names[a]);
                if (a == 0) viaStatement(con, rows); else if (a == 1) viaPrepared(con, rows); else viaBatch(con, rows);
                List<String> got = dump(con, a == 2);
                System.out.println("   rows in table: " + got.size() + "   equal to the 10 generated records: " + got.equals(expected));
                results.add(got);
            }
            System.out.println();
            System.out.println("All three approaches produce identical table contents: " + (results.get(0).equals(results.get(1)) && results.get(1).equals(results.get(2))));
            System.out.println("Table contents (from the last approach):");
            for (String s : results.get(2)) System.out.println("   " + s);
        }
    }
}
