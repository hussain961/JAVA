#!/bin/bash
# Runs every task program, saves the console output in results/outputs/ and the measurements in results/*.csv
# Usage:  ./run_all.sh            (needs JDK 17+, a MySQL server with the test database, and the JDBC jar in lib/)
#         ./run_all.sh quick      (skips the slow 50 MB / 100,000-row / 800,000-pass measurements)
cd "$(dirname "$0")" || exit 1
MODE="$1"
JAR="${JDBC_JAR:-$(ls lib/*.jar 2>/dev/null | head -1)}"
if [ -z "$JAR" ]; then echo "No JDBC driver found. Put mysql-connector-j-*.jar in lib/ or set JDBC_JAR=/path/to.jar"; exit 1; fi
CP="out:$JAR"
SQLCLI=$(command -v mysql || command -v mariadb)

mkdir -p out results/outputs work
rm -f results/*.csv results/outputs/*.txt results/B4_1_migration_report.txt

echo "== Environment =="
{
  echo "date: $(date -u '+%Y-%m-%d %H:%M UTC')"
  echo "os: $(uname -sr) $(uname -m)"
  echo "cpu: $(grep -m1 'model name' /proc/cpuinfo 2>/dev/null | cut -d: -f2 | xargs) x $(nproc 2>/dev/null || echo ?) core(s)"
  echo "memory: $(free -m 2>/dev/null | awk '/Mem:/ {print $2 " MB"}')"
  java -version 2>&1 | head -1 | sed 's/^/java: /'
  echo "jdbc_jar: $(basename "$JAR")"
} | tee results/env.txt

echo "== Compile =="
javac --release 17 -Xlint:-unchecked -d out -cp "$CP" common/*.java TaskB1/*.java TaskB2/*.java TaskB3/*.java TaskB4/*.java \
      TaskA1/experiments/*.java TaskA4/experiments/*.java || exit 1

if [ -n "$SQLCLI" ]; then
  echo "== Reset test database =="
  $SQLCLI -u "${DB_USER:-transport}" -p"${DB_PASS:-transport123}" transport_test < db/schema.sql || { echo "could not reset the database - check db/setup_mysql_user.sql was run"; exit 1; }
else
  echo "(no mysql client found: run db/schema.sql yourself before the database tasks)"
fi

run () {   # run <label> <java args...>
  local label="$1"; shift
  echo "== $label =="
  java "$@" 2>&1 | tee "results/outputs/$label.txt"
}

run TaskB1_PassStore_complete_the_code -cp "$CP" PassStore
run TaskB1_1_tests -cp "$CP" PassStoreTest
if [ "$MODE" = "quick" ]; then run TaskB1_3_buffering -cp "$CP" BuffBench 1 10; else run TaskB1_3_buffering -cp "$CP" BuffBench; fi
run TaskB1_4_growth -cp "$CP" GrowthBench
run TaskA1_binary_layout -cp "$CP" BinaryLayoutDemo
run TaskA1_randomaccess -cp "$CP" RandomAccessBench
run TaskA4_serialization_demo -cp "$CP" SerializationDemo
run TaskA4_formats -cp "$CP" SerializationBench
echo "== TaskA4_serialVersionUID_demo =="; bash TaskA4/experiments/uid-demo/run_uid_demo.sh 2>&1 | tee results/outputs/TaskA4_serialVersionUID_demo.txt
run TaskB2_login_injection -cp "$CP" LoginDemo
run TaskB2_damaged_files -cp "$CP" BadFileDemo
run TaskB2_escaping_weakness -cp "$CP" EscapingWeakness
run TaskB3_1_correctness -cp "$CP" SmallCorrectness
if [ "$MODE" = "quick" ]; then run TaskB3_2_inserts -cp "$CP" LoadBench 1000 10000; else run TaskB3_2_inserts -cp "$CP" LoadBench; fi
run TaskB3_3_transactions -cp "$CP" TransactionDemo
run TaskB3_alt_insert_strategies -cp "$CP" InsertStrategies
run TaskB4_1_generate -cp "$CP" GenerateMigrationData
run TaskB4_1_migrate -cp "$CP" Migrate
run TaskB4_2_metadata -cp "$CP" DbInfo
run TaskB4_3_concurrency -cp "$CP" ConcurrencyDemo
if [ "$MODE" = "quick" ]; then echo "(quick mode: ScaleDecision skipped)"; else run TaskB4_3_scale -Xmx2g -cp "$CP" ScaleDecision; fi

echo "== Finished. Measurements: results/*.csv   Console output: results/outputs/*.txt =="
