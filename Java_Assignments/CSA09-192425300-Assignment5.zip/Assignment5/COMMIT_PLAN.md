# Suggested commit plan

Make **one commit per step as you finish it** on your own computer (do not commit everything at once and do not change commit dates).
Short, specific messages show how the work developed.

| # | Commit message | Files |
|:-:|:---|:---|
| 1 | `Add project skeleton, schema and README` | `README.md`, `db/`, `common/`, `.gitignore` |
| 2 | `Task A1: record layouts and file operations` | `TaskA1/answer.md` |
| 3 | `Task A1: fixed-length RandomAccessFile alternative with measurements` | `TaskA1/experiments/` |
| 4 | `Task A2: buffering prediction and redesign` | `TaskA2/answer.md` |
| 5 | `Task A3: DAO pattern design` | `TaskA3/answer.md` |
| 6 | `Task A4: serialization of the hostel graph and serialVersionUID plan` | `TaskA4/` |
| 7 | `Task A5: transaction design and injection analysis` | `TaskA5/answer.md` |
| 8 | `B1: complete PassStore.find (TODO 1)` | `TaskB1/PassStore.java` |
| 9 | `B1: BusPassFileStore with escaping, CRC and recovery` | `TaskB1/BusPassFileStore.java` |
| 10 | `B1.1: validation tests` | `TaskB1/PassStoreTest.java` |
| 11 | `B1.3/B1.4: buffering and growth measurements` | `TaskB1/*Bench.java`, `LineCounter.java`, `results/` |
| 12 | `B2: injection and damaged-file experiments` | `TaskB2/` |
| 13 | `B3: complete PassLoader.loadAll (TODO 1-3)` | `TaskB3/PassLoader.java` |
| 14 | `B3.1-B3.3: correctness, timing and rollback experiments` | `TaskB3/` |
| 15 | `B4: migration with rejected-line report and DatabaseMetaData` | `TaskB4/Migrate.java`, `DbInfo.java`, `GenerateMigrationData.java` |
| 16 | `B4.3: concurrency and scale experiments, decision` | `TaskB4/ConcurrencyDemo.java`, `ScaleDecision.java` |
| 17 | `Add my own run results and screenshots` | `results/`, `screenshots/` |
| 18 | `Add assignment report` | `report/Assignment5_Report.docx` |
