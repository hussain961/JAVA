Put the MySQL JDBC driver jar in this folder, for example:   mysql-connector-j-8.4.0.jar
Download: https://dev.mysql.com/downloads/connector/j/  (choose "Platform Independent", unpack the zip, copy the .jar here)
run_all.sh uses the first .jar it finds in this folder (or the path in the JDBC_JAR environment variable).
