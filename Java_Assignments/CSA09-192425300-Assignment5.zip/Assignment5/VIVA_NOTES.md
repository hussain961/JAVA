# Viva preparation – questions you may be asked and short answers

You may be asked to **explain, run or modify** any program. Practise running each one and saying out loud what the output proves.

**Files and streams**
1. *Why did you use `|` and not a comma?* Names such as "Kumar, Arun" contain commas; the supplied `PassStore` loses such a pass (test C4). `|` is rarer and, anyway, escaped as `\|`.
2. *What does the CRC field do?* It detects a half-written, edited or bit-flipped line; the field count alone only checks the shape (B2: `abc` as an amount passes the field-count test).
3. *What happens after a power failure in the middle of an append?* The last line has no `\n` and fails the CRC. The next `add` writes a `\n` first so it is not glued to the half line; `repairTail()` can truncate it. (Tests T13–T16.)
4. *Why is unbuffered `read()` slow?* Every call is a system call: 52,428,801 calls for 50 MB. A buffer turns it into 800–6,400 calls. (B1.3)
5. *When does buffering not help?* When you already read in big blocks, or with random access / seeks.
6. *Why is `find` O(n)? How would you make it O(1)?* It scans line by line. A `HashMap` index (O(n) memory) or fixed-length records with ids that encode the position.
7. *Why does `PassStore.find` keep going after a damaged line?* `split(",", -1)` gives an array whose length is not 5 → `continue` → next line; no exception is thrown.
8. *Why `transient` on password and connection? What if you forget?* Secrets must not be written; `Connection` is not `Serializable` → `NotSerializableException`.
9. *What is `serialVersionUID` for?* Without it, adding a field changes the computed id and old files fail with `InvalidClassException`; with `1L` the old file loads and the new field is `null`. (A4.2 demo)

**JDBC**
10. *Why is `PreparedStatement` safer?* The SQL text is fixed first; values are sent as data, so `' OR '1'='1` is just a password that matches nothing.
11. *Is it faster than `Statement`?* Not when each row is executed alone (B3.2: about the same). The big gains come from **batching** and from **one transaction** instead of a commit per row.
12. *Explain `PassLoader.loadAll`.* `setAutoCommit(false)`; bind five parameters, `addBatch`, `executeBatch` every 1,000 rows and at the end; `commit()`; in `catch`, `rollback()` then re-throw; `finally` restores auto-commit.
13. *Show that the rollback works.* `TransactionDemo` part 1: with auto-commit 2,000 rows remain after the bad row; with `loadAll` 0.
14. *Why is the transaction not slower for the wallet transfer?* One commit (one log flush) instead of two.
15. *What did the stacked `DROP TABLE` test show?* It depends on the driver setting `allowMultiQueries`; a performance option (`rewriteBatchedStatements`) changed it in the MariaDB driver. The real defence is parameters + least privilege.
16. *Why a database for 12 campuses?* Concurrent counters produced duplicate passes with a file (6–27 per trial) but never with a primary key; lookup ~0.05 ms vs ~40 ms; but for one desk and 8,000 passes a file is fine.
17. *What does `DatabaseMetaData` give you?* Product/driver version, supported features (transactions, batches), isolation level, tables/columns/keys – to check portability and a migration.

**Be ready for modifications** such as: change the batch size, add a column (what changes in `PassLoader`, the schema, `Migrate`?), add a new rejection reason in `BusPassFileStore.decode`, add a new route report query with an index.
