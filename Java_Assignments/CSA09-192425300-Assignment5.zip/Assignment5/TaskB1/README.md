# Task B1 – Build and validate the file store

| File | Purpose | Run |
|:---|:---|:---|
| `PassStore.java` | **Complete the Code** – TODO 1 (`find`) completed, rest unchanged | `java -cp out PassStore` → prints `[P1003, 192311003, Divya, 7, 3800.0]` then `null` |
| `BusPassFileStore.java` | implementation of the Task A1 design (escaping, CRC-32, validation, recovery) | used by the other programs |
| `PassStoreTest.java` | B1.1 – 22 checks (expected vs actual); exit code 1 on failure | `java -cp out PassStoreTest` |
| `LineCounter.java`, `BuffBench.java` | B1.3 – buffering on 1 / 10 / 50 MB logs → `results/B1_3_buffering.csv` | `java -cp out BuffBench` (or `BuffBench 1 10` for a quick run) |
| `GrowthBench.java` | B1.4 – find time for 1,000 … 100,000 records, plus the HashMap alternative | `java -cp out GrowthBench` |

Screenshots to take: PassStore output; PassStoreTest table; BuffBench table; GrowthBench table.
