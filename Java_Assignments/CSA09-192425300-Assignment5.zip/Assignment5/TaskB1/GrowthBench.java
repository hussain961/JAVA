import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

/**
 * Task B1.4 (+ alternative concept of B1) - how long does find() take as the file grows from 1,000 to 100,000 records,
 * and what changes if the file is read once into a HashMap?
 *
 * Output: results/B1_4_growth.csv      n, file_kb, store, case, time_ms
 *         results/B1_alt_hashmap.csv   n, q, scan_ms, build_ms, lookups_ms, hashmap_total_ms, heap_mb
 */
public class GrowthBench {

    static void csvFile(Path f, List<BusPassFileStore.Pass> passes) throws IOException {
        // same layout as PassStore (comma separated, 5 fields); commas/bars removed from names so every line is valid
        try (BufferedWriter w = Files.newBufferedWriter(f)) {
            for (BusPassFileStore.Pass p : passes) {
                w.write(String.join(",", p.passId(), p.regNo(), p.name().replace(',', ' ').replace('|', ' '),
                        String.valueOf(p.route()), p.amount().toPlainString()));
                w.newLine();
            }
        }
    }

    static Map<String, String[]> loadMap(Path f) throws IOException {
        Map<String, String[]> m = new HashMap<>();
        try (BufferedReader r = Files.newBufferedReader(f)) {
            String line;
            while ((line = r.readLine()) != null) {
                String[] a = line.split(",", -1);
                if (a.length == 5) m.put(a[0], a);
            }
        }
        return m;
    }

    static double heapMb() {
        System.gc(); System.gc();
        Runtime rt = Runtime.getRuntime();
        return (rt.totalMemory() - rt.freeMemory()) / 1048576.0;
    }

    public static void main(String[] args) throws Exception {
        Bench.resetCsv("B1_4_growth.csv", "n,file_kb,store,case,time_ms");
        Bench.resetCsv("B1_alt_hashmap.csv", "n,q,scan_ms,build_ms,lookups_ms,hashmap_total_ms,heap_mb");
        int[] sizes = {1000, 5000, 10000, 50000, 100000};
        int q = 100;

        // JIT warm-up on a throw-away file so that the first measured size is not penalised
        {
            List<BusPassFileStore.Pass> w = PassData.passes(20000);
            Path wc = Bench.workDir().resolve("warm_csv.csv"), wt = Bench.workDir().resolve("warm_txt.txt");
            Files.deleteIfExists(wt);
            csvFile(wc, w);
            new BusPassFileStore(wt).appendAll(w, false);
            PassStore g = new PassStore(wc);
            BusPassFileStore f = new BusPassFileStore(wt);
            for (int i = 0; i < 80; i++) { g.find("P999999"); f.find("P999999"); f.find(PassData.passId(10)); }
        }

        for (int n : sizes) {
            List<BusPassFileStore.Pass> passes = PassData.passes(n);
            Path csv = Bench.workDir().resolve("growth_csv_" + n + ".csv");
            Path txt = Bench.workDir().resolve("growth_txt_" + n + ".txt");
            Files.deleteIfExists(txt);
            csvFile(csv, passes);
            new BusPassFileStore(txt).appendAll(passes, false);
            long kb = Files.size(txt) / 1024;

            PassStore given = new PassStore(csv);
            BusPassFileStore full = new BusPassFileStore(txt);
            String[][] cases = {
                    {"first record", PassData.passId(1)},
                    {"middle record", PassData.passId(n / 2)},
                    {"last record", PassData.passId(n)},
                    {"not found", "P999999"}};
            for (int i = 0; i < 3; i++) { given.find(PassData.passId(n)); full.find(PassData.passId(n)); }   // warm-up

            for (String[] c : cases) {
                double tGiven = Bench.medianMs(11, () -> given.find(c[1]));
                double tFull = Bench.medianMs(11, () -> full.find(c[1]));
                System.out.printf("n=%7d | %-13s | PassStore.find %9.3f ms | BusPassFileStore.find %9.3f ms%n", n, c[0], tGiven, tFull);
                Bench.csv("B1_4_growth.csv", n + "," + kb + ",PassStore," + c[0] + "," + String.format("%.3f", tGiven));
                Bench.csv("B1_4_growth.csv", n + "," + kb + ",BusPassFileStore," + c[0] + "," + String.format("%.3f", tFull));
            }

            // ---- alternative: HashMap loaded once
            Random r = new Random(7);
            String[] ids = new String[q];
            for (int i = 0; i < q; i++) ids[i] = PassData.passId(1 + r.nextInt(n));
            double scanMs = Bench.timeMs(() -> { for (String id : ids) given.find(id); });
            double before = heapMb();
            Object[] holder = new Object[1];
            double buildMs = Bench.timeMs(() -> holder[0] = loadMap(csv));
            double heap = Math.max(0, heapMb() - before);
            @SuppressWarnings("unchecked") Map<String, String[]> map = (Map<String, String[]>) holder[0];
            double lookMs = Bench.timeMs(() -> { for (String id : ids) if (map.get(id) == null) throw new IllegalStateException(id); });
            System.out.printf("n=%7d | q=%d searches: scan %9.1f ms | HashMap build %8.1f ms + lookups %6.3f ms = %8.1f ms | heap %.1f MB%n",
                    n, q, scanMs, buildMs, lookMs, buildMs + lookMs, heap);
            Bench.csv("B1_alt_hashmap.csv", n + "," + q + "," + String.format("%.1f,%.1f,%.3f,%.1f,%.1f", scanMs, buildMs, lookMs, buildMs + lookMs, heap));
            if (map.size() != n) throw new IllegalStateException("map size " + map.size());
        }
    }
}
