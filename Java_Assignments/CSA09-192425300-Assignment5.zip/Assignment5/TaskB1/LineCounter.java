import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

/**
 * Task A2 / B1.3 - five ways to count the lines of a large attendance log.
 * Every method returns the number of lines; {@link #lastReadCalls} holds the
 * number of read() calls issued by the most recent counting method.
 */
public final class LineCounter {
    private LineCounter() { }

    /** Number of read calls made by the last count*() method (instrumentation for the A2.1 prediction). */
    public static long lastReadCalls;

    /** A2.1 program: FileInputStream.read() one byte at a time - every call goes to the operating system. */
    public static long countUnbuffered(Path p) throws IOException {
        long lines = 0, calls = 0;
        int prev = '\n', b;
        try (FileInputStream in = new FileInputStream(p.toFile())) {
            while ((b = in.read()) != -1) {
                calls++;
                if (b == '\n') lines++;
                prev = b;
            }
            calls++;                         // the final call that returned -1
        }
        if (prev != '\n') lines++;           // last line without a trailing newline
        lastReadCalls = calls;
        return lines;
    }

    /** Same single-byte API, but behind a BufferedInputStream (8 KiB buffer): the OS is called once per 8 KiB. */
    public static long countBufferedStream(Path p) throws IOException {
        long lines = 0, calls = 0;
        int prev = '\n', b;
        try (BufferedInputStream in = new BufferedInputStream(new FileInputStream(p.toFile()))) {
            while ((b = in.read()) != -1) {
                calls++;                     // calls to BufferedInputStream.read(); OS calls are ~ size/8192
                if (b == '\n') lines++;
                prev = b;
            }
        }
        if (prev != '\n') lines++;
        lastReadCalls = (Files.size(p) + 8191) / 8192 + 1;   // actual OS-level reads
        return lines;
    }

    /** A2.2 redesign: read big chunks into a byte[] buffer and scan the buffer in memory. */
    public static long countChunks(Path p, int bufSize) throws IOException {
        long lines = 0, calls = 0;
        byte[] buf = new byte[bufSize];
        int prev = '\n', n;
        try (FileInputStream in = new FileInputStream(p.toFile())) {
            while ((n = in.read(buf)) != -1) {
                calls++;
                for (int i = 0; i < n; i++) if (buf[i] == '\n') lines++;
                prev = buf[n - 1];
            }
        }
        if (prev != '\n') lines++;
        lastReadCalls = calls + 1;
        return lines;
    }

    /** The usual idiom: BufferedReader.readLine() (decodes bytes to characters as well). */
    public static long countBufferedReader(Path p) throws IOException {
        long lines = 0;
        try (BufferedReader r = Files.newBufferedReader(p)) {
            while (r.readLine() != null) lines++;
        }
        lastReadCalls = (Files.size(p) + 8191) / 8192 + 1;
        return lines;
    }

    /** Alternative concept: load every line into memory at once. Memory grows with the file size. */
    public static long countReadAllLines(Path p) throws IOException {
        lastReadCalls = (Files.size(p) + 8191) / 8192 + 1;
        return Files.readAllLines(p).size();
    }
}
