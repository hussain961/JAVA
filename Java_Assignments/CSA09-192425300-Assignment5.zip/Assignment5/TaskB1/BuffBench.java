import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Random;

/**
 * Task B1.3 (and Task A2 alternative) - measures the effect of buffering on a line-count program
 * for files of 1 MB, 10 MB and 50 MB (1 MB = 1,048,576 bytes; every line is exactly 64 bytes).
 *
 * Output: results/B1_3_buffering.csv with columns
 *   size_mb, method, lines, read_calls, time_ms, allocated_mb
 */
public class BuffBench {

    static final int LINE_BYTES = 64;

    /** Creates (or re-uses) an attendance log of exactly sizeMb MiB, 64 bytes per line. */
    static Path makeLog(int sizeMb) throws IOException {
        Path f = Bench.workDir().resolve("attendance_" + sizeMb + "mb.log");
        long want = sizeMb * 1024L * 1024L;
        if (Files.exists(f) && Files.size(f) == want) return f;
        Random r = new Random(42);
        String[] gates = {"GATE-01", "GATE-02", "GATE-03", "LIBRARY", "HOSTEL-A", "HOSTEL-B"};
        try (BufferedWriter w = Files.newBufferedWriter(f)) {
            long lines = want / LINE_BYTES;
            for (long i = 0; i < lines; i++) {
                String s = String.format("2026-11-%02d,%d,%02d:%02d:%02d,%s,%s",
                        1 + r.nextInt(28), 192300000 + r.nextInt(99999), r.nextInt(24), r.nextInt(60), r.nextInt(60),
                        r.nextBoolean() ? "IN" : "OUT", gates[r.nextInt(gates.length)]);
                w.write(String.format("%-" + (LINE_BYTES - 1) + "s", s));   // pad to 63 chars
                w.write('\n');
            }
        }
        return f;
    }

    interface Counter { long count(Path p) throws IOException; }

    static void measure(int sizeMb, Path f, String method, int runs, Counter c) throws Exception {
        long lines = 0;
        double[] t = new double[runs];
        long alloc = 0;
        for (int i = 0; i < runs; i++) {
            long a0 = Bench.allocatedBytes();
            long t0 = System.nanoTime();
            lines = c.count(f);
            t[i] = (System.nanoTime() - t0) / 1e6;
            alloc = Bench.allocatedBytes() - a0;
        }
        java.util.Arrays.sort(t);
        double med = t[runs / 2];
        long calls = LineCounter.lastReadCalls;
        System.out.printf("%4d MB | %-34s | lines=%9d | read calls=%11d | %10.1f ms | allocated %8.1f MB%n",
                sizeMb, method, lines, calls, med, alloc / 1048576.0);
        Bench.csv("B1_3_buffering.csv", sizeMb + "," + method + "," + lines + "," + calls + "," + String.format("%.1f", med)
                + "," + String.format("%.1f", alloc / 1048576.0));
    }

    public static void main(String[] args) throws Exception {
        Bench.resetCsv("B1_3_buffering.csv", "size_mb,method,lines,read_calls,time_ms,allocated_mb");
        int[] sizes = args.length > 0 ? java.util.Arrays.stream(args).mapToInt(Integer::parseInt).toArray() : new int[] {1, 10, 50};

        // warm-up so that JIT compilation does not distort the first measurement
        Path warm = makeLog(1);
        for (int i = 0; i < 3; i++) {
            LineCounter.countUnbuffered(warm); LineCounter.countChunks(warm, 65536);
            LineCounter.countBufferedStream(warm); LineCounter.countBufferedReader(warm); LineCounter.countReadAllLines(warm);
        }

        for (int mb : sizes) {
            Path f = makeLog(mb);
            long expectedLines = Files.size(f) / LINE_BYTES;
            int runs = mb >= 50 ? 3 : 5;
            measure(mb, f, "unbuffered read() one byte", runs, LineCounter::countUnbuffered);
            measure(mb, f, "BufferedInputStream.read() 8 KiB", runs, LineCounter::countBufferedStream);
            measure(mb, f, "FileInputStream + byte[8192]", runs, p -> LineCounter.countChunks(p, 8192));
            measure(mb, f, "FileInputStream + byte[65536]", runs, p -> LineCounter.countChunks(p, 65536));
            measure(mb, f, "BufferedReader.readLine()", runs, LineCounter::countBufferedReader);
            measure(mb, f, "Files.readAllLines()", runs, LineCounter::countReadAllLines);
            System.out.println("       (expected line count = " + expectedLines + ")");
        }
    }
}
