import java.io.IOException;
import java.math.BigDecimal;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/**
 * Task B1.1 - validation tests for the bus-pass file stores.
 * Prints a table: test id, scenario, expected, actual, PASS/FAIL.
 * Exit code is 1 if any test fails.
 */
public class PassStoreTest {

    static final List<String[]> rows = new ArrayList<>();
    static int failures = 0;

    static void check(String id, String scenario, Object expected, Object actual) {
        String e = String.valueOf(expected), a = String.valueOf(actual);
        boolean ok = e.equals(a);
        if (!ok) failures++;
        rows.add(new String[] {id, scenario, e, a, ok ? "PASS" : "FAIL"});
    }

    /** A weakness of the given design that is demonstrated on purpose: shown as LIMITATION, not counted as a failure. */
    static void limit(String id, String scenario, Object ideal, Object actual) {
        String e = String.valueOf(ideal), a = String.valueOf(actual);
        rows.add(new String[] {id, scenario, e + "   (ideal behaviour)", a, e.equals(a) ? "PASS" : "LIMITATION"});
    }

    static BusPassFileStore.Pass pass(String id, int route, String name) {
        return new BusPassFileStore.Pass(id, "192311001", name, route, "Guindy",
                LocalDate.of(2027, 3, 31), new BigDecimal("4500.00"));
    }

    static Path temp(String name) throws IOException {
        Path f = Bench.workDir().resolve(name);
        Files.deleteIfExists(f);
        return f;
    }

    /** Appends a hand-made line to a file (used to inject damage). */
    static void raw(Path f, String text) throws IOException {
        Files.writeString(f, text, StandardCharsets.UTF_8, StandardOpenOption.CREATE, StandardOpenOption.APPEND);
    }

    /** Builds a line with a CORRECT checksum around the given body, so only the field itself is wrong. */
    static String lineWithValidCrc(String body) { return body + "|" + BusPassFileStore.crcHex(body); }

    public static void main(String[] args) throws Exception {
        // ---------------------------------------------------------------- BusPassFileStore
        Path f = temp("t1.txt");
        BusPassFileStore s = new BusPassFileStore(f);
        s.add(pass("P001001", 12, "Arun Kumar"));
        s.add(pass("P001002", 12, "Divya Raj"));
        s.add(pass("P001003", 7, "Karthik Nair"));
        s.add(pass("P001004", 12, "Meena Iyer"));

        check("T1", "add then find an existing pass (P001003)", "Karthik Nair", s.find("P001003").map(BusPassFileStore.Pass::name).orElse("-"));
        check("T2", "list all passes on route 12", "[P001001, P001002, P001004]",
                s.listByRoute(12).stream().map(BusPassFileStore.Pass::passId).toList());
        check("T3", "find a pass id that does not exist", "Optional.empty", s.find("P999999"));
        check("T4", "find when the file does not exist", "Optional.empty",
                new BusPassFileStore(temp("missing.txt")).find("P001001"));

        // duplicate / invalid input on add
        String dup;
        try { s.add(pass("P001001", 5, "Someone Else")); dup = "accepted"; } catch (IllegalStateException e) { dup = "rejected: duplicate"; }
        check("T5", "add a pass whose id already exists", "rejected: duplicate", dup);
        String inv;
        try { s.add(pass("P001010", 0, "Bad Route")); inv = "accepted"; } catch (IllegalArgumentException e) { inv = "rejected: " + e.getMessage(); }
        check("T6", "add a pass with route 0", "rejected: invalid pass: BAD_ROUTE", inv);

        // names that contain the delimiter, a comma and a backslash
        String tricky = "Ravi|Kumar, Jr\\X";
        s.add(pass("P001020", 3, tricky));
        check("T7", "name containing | , and \\ survives a round trip", tricky,
                s.find("P001020").map(BusPassFileStore.Pass::name).orElse("-"));

        // ---------------------------------------------------------------- damaged data
        Path d = temp("t2.txt");
        BusPassFileStore ds = new BusPassFileStore(d);
        ds.add(pass("P002001", 1, "First Valid"));
        raw(d, "P002002|192311002|Short Line\n");                                   // wrong field count
        raw(d, "\n");                                                                // empty line
        raw(d, lineWithValidCrc("P002003|192311003|Bad Amount|4|Guindy|2027-03-31|abc") + "\n");   // non-numeric amount, valid crc
        raw(d, "P002004|192311004|Edited By Hand|4|Guindy|2027-03-31|4500.00|deadbeef\n");          // checksum does not match
        raw(d, lineWithValidCrc("P002005|192311005|Bad Date|4|Guindy|2027-13-45|4500.00") + "\n");  // impossible date
        ds.add(pass("P002006", 9, "Last Valid"));

        BusPassFileStore.ScanReport rep = ds.verify();
        check("T8", "verify(): lines / valid / damaged", "lines=7 valid=2 damaged=5", "lines=" + rep.lines + " valid=" + rep.valid + " damaged=" + rep.damaged);
        check("T9", "damaged reasons recorded", "{EMPTY_LINE=1, WRONG_FIELD_COUNT=1, CRC_MISMATCH=1, BAD_DATE=1, BAD_AMOUNT=1}", rep.byReason);
        check("T10", "a valid pass AFTER the damaged lines is still found", "Last Valid",
                ds.find("P002006").map(BusPassFileStore.Pass::name).orElse("-"));
        check("T11", "a pass whose line is damaged (bad crc) is not returned", "Optional.empty", ds.find("P002004"));
        check("T12", "damaged line with matching id is counted as skipped", "1", ds.lastDamagedCount());

        // ---------------------------------------------------------------- power failure (half-written last line)
        Path p = temp("t3.txt");
        BusPassFileStore ps = new BusPassFileStore(p);
        ps.add(pass("P003001", 2, "Before Crash"));
        String full = BusPassFileStore.encode(pass("P003002", 2, "Half Written"));
        raw(p, full.substring(0, full.length() / 2));                                // no newline, cut in the middle
        check("T13", "half-written tail is detected (file does not end with newline)", "false", ps.verify().endsWithNewline);
        check("T14", "all complete records before the tail are still readable", "Before Crash",
                ps.find("P003001").map(BusPassFileStore.Pass::name).orElse("-"));
        ps.add(pass("P003003", 2, "After Crash"));                                    // must NOT be glued to the half line
        BusPassFileStore.ScanReport r3 = ps.verify();
        check("T15", "next add is not glued to the half line", "lines=3 valid=2 damaged=1", "lines=" + r3.lines + " valid=" + r3.valid + " damaged=" + r3.damaged);
        Path q = temp("t4.txt");
        BusPassFileStore qs = new BusPassFileStore(q);
        qs.add(pass("P004001", 2, "Before Crash"));
        raw(q, full.substring(0, 20));
        boolean truncated = qs.repairTail();
        BusPassFileStore.ScanReport r4 = qs.verify();
        check("T16", "repairTail() removes the half line", "true lines=1 damaged=0 endsWithNewline=true",
                truncated + " lines=" + r4.lines + " damaged=" + r4.damaged + " endsWithNewline=" + r4.endsWithNewline);

        // invalid UTF-8 byte inside a record must not abort the scan
        Path u = temp("t5.txt");
        BusPassFileStore us = new BusPassFileStore(u);
        us.add(pass("P005001", 2, "Good One"));
        Files.write(u, new byte[] {'P', '0', '0', '5', '0', '0', '2', '|', (byte) 0xC3, (byte) 0x28, '\n'}, StandardOpenOption.APPEND);
        us.add(pass("P005003", 2, "Good Two"));
        check("T17", "invalid UTF-8 bytes: scan continues, 2 valid / 1 damaged", "valid=2 damaged=1",
                "valid=" + us.verify().valid + " damaged=" + us.verify().damaged);

        // ---------------------------------------------------------------- the given PassStore (comma format)
        Path c = temp("c1.csv");
        PassStore cs = new PassStore(c);
        cs.add("P1001", "192311001", "Arun", 12, 4500);
        raw(c, "P1002,DAMAGED LINE\n");
        cs.add("P1003", "192311003", "Divya", 7, 3800);
        check("C1", "PassStore: find an existing pass", "[P1003, 192311003, Divya, 7, 3800.0]", java.util.Arrays.toString(cs.find("P1003")));
        check("C2", "PassStore: find an id that does not exist", "null", java.util.Arrays.toString(cs.find("P7777")));
        check("C3", "PassStore: damaged line (2 fields) is skipped, not returned", "null", java.util.Arrays.toString(cs.find("P1002")));
        cs.add("P1004", "192311004", "Kumar, Arun", 5, 4000);                          // name contains the delimiter
        limit("C4", "PassStore: name with a comma makes a valid pass unfindable", "[P1004, 192311004, Kumar, Arun, 5, 4000.0]",
                java.util.Arrays.toString(cs.find("P1004")));
        raw(c, "P1005,192311005,Eve,6,abc\n");                                          // 5 fields but amount is not a number
        limit("C5", "PassStore: a line with a non-numeric amount is accepted as valid", "null", java.util.Arrays.toString(cs.find("P1005")));

        // ---------------------------------------------------------------- print the table
        System.out.printf("%-4s | %-70s | %-10s%n", "ID", "Scenario", "Result");
        System.out.println("-----+" + "-".repeat(72) + "+-----------");
        for (String[] r : rows) System.out.printf("%-4s | %-70s | %-10s%n", r[0], r[1], r[4]);
        System.out.println();
        System.out.println("Details (expected vs actual):");
        for (String[] r : rows) {
            System.out.println(r[0] + "  expected: " + r[2]);
            System.out.println(r[0] + "  actual  : " + r[3]);
        }
        System.out.println();
        System.out.println(failures == 0 ? "ALL " + rows.size() + " CHECKS PASSED" : failures + " CHECK(S) FAILED");
        System.exit(failures == 0 ? 0 : 1);
    }
}
