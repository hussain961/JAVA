import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.RandomAccessFile;
import java.math.BigDecimal;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;
import java.nio.charset.CodingErrorAction;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.regex.Pattern;
import java.util.zip.CRC32;

/**
 * Bus-pass file store that implements the Task A1 design (delimited text file).
 *
 * One record per line, UTF-8, fields separated by '|':
 *
 *   passId|regNo|name|route|boardingStop|validUntil|amount|crc32
 *
 * - '|' , '\' and line breaks inside a field are escaped as \| , \\ , \n , \r
 * - the last field is the CRC-32 of everything before the final '|' (8 hex digits),
 *   so a damaged or half-written line is detected instead of being trusted
 * - find() and listByRoute() skip damaged lines and count them
 * - an append is a single write followed by force(), and a half-written tail is
 *   isolated (never glued to the next record)
 */
public class BusPassFileStore {

    /** One validated bus-pass record (Serializable so the same class can be used in later experiments). */
    public record Pass(String passId, String regNo, String name, int route, String stop,
                       LocalDate validUntil, BigDecimal amount) implements java.io.Serializable { }

    /** Why a line was rejected. */
    public enum Reason {
        EMPTY_LINE, WRONG_FIELD_COUNT, BAD_ESCAPE, CRC_MISMATCH,
        BAD_ID, BAD_REGNO, BAD_NAME, BAD_ROUTE, BAD_STOP, BAD_DATE, BAD_AMOUNT
    }

    /** Result of decoding one line: either a Pass or a Reason. */
    public static final class Result {
        public final Pass pass;
        public final Reason reason;
        Result(Pass p, Reason r) { pass = p; reason = r; }
        public boolean ok() { return pass != null; }
        @Override public String toString() { return ok() ? "OK " + pass.passId() : "REJECT " + reason; }
    }

    /** Summary produced by verify(). */
    public static final class ScanReport {
        public int lines, valid, damaged;
        public boolean endsWithNewline = true;
        public final Map<Reason, Integer> byReason = new EnumMap<>(Reason.class);
        @Override public String toString() {
            return "lines=" + lines + " valid=" + valid + " damaged=" + damaged
                    + " endsWithNewline=" + endsWithNewline + " " + byReason;
        }
    }

    private static final Pattern ID = Pattern.compile("P\\d{4,8}");
    private static final Pattern REG = Pattern.compile("\\d{9}");

    private final Path file;
    private int lastDamaged;

    public BusPassFileStore(Path file) { this.file = file; }

    public int lastDamagedCount() { return lastDamaged; }

    // ------------------------------------------------------------------ encoding

    static String escape(String s) {
        StringBuilder b = new StringBuilder(s.length() + 4);
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            switch (c) {
                case '\\': b.append("\\\\"); break;
                case '|':  b.append("\\|");  break;
                case '\n': b.append("\\n");  break;
                case '\r': b.append("\\r");  break;
                default:   b.append(c);
            }
        }
        return b.toString();
    }

    static String crcHex(String body) {
        CRC32 c = new CRC32();
        c.update(body.getBytes(StandardCharsets.UTF_8));
        return String.format("%08x", c.getValue());
    }

    /** Builds the line (without the final newline) for a pass. */
    public static String encode(Pass p) {
        String body = String.join("|", escape(p.passId()), escape(p.regNo()), escape(p.name()),
                String.valueOf(p.route()), escape(p.stop()), p.validUntil().toString(), p.amount().toPlainString());
        return body + "|" + crcHex(body);
    }

    /** Parses and validates one line. Never throws: damaged input becomes a Reason. */
    public static Result decode(String line) {
        if (line == null || line.isBlank()) return new Result(null, Reason.EMPTY_LINE);

        // find the last unescaped '|' (it separates the body from the CRC)
        int lastBar = -1;
        for (int i = 0; i < line.length(); i++) {
            char c = line.charAt(i);
            if (c == '\\') { i++; continue; }
            if (c == '|') lastBar = i;
        }
        if (lastBar < 0) return new Result(null, Reason.WRONG_FIELD_COUNT);
        String body = line.substring(0, lastBar);
        String crc = line.substring(lastBar + 1);

        // split the body on unescaped '|' and unescape each field
        List<String> f = new ArrayList<>(7);
        StringBuilder cur = new StringBuilder();
        for (int i = 0; i < body.length(); i++) {
            char c = body.charAt(i);
            if (c == '\\') {
                if (i + 1 >= body.length()) return new Result(null, Reason.BAD_ESCAPE);
                char n = body.charAt(++i);
                switch (n) {
                    case '\\': cur.append('\\'); break;
                    case '|':  cur.append('|');  break;
                    case 'n':  cur.append('\n'); break;
                    case 'r':  cur.append('\r'); break;
                    default:   return new Result(null, Reason.BAD_ESCAPE);
                }
            } else if (c == '|') {
                f.add(cur.toString());
                cur.setLength(0);
            } else {
                cur.append(c);
            }
        }
        f.add(cur.toString());
        if (f.size() != 7) return new Result(null, Reason.WRONG_FIELD_COUNT);
        if (!crc.equals(crcHex(body))) return new Result(null, Reason.CRC_MISMATCH);

        String id = f.get(0), reg = f.get(1), name = f.get(2), stop = f.get(4);
        if (!ID.matcher(id).matches()) return new Result(null, Reason.BAD_ID);
        if (!REG.matcher(reg).matches()) return new Result(null, Reason.BAD_REGNO);
        if (name.isBlank() || name.length() > 60) return new Result(null, Reason.BAD_NAME);
        int route;
        try { route = Integer.parseInt(f.get(3)); } catch (NumberFormatException e) { return new Result(null, Reason.BAD_ROUTE); }
        if (route < 1 || route > 99) return new Result(null, Reason.BAD_ROUTE);
        if (stop.isBlank() || stop.length() > 40) return new Result(null, Reason.BAD_STOP);
        LocalDate valid;
        try { valid = LocalDate.parse(f.get(5)); } catch (DateTimeParseException e) { return new Result(null, Reason.BAD_DATE); }
        BigDecimal amount;
        try { amount = new BigDecimal(f.get(6)); } catch (NumberFormatException e) { return new Result(null, Reason.BAD_AMOUNT); }
        if (amount.signum() < 0 || amount.scale() > 2 || amount.compareTo(new BigDecimal("99999.99")) > 0) {
            return new Result(null, Reason.BAD_AMOUNT);
        }
        return new Result(new Pass(id, reg, name, route, stop, valid, amount), null);
    }

    // ------------------------------------------------------------------ operations

    /** (i) Add a new pass. Rejects invalid data and duplicate pass ids. Durable when it returns. */
    public void add(Pass p) throws IOException {
        Result check = decode(encode(p));
        if (!check.ok()) throw new IllegalArgumentException("invalid pass: " + check.reason);
        if (find(p.passId()).isPresent()) throw new IllegalStateException("duplicate pass id " + p.passId());
        append(encode(p) + "\n", true);
    }

    /** Bulk append without the duplicate scan (used for test-data generation); one force() at the end. */
    public void appendAll(Collection<Pass> passes, boolean sync) throws IOException {
        StringBuilder sb = new StringBuilder(passes.size() * 90);
        for (Pass p : passes) sb.append(encode(p)).append('\n');
        append(sb.toString(), sync);
    }

    /** (ii) Find a pass by pass id. A missing file is an empty store; damaged lines are skipped. */
    public Optional<Pass> find(String passId) throws IOException {
        lastDamaged = 0;
        if (!Files.exists(file)) return Optional.empty();
        String prefix = escape(passId) + "|";
        try (BufferedReader r = reader()) {
            String line;
            while ((line = r.readLine()) != null) {
                if (line.startsWith(prefix)) {            // cheap pre-check before the full validation
                    Result res = decode(line);
                    if (res.ok()) return Optional.of(res.pass);
                    lastDamaged++;                         // matching id but damaged line: skip it
                }
            }
        }
        return Optional.empty();
    }

    /** (iii) List all valid passes on a route. */
    public List<Pass> listByRoute(int route) throws IOException {
        lastDamaged = 0;
        List<Pass> out = new ArrayList<>();
        if (!Files.exists(file)) return out;
        try (BufferedReader r = reader()) {
            String line;
            while ((line = r.readLine()) != null) {
                Result res = decode(line);
                if (!res.ok()) { lastDamaged++; continue; }
                if (res.pass.route() == route) out.add(res.pass);
            }
        }
        return out;
    }

    /** Scans the whole file and reports valid/damaged lines by reason. */
    public ScanReport verify() throws IOException {
        ScanReport rep = new ScanReport();
        if (!Files.exists(file)) return rep;
        rep.endsWithNewline = endsWithNewline();
        try (BufferedReader r = reader()) {
            String line;
            while ((line = r.readLine()) != null) {
                rep.lines++;
                Result res = decode(line);
                if (res.ok()) rep.valid++;
                else { rep.damaged++; rep.byReason.merge(res.reason, 1, Integer::sum); }
            }
        }
        return rep;
    }

    /** Removes a half-written last line (no final newline) after a crash. Returns true if it truncated. */
    public boolean repairTail() throws IOException {
        if (!Files.exists(file) || endsWithNewline()) return false;
        try (RandomAccessFile raf = new RandomAccessFile(file.toFile(), "rw")) {
            long pos = raf.length() - 1;
            while (pos >= 0) {
                raf.seek(pos);
                if (raf.read() == '\n') break;
                pos--;
            }
            raf.setLength(pos + 1);          // keep everything up to and including the last '\n'
        }
        return true;
    }

    // ------------------------------------------------------------------ helpers

    private BufferedReader reader() throws IOException {
        // REPLACE (not REPORT) so that invalid UTF-8 bytes cannot abort the whole scan:
        // they become U+FFFD, the CRC no longer matches and the line is skipped as damaged.
        var dec = StandardCharsets.UTF_8.newDecoder()
                .onMalformedInput(CodingErrorAction.REPLACE).onUnmappableCharacter(CodingErrorAction.REPLACE);
        return new BufferedReader(new InputStreamReader(Files.newInputStream(file), dec), 1 << 16);
    }

    private boolean endsWithNewline() throws IOException {
        long len = Files.size(file);
        if (len == 0) return true;
        try (RandomAccessFile raf = new RandomAccessFile(file.toFile(), "r")) {
            raf.seek(len - 1);
            return raf.read() == '\n';
        }
    }

    private void append(String text, boolean sync) throws IOException {
        boolean needNewline = Files.exists(file) && !endsWithNewline();   // isolate a half-written tail
        byte[] bytes = ((needNewline ? "\n" : "") + text).getBytes(StandardCharsets.UTF_8);
        try (FileChannel ch = FileChannel.open(file, StandardOpenOption.CREATE,
                StandardOpenOption.WRITE, StandardOpenOption.APPEND)) {
            ByteBuffer buf = ByteBuffer.wrap(bytes);
            while (buf.hasRemaining()) ch.write(buf);
            if (sync) ch.force(true);
        }
    }
}
