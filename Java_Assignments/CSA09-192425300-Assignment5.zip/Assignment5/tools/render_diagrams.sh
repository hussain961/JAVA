#!/bin/bash
# Renders tools/diagrams/*.dot to report/figures/d_*.png  (needs Graphviz: https://graphviz.org)
cd "$(dirname "$0")/diagrams" || exit 1
for f in *.dot; do dot -Tpng -Gdpi=170 "$f" -o "../../report/figures/d_${f%.dot}.png" && echo "rendered $f"; done
