#!/usr/bin/env python3
"""
Builds the assignment report from report/parts/*.md + the measurements in results/.

  python3 tools/build_report.py            -> report/Assignment5_Report.md  and  report/Assignment5_Report.docx (needs pandoc)
                                              and the task answers TaskA1/answer.md ... TaskA5/answer.md

Placeholders used inside report/parts/*.md
  {{v:key}}                  a number computed from results/*.csv (see values())
  {{table:NAME|caption}}     a table built from the CSV files
  {{out:FILE|head=N}}        console output saved by run_all.sh (results/outputs/FILE.txt), optionally first N lines
  {{src:path|lang}}          a source file from the repository
  {{fig:file.png|caption}}   a figure from report/figures
Because every number comes from results/, re-running ./run_all.sh on your own computer and then this script
gives you a report that contains YOUR measurements.
"""
import csv, os, re, subprocess, sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
RES = os.path.join(ROOT, "results")
PARTS = os.path.join(ROOT, "report", "parts")
ORDER = ["00_cover", "01_intro", "A1", "A2", "A3", "A4", "A5", "B1", "B2", "B3", "B4", "90_conclusion"]
TASK_PARTS = ["A1", "A2", "A3", "A4", "A5"]


def rows(name):
    with open(os.path.join(RES, name), newline="") as f:
        return list(csv.DictReader(f))


def fnum(x, d=1):
    x = float(x)
    if x == 0:
        return "0"
    if x >= 1000:
        return f"{x:,.0f}"
    if x >= 100:
        return f"{x:,.0f}"
    if x >= 10:
        return f"{x:,.1f}"
    if x >= 1:
        return f"{x:,.2f}"
    return f"{x:.3f}"


def secs(ms):
    return f"{float(ms) / 1000:.1f} s" if float(ms) >= 1000 else f"{fnum(ms)} ms"


def values():
    v = {}
    env = {}
    for line in open(os.path.join(RES, "env.txt")):
        if ":" in line:
            k, val = line.split(":", 1)
            env[k.strip()] = val.strip()
    v["env_line"] = f"{env.get('os','?')}, {env.get('cpu','?')}, {env.get('memory','?')} RAM, {env.get('java','?')}"
    v["env_date"] = env.get("date", "?")
    v["env_jdbc"] = env.get("jdbc_jar", "?")
    try:
        for line in open(os.path.join(RES, "outputs", "TaskB4_2_metadata.txt")):
            if line.startswith("Database product"):
                v["db_product"] = line.split(":", 1)[1].strip()
            if line.startswith("Driver "):
                v["db_driver"] = line.split(":", 1)[1].strip()
    except OSError:
        pass

    # ---- buffering
    b = rows("B1_3_buffering.csv")
    def bt(size, method, col="time_ms"):
        return float(next(x[col] for x in b if int(x["size_mb"]) == size and x["method"] == method))
    S = max(int(x["size_mb"]) for x in b)
    v["buf_size"] = S
    v["unbuf_ms"] = secs(bt(S, "unbuffered read() one byte"))
    v["unbuf_calls"] = f"{int(bt(S, 'unbuffered read() one byte', 'read_calls')):,}"
    v["unbuf_us_per_call"] = f"{bt(S, 'unbuffered read() one byte') * 1000 / bt(S, 'unbuffered read() one byte', 'read_calls'):.2f}"
    v["bis_calls"] = f"{int(bt(S, 'BufferedInputStream.read() 8 KiB', 'read_calls')):,}"
    v["bis_ms"] = secs(bt(S, "BufferedInputStream.read() 8 KiB"))
    v["chunk_calls"] = f"{int(bt(S, 'FileInputStream + byte[65536]', 'read_calls')):,}"
    v["chunk8_calls"] = f"{int(bt(S, 'FileInputStream + byte[8192]', 'read_calls')):,}"
    v["chunk_ms"] = secs(bt(S, "FileInputStream + byte[65536]"))
    v["speedup_chunk"] = f"{bt(S, 'unbuffered read() one byte') / bt(S, 'FileInputStream + byte[65536]'):,.0f}"
    v["speedup_bis"] = f"{bt(S, 'unbuffered read() one byte') / bt(S, 'BufferedInputStream.read() 8 KiB'):,.0f}"
    v["call_reduction"] = f"{bt(S, 'unbuffered read() one byte', 'read_calls') / bt(S, 'FileInputStream + byte[65536]', 'read_calls'):,.0f}"
    v["readall_ms"] = secs(bt(S, "Files.readAllLines()"))
    v["readall_mb"] = fnum(bt(S, "Files.readAllLines()", "allocated_mb"))
    v["readall_ratio"] = f"{bt(S, 'Files.readAllLines()', 'allocated_mb') / S:.1f}"
    v["readline_ms"] = secs(bt(S, "BufferedReader.readLine()"))
    v["chunk_alloc_mb"] = fnum(bt(S, "FileInputStream + byte[65536]", "allocated_mb"))
    v["unbuf_1mb_ms"] = secs(bt(1, "unbuffered read() one byte"))
    v["unbuf_scaling"] = f"{bt(S, 'unbuffered read() one byte') / bt(1, 'unbuffered read() one byte'):.0f}"

    # ---- growth
    g = rows("B1_4_growth.csv")
    def gt(n, store, case):
        return float(next(x["time_ms"] for x in g if int(x["n"]) == n and x["store"] == store and x["case"] == case))
    ns = sorted({int(x["n"]) for x in g})
    n0, n1 = ns[0], ns[-1]
    v["g_n0"], v["g_n1"] = f"{n0:,}", f"{n1:,}"
    v["g_last0"] = fnum(gt(n0, "BusPassFileStore", "last record"))
    v["g_last1"] = fnum(gt(n1, "BusPassFileStore", "last record"))
    v["g_ratio_n"] = f"{n1 / n0:.0f}"
    v["g_ratio_t"] = f"{gt(n1, 'BusPassFileStore', 'last record') / gt(n0, 'BusPassFileStore', 'last record'):.0f}"
    n_mid = ns[2]
    v["g_n_mid"] = f"{n_mid:,}"
    v["g_last_mid"] = fnum(gt(n_mid, "BusPassFileStore", "last record"))
    v["g_ratio_n2"] = f"{n1 / n_mid:.0f}"
    v["g_ratio_t2"] = f"{gt(n1, 'BusPassFileStore', 'last record') / gt(n_mid, 'BusPassFileStore', 'last record'):.1f}"
    v["g_ps_last1"] = fnum(gt(n1, "PassStore", "last record"))
    v["g_first1"] = fnum(gt(n1, "BusPassFileStore", "first record"))
    v["g_ns_per_rec"] = f"{gt(n1, 'BusPassFileStore', 'last record') * 1e6 / n1:.0f}"
    v["g_ps_vs_full"] = f"{gt(n1, 'PassStore', 'last record') / gt(n1, 'BusPassFileStore', 'last record'):.1f}"
    h = rows("B1_alt_hashmap.csv")
    hl = h[-1]
    v["h_n"] = f"{int(hl['n']):,}"
    v["h_q"] = hl["q"]
    v["h_scan"] = secs(hl["scan_ms"])
    v["h_total"] = secs(hl["hashmap_total_ms"])
    v["h_build"] = secs(hl["build_ms"])
    v["h_heap"] = fnum(hl["heap_mb"])
    v["h_speedup"] = f"{float(hl['scan_ms']) / float(hl['hashmap_total_ms']):.1f}"
    v["h_file_mb"] = fnum(next(int(x["file_kb"]) for x in g if int(x["n"]) == n1) / 1024)
    v["h_heap_ratio"] = f"{float(hl['heap_mb']) / (next(int(x['file_kb']) for x in g if int(x['n']) == n1) / 1024):.1f}"

    # ---- random access
    r = rows("A1_randomaccess.csv")[-1]
    v["ra_pad"] = r["padding_pct"]
    v["ra_avg"] = r["avg_content_bytes"]
    v["ra_scan"] = fnum(r["scan_find_ms"])
    v["ra_seek"] = fnum(r["seek_find_us"])
    v["ra_speedup"] = f"{float(r['scan_find_ms']) * 1000 / float(r['seek_find_us']):,.0f}"
    v["ra_fixed_kb"] = f"{int(r['ra_file_kb']):,}"
    v["ra_text_kb"] = f"{int(r['text_file_kb']):,}"
    v["ra_n"] = f"{int(r['n']):,}"

    # ---- formats
    f = rows("A4_formats.csv")
    def ft(n, fmt, col):
        return float(next(x[col] for x in f if int(x["n"]) == n and x["format"] == fmt))
    N = max(int(x["n"]) for x in f)
    v["f_n"] = f"{N:,}"
    for key, fmt in (("ser", "Java serialization"), ("csv", "CSV text"), ("json", "JSON text")):
        v[f"f_{key}_kb"] = f"{ft(N, fmt, 'file_kb'):,.0f}"
    v["f_json_vs_ser"] = f"{ft(N, 'JSON text', 'file_kb') / ft(N, 'Java serialization', 'file_kb'):.1f}"
    v["f_ser_vs_csv"] = f"{ft(N, 'Java serialization', 'file_kb') / ft(N, 'CSV text', 'file_kb'):.1f}"

    # ---- inserts
    t = rows("B3_2_inserts.csv")
    def it(n, a, m):
        return float(next(x["time_ms"] for x in t if int(x["rows"]) == n and x["approach"] == a and x["commit_mode"] == m))
    N = max(int(x["rows"]) for x in t)
    v["i_n"] = f"{N:,}"
    v["i_stmt_auto"] = secs(it(N, "Statement", "autocommit"))
    v["i_prep_auto"] = secs(it(N, "PreparedStatement", "autocommit"))
    v["i_batch_auto"] = secs(it(N, "PreparedStatement + batch", "autocommit"))
    v["i_stmt_tx"] = secs(it(N, "Statement", "transaction"))
    v["i_prep_tx"] = secs(it(N, "PreparedStatement", "transaction"))
    v["i_batch_tx"] = secs(it(N, "PreparedStatement + batch", "transaction"))
    v["i_batch_vs_stmt"] = f"{it(N, 'Statement', 'autocommit') / it(N, 'PreparedStatement + batch', 'autocommit'):.0f}"
    v["i_tx_vs_auto_stmt"] = f"{it(N, 'Statement', 'autocommit') / it(N, 'Statement', 'transaction'):.1f}"
    v["i_batch_vs_tx_stmt"] = f"{it(N, 'Statement', 'transaction') / it(N, 'PreparedStatement + batch', 'transaction'):.1f}"
    v["i_prep_vs_stmt_auto"] = f"{it(N, 'Statement', 'autocommit') / it(N, 'PreparedStatement', 'autocommit'):.2f}"
    v["i_stmt_rate"] = f"{N / (it(N, 'Statement', 'autocommit') / 1000):,.0f}"
    v["i_batch_rate"] = f"{N / (it(N, 'PreparedStatement + batch', 'autocommit') / 1000):,.0f}"
    v["i_per_row_auto_ms"] = f"{it(N, 'Statement', 'autocommit') / N:.3f}"
    n1k = min(int(x["rows"]) for x in t)
    v["i_1k_ratio"] = f"{it(n1k, 'Statement', 'autocommit') / it(n1k, 'PreparedStatement + batch', 'autocommit'):.0f}"

    a = rows("B3_alt_inserts.csv")
    def at(method, b):
        return next(x for x in a if x["method"] == method and x["b"] == str(b))
    v["alt_batch1000"] = secs(at("PreparedStatement batch", 1000)["time_ms"])
    v["alt_multi1000"] = secs(at("multi-row INSERT", 1000)["time_ms"])
    ld = at("LOAD DATA LOCAL INFILE", 0)
    v["alt_load"] = secs(ld["time_ms"]) if ld["time_ms"] != "NA" else "not available"

    fl = rows("B3_3_failure.csv")
    v["fail_auto_invalid"] = next(x["rows_left"] for x in fl if x["scenario"].startswith("invalid") and "auto-commit" in x["mode"])
    v["fail_tx_invalid"] = next(x["rows_left"] for x in fl if x["scenario"].startswith("invalid") and "transaction" in x["mode"])
    v["fail_auto_dup"] = next(x["rows_left"] for x in fl if x["scenario"].startswith("duplicate") and "auto-commit" in x["mode"])
    v["fail_tx_dup"] = next(x["rows_left"] for x in fl if x["scenario"].startswith("duplicate") and "transaction" in x["mode"])
    sp = rows("B3_3_transfer_speed.csv")
    v["tr_auto"] = sp[0]["ms_per_transfer"]
    v["tr_tx"] = sp[1]["ms_per_transfer"]
    v["tr_ratio"] = f"{float(sp[0]['ms_per_transfer']) / float(sp[1]['ms_per_transfer']):.2f}"
    v["tr_n"] = f"{int(sp[0]['transfers']):,}"

    # ---- validation cost
    c = rows("B2_validation_cost.csv")
    v["val_regex_us"] = fnum(next(x["per_op_us"] for x in c if x["method"].startswith("regex validation")))
    v["val_str_us"] = fnum(next(x["per_op_us"] for x in c if x["method"].startswith("regex + escaping")))
    v["val_ps_us"] = fnum(next(x["per_op_us"] for x in c if x["method"].startswith("PreparedStatement")))
    v["val_share"] = f"{float(next(x['per_op_us'] for x in c if x['method'].startswith('regex validation'))) / float(next(x['per_op_us'] for x in c if x['method'].startswith('PreparedStatement'))) * 100:.2f}"

    # ---- migration
    m = rows("B4_1_migration.csv")[0]
    v["m_lines"], v["m_loaded"], v["m_rejected"] = f"{int(m['lines']):,}", f"{int(m['loaded']):,}", m["rejected"]
    v["m_time"] = m["time_s"]

    # ---- scale
    s = rows("B4_3_scale.csv")
    def st(design, op):
        return next(x for x in s if x["design"].startswith(design) and op in x["operation"])
    v["s_file_avg"] = fnum(st("A.", "average of 20")["time_ms"])
    v["s_file_end"] = fnum(st("A.", "near the end")["time_ms"])
    v["s_ser_all"] = secs(st("B.", "campus unknown")["time_ms"])
    v["s_ser_one"] = secs(st("B.", "ONE campus")["time_ms"])
    v["s_db_pk_ms"] = st("C.", "primary key")["time_ms"]
    v["s_db_pk_us"] = f"{float(st('C.', 'primary key')['time_ms']) * 1000:.0f}"
    v["s_ratio_file_db"] = f"{float(st('A.', 'average of 20')['time_ms']) / float(st('C.', 'primary key')['time_ms']):,.0f}"
    v["s_ratio_ser_db"] = f"{float(st('B.', 'campus unknown')['time_ms']) / float(st('C.', 'primary key')['time_ms']):,.0f}"
    v["s_file_mb"] = fnum(st("A.", "write all")["size_mb"])
    v["s_ser_mb"] = fnum(st("B.", "save 12")["size_mb"])
    v["s_db_mb"] = fnum(st("C.", "load all")["size_mb"])
    v["s_db_load"] = secs(st("C.", "load all")["time_ms"])
    v["s_route_file"] = secs(st("A.", "list passes on one route")["time_ms"])
    v["s_route_db"] = fnum(st("C.", "count passes on one route")["time_ms"])
    v["s_lookups_per_sec_file"] = f"{1000 / float(st('A.', 'average of 20')['time_ms']):,.0f}"
    v["s_lookups_per_sec_db"] = f"{1000 / float(st('C.', 'primary key')['time_ms']):,.0f}"

    cc = rows("B4_3_concurrency.csv")
    da = [int(x["duplicates"]) for x in cc if x["design"].startswith('"A') or x["design"].startswith("A")]
    v["c_trials"] = str(len(da))
    v["c_min"], v["c_max"] = str(min(da)), str(max(da))
    v["c_bad_trials"] = str(sum(1 for d in da if d > 0))
    v["c_db_refused"] = re.search(r"\((\d+) duplicate", next(x["design"] for x in cc if "database" in x["design"])).group(1)
    return v


# ------------------------------------------------------------------ tables
def md_table(headers, body, align=None):
    align = align or ["l"] * len(headers)
    sep = ["---:" if a == "r" else ":---" for a in align]
    out = ["| " + " | ".join(headers) + " |", "| " + " | ".join(sep) + " |"]
    for r in body:
        out.append("| " + " | ".join(str(c) for c in r) + " |")
    return "\n".join(out)


def tables():
    T = {}
    r = rows("A1_randomaccess.csv")
    T["A1_ra"] = md_table(["Records (n)", "Record size", "Average real content", "Padding wasted", "Fixed-length file", "Text file", "Find by scan (avg)", "Find by seek (avg)"],
        [[f"{int(x['n']):,}", f"{x['record_bytes']} B", f"{x['avg_content_bytes']} B", f"{x['padding_pct']} %", f"{int(x['ra_file_kb']):,} KB", f"{int(x['text_file_kb']):,} KB",
          f"{fnum(x['scan_find_ms'])} ms", f"{fnum(x['seek_find_us'])} µs"] for x in r], ["r"] * 8)
    b = rows("B1_3_buffering.csv")
    T["B1_3"] = md_table(["File", "Method", "OS-level read calls", "Time", "Memory allocated"],
        [[f"{x['size_mb']} MB", x["method"], f"{int(x['read_calls']):,}", secs(x["time_ms"]), f"{fnum(x['allocated_mb'])} MB"] for x in b], ["l", "l", "r", "r", "r"])
    g = rows("B1_4_growth.csv")
    ns = sorted({int(x["n"]) for x in g})
    def gt(n, store, case):
        return float(next(x["time_ms"] for x in g if int(x["n"]) == n and x["store"] == store and x["case"] == case))
    body = []
    for n in ns:
        kb = next(int(x["file_kb"]) for x in g if int(x["n"]) == n)
        body.append([f"{n:,}", f"{kb:,} KB", fnum(gt(n, "PassStore", "last record")), fnum(gt(n, "BusPassFileStore", "first record")), fnum(gt(n, "BusPassFileStore", "middle record")),
                     fnum(gt(n, "BusPassFileStore", "last record")), fnum(gt(n, "BusPassFileStore", "not found"))])
    T["B1_4"] = md_table(["Records", "File size", "PassStore: last (ms)", "BusPassFileStore: first (ms)", "middle (ms)", "last (ms)", "not found (ms)"], body, ["r"] * 7)
    h = rows("B1_alt_hashmap.csv")
    T["B1_hash"] = md_table(["Records (n)", "Searches (q)", "q scans of the file", "Read once into HashMap (build)", "q lookups", "HashMap total", "Heap used by map"],
        [[f"{int(x['n']):,}", x["q"], secs(x["scan_ms"]), secs(x["build_ms"]), f"{float(x['lookups_ms']):.2f} ms", secs(x["hashmap_total_ms"]), f"{fnum(x['heap_mb'])} MB"] for x in h], ["r"] * 7)
    f = rows("A4_formats.csv")
    T["A4"] = md_table(["Residents", "Format", "File size", "Save", "Load"],
        [[f"{int(x['n']):,}", x["format"], f"{int(x['file_kb']):,} KB", secs(x["save_ms"]), secs(x["load_ms"])] for x in f], ["r", "l", "r", "r", "r"])
    c = rows("B2_validation_cost.csv")
    T["B2_cost"] = md_table(["Operation", "Repetitions", "Total time", "Time per operation"],
        [[x["method"], f"{int(x['operations']):,}", secs(x["total_ms"]), f"{float(x['per_op_us']):.2f} µs"] for x in c], ["l", "r", "r", "r"])
    t = rows("B3_2_inserts.csv")
    names = ["Statement", "PreparedStatement", "PreparedStatement + batch"]
    sizes = sorted({int(x["rows"]) for x in t})
    body = []
    for n in sizes:
        for a in names:
            au = next(x for x in t if int(x["rows"]) == n and x["approach"] == a and x["commit_mode"] == "autocommit")
            tx = next(x for x in t if int(x["rows"]) == n and x["approach"] == a and x["commit_mode"] == "transaction")
            body.append([f"{n:,}", a, secs(au["time_ms"]), f"{int(float(au['rows_per_sec'])):,}", secs(tx["time_ms"]), f"{int(float(tx['rows_per_sec'])):,}"])
    T["B3_2"] = md_table(["Rows", "Approach", "Auto-commit: time", "rows/s", "One transaction: time", "rows/s"], body, ["r", "l", "r", "r", "r", "r"])
    fl = rows("B3_3_failure.csv")
    T["B3_3_fail"] = md_table(["Scenario", "Mode", "Exception", "Rows left in table"],
        [[x["scenario"], x["mode"], x["exception"], x["rows_left"]] for x in fl], ["l", "l", "l", "r"])
    sp = rows("B3_3_transfer_speed.csv")
    T["B3_3_speed"] = md_table(["Mode", "Transfers", "Total time", "Per transfer"],
        [[x["mode"], f"{int(x['transfers']):,}", secs(x["time_ms"]), f"{x['ms_per_transfer']} ms"] for x in sp], ["l", "r", "r", "r"])
    a = rows("B3_alt_inserts.csv")
    T["B3_alt"] = md_table(["Method", "Rows", "Rows per statement/batch (b)", "Time", "Memory allocated"],
        [[x["method"], f"{int(x['rows']):,}", "-" if x["b"] == "0" else x["b"], secs(x["time_ms"]) if x["time_ms"] != "NA" else "not available",
          (fnum(x["allocated_mb"]) + " MB") if x["allocated_mb"] != "NA" else "-"] for x in a], ["l", "r", "r", "r", "r"])
    s = rows("B4_3_scale.csv")
    T["B4_scale"] = md_table(["Design", "Operation", "Time", "Size"],
        [[x["design"], x["operation"], secs(x["time_ms"]) if float(x["time_ms"]) >= 1 else f"{float(x['time_ms']):.3f} ms", f"{fnum(x['size_mb'])} MB" if x["size_mb"] else ""] for x in s], ["l", "l", "r", "r"])
    cc = rows("B4_3_concurrency.csv")
    T["B4_conc"] = md_table(["Design", "Trial", "Rows stored", "Expected", "Duplicates", "Time"],
        [[x["design"], x["trial"], x["rows_stored"], x["expected"], x["duplicates"], secs(x["time_ms"])] for x in cc], ["l", "r", "r", "r", "r", "r"])
    return T


# ------------------------------------------------------------------ assembling
class Counter:
    fig = 0
    tab = 0


def render(text, V, T):
    def sub_v(m):
        k = m.group(1)
        if k not in V:
            raise KeyError("unknown value key: " + k)
        return str(V[k])
    text = re.sub(r"\{\{v:([A-Za-z0-9_]+)\}\}", sub_v, text)

    def sub_table(m):
        name, cap = m.group(1), m.group(2)
        Counter.tab += 1
        return f"{T[name]}\n\nTable: Table {Counter.tab} – {cap}\n"
    text = re.sub(r"\{\{table:([A-Za-z0-9_]+)\|([^}]*)\}\}", sub_table, text)

    def sub_out(m):
        name, kind, spec = m.group(1), m.group(2), m.group(3)
        path = os.path.join(RES, "outputs", name + ".txt")
        lines = open(path, encoding="utf-8", errors="replace").read().rstrip("\n").split("\n")
        if kind == "head":
            lines = lines[: int(spec)]
        elif kind == "lines":
            a, b = spec.split("-")
            lines = lines[int(a) - 1: int(b)]
        return "```text\n" + "\n".join(lines) + "\n```"
    text = re.sub(r"\{\{out:([A-Za-z0-9_]+)(?:\|(head|lines)=([0-9-]+))?\}\}", sub_out, text)

    def sub_file(m):
        path, head = m.group(1), m.group(2)
        lines = open(os.path.join(ROOT, path), encoding="utf-8", errors="replace").read().rstrip("\n").split("\n")
        if head:
            lines = lines[: int(head)]
        return "```text\n" + "\n".join(lines) + "\n```"
    text = re.sub(r"\{\{file:([^|}]+)(?:\|head=(\d+))?\}\}", sub_file, text)

    def sub_src(m):
        path, lang = m.group(1), m.group(2) or "java"
        body = open(os.path.join(ROOT, path), encoding="utf-8").read().rstrip("\n")
        if m.group(3) == "compact":       # the supplied skeletons are double-spaced: drop the blank lines in the report listing only
            body = "\n".join(l for l in body.split("\n") if l.strip())
        return f"```{lang}\n" + body + "\n```"
    text = re.sub(r"\{\{src:([^|}]+)(?:\|([a-z]+))?(?:\|(compact))?\}\}", sub_src, text)

    def sub_fig(m):
        Counter.fig += 1
        width = m.group(3) or "88"
        return f"![Figure {Counter.fig} – {m.group(2)}](report/figures/{m.group(1)}){{width={width}%}}\n"
    text = re.sub(r"\{\{fig:([^|}]+)\|([^|}]*)(?:\|w=(\d+))?\}\}", sub_fig, text)
    return text


def main():
    V, T = values(), tables()
    chunks, per_task = [], {}
    for part in ORDER:
        path = os.path.join(PARTS, part + ".md")
        if not os.path.exists(path):
            print("missing part:", part)
            continue
        raw = open(path, encoding="utf-8").read()
        rendered = render(raw, V, T)
        chunks.append(rendered)
        if part in TASK_PARTS:
            per_task[part] = rendered
    # static contents list (Parts and Tasks) placed after the cover page
    toc = ["**Contents**", ""]
    for ch in chunks[1:]:
        for line in ch.split("\n"):
            if line.startswith("# "):
                toc.append(f"- **{line[2:].strip()}**")
            elif line.startswith("## "):
                toc.append(f"    - {line[3:].strip()}")
    contents = "\n".join(toc) + "\n\n```{=openxml}\n<w:p><w:r><w:br w:type=\"page\"/></w:r></w:p>\n```"
    chunks.insert(1, contents)
    full = "\n\n".join(chunks)
    out_md = os.path.join(ROOT, "report", "Assignment5_Report.md")
    open(out_md, "w", encoding="utf-8").write(full)
    print("wrote", out_md, f"({len(full.split())} words)")
    for part, body in per_task.items():
        d = os.path.join(ROOT, "Task" + part)
        os.makedirs(d, exist_ok=True)
        body = body.replace("(report/figures/", "(../report/figures/")
        open(os.path.join(d, "answer.md"), "w", encoding="utf-8").write(body)
    if "--no-docx" in sys.argv:
        return
    ref = os.path.join(ROOT, "report", "reference.docx")
    out_docx = os.path.join(ROOT, "report", "Assignment5_Report.docx")
    cmd = ["pandoc", out_md, "-o", out_docx, "--from", "markdown+pipe_tables+fenced_code_blocks+backtick_code_blocks-smart", "--highlight-style=tango", "--resource-path", ROOT]
    if os.path.exists(ref):
        cmd += ["--reference-doc", ref]
    subprocess.check_call(cmd)
    print("wrote", out_docx)
    post = os.path.join(ROOT, "tools", "style_docx.py")
    if os.path.exists(post):
        subprocess.check_call([sys.executable, post, out_docx])


if __name__ == "__main__":
    main()
