#!/usr/bin/env python3
"""Draws the measurement charts from results/*.csv  ->  report/figures/*.png   (re-run after ./run_all.sh)"""
import csv, os, sys
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
RES, FIG = os.path.join(ROOT, "results"), os.path.join(ROOT, "report", "figures")
os.makedirs(FIG, exist_ok=True)
C = ["#1f4e79", "#c55a11", "#548235", "#7f6000", "#7030a0", "#a6a6a6"]
plt.rcParams.update({"font.size": 10, "axes.spines.top": False, "axes.spines.right": False, "figure.dpi": 150})

def rows(name):
    with open(os.path.join(RES, name), newline="") as f:
        return list(csv.DictReader(f))

def save(fig, name):
    fig.tight_layout()
    fig.savefig(os.path.join(FIG, name), dpi=170)
    plt.close(fig)

# ---------------- B1.3 buffering
r = rows("B1_3_buffering.csv")
methods = ["unbuffered read() one byte", "BufferedInputStream.read() 8 KiB", "FileInputStream + byte[65536]", "BufferedReader.readLine()", "Files.readAllLines()"]
labels = ["unbuffered\nread()", "BufferedInputStream\nread()", "byte[64 KiB]\nchunks", "BufferedReader\nreadLine()", "Files.\nreadAllLines()"]
sizes = sorted({int(x["size_mb"]) for x in r})
fig, ax = plt.subplots(figsize=(8, 4))
w = 0.8 / len(sizes)
for i, s in enumerate(sizes):
    vals = [float(next(x["time_ms"] for x in r if int(x["size_mb"]) == s and x["method"] == m)) for m in methods]
    bars = ax.bar(np.arange(len(methods)) + i * w, vals, w, label=f"{s} MB file", color=C[i])
ax.set_yscale("log"); ax.set_ylabel("time to count lines (ms, log scale)")
ax.set_xticks(np.arange(len(methods)) + w); ax.set_xticklabels(labels, fontsize=8)
ax.legend(frameon=False); ax.set_title("Task B1.3 - effect of buffering on counting the lines of a file")
save(fig, "fig_b1_3_buffering.png")

# ---------------- B1.4 growth
g = rows("B1_4_growth.csv")
fig, ax = plt.subplots(figsize=(6.5, 4))
for store, col, mk in (("PassStore", C[1], "s"), ("BusPassFileStore", C[0], "o")):
    pts = sorted((int(x["n"]), float(x["time_ms"])) for x in g if x["store"] == store and x["case"] == "last record")
    ax.plot([p[0] for p in pts], [p[1] for p in pts], marker=mk, color=col, label=f"{store}.find (last record)")
h = rows("B1_alt_hashmap.csv")
ax.plot([int(x["n"]) for x in h], [float(x["lookups_ms"]) / int(x["q"]) for x in h], marker="^", color=C[2], label="HashMap.get (one lookup)")
ax.set_xscale("log"); ax.set_yscale("log"); ax.set_xlabel("records in the file (n)"); ax.set_ylabel("time for one find (ms, log scale)")
ax.legend(frameon=False, fontsize=8); ax.set_title("Task B1.4 - find time as the file grows")
save(fig, "fig_b1_4_growth.png")

# ---------------- B3.2 inserts
t = rows("B3_2_inserts.csv")
names = ["Statement", "PreparedStatement", "PreparedStatement + batch"]
fig, axes = plt.subplots(1, 2, figsize=(9, 3.9), sharey=True)
for ax, mode, title in zip(axes, ("autocommit", "transaction"), ("auto-commit ON (JDBC default)", "inside ONE transaction")):
    ns = sorted({int(x["rows"]) for x in t})
    w = 0.26
    for i, nm in enumerate(names):
        vals = [float(next(x["time_ms"] for x in t if int(x["rows"]) == n and x["approach"] == nm and x["commit_mode"] == mode)) for n in ns]
        ax.bar(np.arange(len(ns)) + i * w, vals, w, label=nm, color=C[i])
    ax.set_yscale("log"); ax.set_xticks(np.arange(len(ns)) + w); ax.set_xticklabels([f"{n:,}" for n in ns]); ax.set_xlabel("rows inserted"); ax.set_title(title, fontsize=9)
axes[0].set_ylabel("total time (ms, log scale)"); axes[0].legend(frameon=False, fontsize=8)
fig.suptitle("Task B3.2 - Statement vs PreparedStatement vs batch", y=1.0)
save(fig, "fig_b3_2_inserts.png")

# ---------------- B3 alternative strategies
a = rows("B3_alt_inserts.csv")
fig, ax = plt.subplots(figsize=(7, 3.6))
lab = [f"{x['method'].replace('PreparedStatement','PS')}" + (f"\nb={x['b']}" if x["b"] != "0" else "") for x in a]
ax.bar(range(len(a)), [float(x["time_ms"]) for x in a], color=[C[0] if "batch" in x["method"] else C[1] if "multi" in x["method"] else C[2] for x in a])
ax.set_xticks(range(len(a))); ax.set_xticklabels(lab, fontsize=7); ax.set_ylabel("time for 100,000 rows (ms)")
ax.set_title("Task B3 alternative - batch vs multi-row INSERT vs LOAD DATA")
save(fig, "fig_b3_alt.png")

# ---------------- A4 formats
f = rows("A4_formats.csv")
fig, axes = plt.subplots(1, 2, figsize=(9, 3.6))
fm = ["Java serialization", "CSV text", "JSON text"]
ns = sorted({int(x["n"]) for x in f}); w = 0.26
for i, name in enumerate(fm):
    axes[0].bar(np.arange(len(ns)) + i * w, [float(next(x["file_kb"] for x in f if int(x["n"]) == n and x["format"] == name)) for n in ns], w, label=name, color=C[i])
    axes[1].bar(np.arange(len(ns)) + i * w, [float(next(x["save_ms"] for x in f if int(x["n"]) == n and x["format"] == name)) + float(next(x["load_ms"] for x in f if int(x["n"]) == n and x["format"] == name)) for n in ns], w, color=C[i])
for ax, yl in zip(axes, ("file size (KB, log scale)", "save + load time (ms, log scale)")):
    ax.set_yscale("log"); ax.set_xticks(np.arange(len(ns)) + w); ax.set_xticklabels([f"{n:,}" for n in ns]); ax.set_xlabel("residents"); ax.set_ylabel(yl)
axes[0].legend(frameon=False, fontsize=8)
fig.suptitle("Task A4 alternative - serialization vs CSV vs JSON", y=1.0)
save(fig, "fig_a4_formats.png")

# ---------------- B4.3 scale
s = rows("B4_3_scale.csv")
def pick(design, op):
    return float(next(x["time_ms"] for x in s if x["design"].startswith(design) and op in x["operation"]))
items = [("A. text file\nscan (average)", pick("A.", "average of 20 random")),
         ("B. 12 serialized files\ncampus unknown", pick("B.", "campus unknown")),
         ("C. database\nprimary key", pick("C.", "primary key"))]
fig, ax = plt.subplots(figsize=(6.5, 3.8))
ax.bar(range(3), [v for _, v in items], color=[C[1], C[4], C[0]])
for i, (_, v) in enumerate(items): ax.text(i, v * 1.15, f"{v:,.2f} ms" if v < 10 else f"{v:,.0f} ms", ha="center", fontsize=9)
ax.set_yscale("log"); ax.set_xticks(range(3)); ax.set_xticklabels([l for l, _ in items], fontsize=8); ax.set_ylabel("time to find ONE pass (ms, log scale)")
ax.set_title("Task B4.3 - 800,000 passes: cost of one search")
ax.set_ylim(0.01, max(v for _, v in items) * 6)
save(fig, "fig_b4_3_scale.png")

# ---------------- B4.3 concurrency
c = rows("B4_3_concurrency.csv")
fig, ax = plt.subplots(figsize=(6.5, 3.6))
lab, val, col = [], [], []
for x in c:
    d = x["design"]
    lab.append(("A" if d.startswith("A") else "B" if d.startswith("B") else "C") + f"{x['trial']}")
    val.append(int(x["duplicates"])); col.append(C[1] if d.startswith("A") else C[2])
ax.bar(range(len(val)), val, color=col)
for i, v in enumerate(val): ax.text(i, v + 0.4, str(v), ha="center", fontsize=9)
ax.set_xticks(range(len(lab))); ax.set_xticklabels(lab); ax.set_ylabel("duplicate passes stored")
ax.set_title("Task B4.3 - 8 counters issuing the same 250 passes\nA = file, no lock   B = file, synchronized   C = database", fontsize=9)
save(fig, "fig_b4_3_concurrency.png")
print("charts written to", FIG)
