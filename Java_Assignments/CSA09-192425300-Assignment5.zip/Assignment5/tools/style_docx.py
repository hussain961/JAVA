#!/usr/bin/env python3
"""Post-processes the pandoc output: table borders/shading, column font size, footer with page numbers, cover tweaks."""
import sys
from docx import Document
from docx.shared import Pt, RGBColor, Cm
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.oxml.ns import qn
from docx.oxml import OxmlElement

path = sys.argv[1]
d = Document(path)

def set_cell_bg(cell, fill):
    tcPr = cell._tc.get_or_add_tcPr()
    for e in tcPr.findall(qn("w:shd")): tcPr.remove(e)
    shd = OxmlElement("w:shd"); shd.set(qn("w:val"), "clear"); shd.set(qn("w:color"), "auto"); shd.set(qn("w:fill"), fill)
    tcPr.append(shd)

def set_borders(tbl):
    tblPr = tbl._tbl.tblPr
    for e in tblPr.findall(qn("w:tblBorders")): tblPr.remove(e)
    b = OxmlElement("w:tblBorders")
    for edge in ("top", "left", "bottom", "right", "insideH", "insideV"):
        el = OxmlElement(f"w:{edge}")
        el.set(qn("w:val"), "single"); el.set(qn("w:sz"), "4"); el.set(qn("w:space"), "0"); el.set(qn("w:color"), "A6A6A6")
        b.append(el)
    tblPr.append(b)
    # cell margins
    for e in tblPr.findall(qn("w:tblCellMar")): tblPr.remove(e)
    m = OxmlElement("w:tblCellMar")
    for side, w in (("top", 40), ("left", 80), ("bottom", 40), ("right", 80)):
        el = OxmlElement(f"w:{side}"); el.set(qn("w:w"), str(w)); el.set(qn("w:type"), "dxa"); m.append(el)
    tblPr.append(m)

def full_width(tbl):
    tblPr = tbl._tbl.tblPr
    for e in tblPr.findall(qn("w:tblW")): tblPr.remove(e)
    w = OxmlElement("w:tblW"); w.set(qn("w:w"), "5000"); w.set(qn("w:type"), "pct"); tblPr.append(w)

for t in d.tables:
    set_borders(t)
    full_width(t)
    t.alignment = WD_TABLE_ALIGNMENT.CENTER
    ncols = len(t.columns)
    size = 9 if ncols <= 4 else 8.5 if ncols <= 6 else 8
    for ri, row in enumerate(t.rows):
        # do not split a row across pages; repeat header row
        trPr = row._tr.get_or_add_trPr()
        cs = OxmlElement("w:cantSplit"); trPr.append(cs)
        if ri == 0:
            th = OxmlElement("w:tblHeader"); trPr.append(th)
        for cell in row.cells:
            if ri == 0:
                set_cell_bg(cell, "1F4E79")
            elif ri % 2 == 0:
                set_cell_bg(cell, "F2F6FA")
            for p in cell.paragraphs:
                p.paragraph_format.space_after = Pt(0)
                p.paragraph_format.space_before = Pt(0)
                for r in p.runs:
                    r.font.size = Pt(size)
                    if ri == 0:
                        r.font.bold = True
                        r.font.color.rgb = RGBColor(0xFF, 0xFF, 0xFF)

# keep short code blocks (pseudocode, outputs) on one page
paras = d.paragraphs
i = 0
while i < len(paras):
    if paras[i].style.name == "Source Code":
        j = i
        while j + 1 < len(paras) and paras[j + 1].style.name == "Source Code":
            j += 1
        if j - i + 1 <= 32:
            for k in range(i, j):
                paras[k].paragraph_format.keep_with_next = True
            for k in range(i, j + 1):
                paras[k].paragraph_format.keep_together = True
        i = j + 1
    else:
        i += 1

# footer: name | reg no | course ... page number
sec = d.sections[0]
sec.different_first_page_header_footer = True
fp = sec.footer.paragraphs[0]
fp.text = ""
fp.alignment = WD_ALIGN_PARAGRAPH.CENTER
def run(text):
    r = fp.add_run(text); r.font.size = Pt(8.5); r.font.color.rgb = RGBColor(0x59, 0x59, 0x59); return r
run("D.HUSSAINAIAH  |  192425300  |  CSA09 Programming in Java – Assignment 5 (CO5)  |  Page ")
r = run("")
for kind, txt in (("begin", None), (None, " PAGE "), ("end", None)):
    if kind:
        fc = OxmlElement("w:fldChar"); fc.set(qn("w:fldCharType"), kind); r._r.append(fc)
    else:
        it = OxmlElement("w:instrText"); it.set(qn("xml:space"), "preserve"); it.text = txt; r._r.append(it)
d.save(path)
print("styled", path)
