#!/usr/bin/env python3
"""Creates report/reference.docx (page size, fonts, heading and code styles) for pandoc."""
import subprocess, os
from docx import Document
from docx.shared import Pt, RGBColor, Cm
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.style import WD_STYLE_TYPE
from docx.oxml.ns import qn
from docx.oxml import OxmlElement

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
ref = os.path.join(ROOT, "report", "reference.docx")
with open(ref, "wb") as f:
    f.write(subprocess.check_output(["pandoc", "-o", "/dev/stdout", "--print-default-data-file", "reference.docx"]))
d = Document(ref)
NAVY = RGBColor(0x1F, 0x4E, 0x79)
for s in d.sections:
    s.page_width, s.page_height = Cm(21.0), Cm(29.7)
    s.left_margin = s.right_margin = Cm(2.2)
    s.top_margin, s.bottom_margin = Cm(2.2), Cm(2.0)

def font(style, name, size, bold=None, color=None, italic=None):
    style.font.name = name
    style.element.rPr.rFonts.set(qn("w:eastAsia"), name) if style.element.rPr is not None and style.element.rPr.rFonts is not None else None
    style.font.size = Pt(size)
    if bold is not None: style.font.bold = bold
    if italic is not None: style.font.italic = italic
    if color is not None: style.font.color.rgb = color

st = d.styles
_by = {x.name.lower(): x for x in st}
def S(name): return _by[name.lower()]
for n in ("Normal", "Body Text", "First Paragraph", "Compact"):
    if n.lower() in _by:
        font(S(n), "Calibri", 10.5)
for n in ("Body Text", "First Paragraph"):
    pf = S(n).paragraph_format
    pf.space_after, pf.space_before, pf.line_spacing = Pt(6), Pt(0), 1.12
S("Compact").paragraph_format.space_after = Pt(2)
for n, sz, before, after in (("Heading 1", 19, 18, 8), ("Heading 2", 14.5, 16, 6), ("Heading 3", 12, 12, 4), ("Heading 4", 11, 8, 3)):
    font(S(n), "Calibri", sz, bold=True, color=NAVY)
    S(n).paragraph_format.space_before, S(n).paragraph_format.space_after = Pt(before), Pt(after)
    S(n).paragraph_format.keep_with_next = True
font(S("Title"), "Calibri", 24, bold=True, color=NAVY)

def shade(par_style, fill):
    ppr = par_style.element.get_or_add_pPr()
    shd = OxmlElement("w:shd"); shd.set(qn("w:val"), "clear"); shd.set(qn("w:color"), "auto"); shd.set(qn("w:fill"), fill)
    ppr.append(shd)

names = [x.name for x in st]
if "Source Code" in names:
    sc = S("Source Code")
    font(sc, "Consolas", 7.5)
    sc.paragraph_format.space_after = Pt(0); sc.paragraph_format.space_before = Pt(0); sc.paragraph_format.line_spacing = 1.0
    sc.paragraph_format.left_indent = Cm(0.15)
    shade(sc, "F4F4F4")
if "Verbatim Char" in names:
    font(S("Verbatim Char"), "Consolas", 9)
for n in ("Image Caption", "Table Caption", "Caption"):
    if n in names:
        font(S(n), "Calibri", 9, italic=True, color=RGBColor(0x40, 0x40, 0x40))
        S(n).paragraph_format.space_after = Pt(8)
        if n != "Table Caption": S(n).paragraph_format.alignment = WD_ALIGN_PARAGRAPH.CENTER

def custom(name, size, bold=False, color=None, align=WD_ALIGN_PARAGRAPH.CENTER, before=0, after=6):
    s = st.add_style(name, WD_STYLE_TYPE.PARAGRAPH)
    s.base_style = S("Normal")
    s.font.name = "Calibri"; s.font.size = Pt(size); s.font.bold = bold
    if color is not None: s.font.color.rgb = color
    s.paragraph_format.alignment = align
    s.paragraph_format.space_before, s.paragraph_format.space_after = Pt(before), Pt(after)
    return s
custom("CoverSmall", 12, True, RGBColor(0x59, 0x59, 0x59), before=60, after=40)
custom("CoverTitle", 28, True, NAVY, before=20, after=6)
custom("CoverTitle2", 18, True, RGBColor(0xC5, 0x5A, 0x11), before=10, after=14)
custom("CoverSub", 11, False, RGBColor(0x40, 0x40, 0x40), after=40)
cf = custom("CoverField", 11.5, False, None, align=WD_ALIGN_PARAGRAPH.LEFT, before=0, after=8)
cf.paragraph_format.left_indent = Cm(1.5); cf.paragraph_format.right_indent = Cm(1.5)
d.save(ref)
print("wrote", ref)
