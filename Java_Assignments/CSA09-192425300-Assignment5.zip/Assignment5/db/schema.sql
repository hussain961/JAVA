-- Task B2/B3/B4 test schema.  Run as the test user:
--   mysql -u transport -ptransport123 transport_test < db/schema.sql
-- (re-running it resets every table to a clean state)
USE transport_test;

-- ---------------------------------------------------------------- bus passes (Tasks B3, B4)
DROP TABLE IF EXISTS bus_pass;
CREATE TABLE bus_pass (
    pass_id        VARCHAR(10)   NOT NULL,
    reg_no         VARCHAR(12)   NOT NULL,
    name           VARCHAR(60)   NOT NULL,
    route_no       INT           NOT NULL,
    boarding_stop  VARCHAR(40)   NULL,
    valid_until    DATE          NULL,
    amount         DECIMAL(10,2) NOT NULL,
    PRIMARY KEY (pass_id),
    INDEX idx_bus_pass_route (route_no),
    CONSTRAINT chk_bus_pass_amount CHECK (amount >= 0)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------- login test (Task B2). TEST DATA ONLY.
DROP TABLE IF EXISTS users;
CREATE TABLE users (
    id    VARCHAR(20) NOT NULL PRIMARY KEY,
    pwd   VARCHAR(30) NOT NULL,
    role  VARCHAR(10) NOT NULL
) ENGINE=InnoDB;
INSERT INTO users VALUES
    ('admin',     'Adm!n#2026', 'ADMIN'),
    ('192311001', 'pass1234',   'STUDENT'),
    ('192311002', 'mango77',    'STUDENT');

-- ---------------------------------------------------------------- wallet transfer (Tasks A5.1, B3.3)
DROP TABLE IF EXISTS hostel_wallet;
DROP TABLE IF EXISTS canteen_wallet;
CREATE TABLE hostel_wallet (
    reg_no  VARCHAR(12)   NOT NULL PRIMARY KEY,
    balance DECIMAL(10,2) NOT NULL,
    CONSTRAINT chk_hostel_balance CHECK (balance >= 0)
) ENGINE=InnoDB;
CREATE TABLE canteen_wallet (
    reg_no  VARCHAR(12)   NOT NULL PRIMARY KEY,
    balance DECIMAL(10,2) NOT NULL,
    CONSTRAINT chk_canteen_balance CHECK (balance >= 0)
) ENGINE=InnoDB;
INSERT INTO hostel_wallet  VALUES ('192311001', 2000.00), ('192311002', 300.00);
INSERT INTO canteen_wallet VALUES ('192311001',  100.00), ('192311002',  50.00);

-- ---------------------------------------------------------------- concurrent counters (Task B4.3)
DROP TABLE IF EXISTS pass_issue;
CREATE TABLE pass_issue (
    reg_no     VARCHAR(12) NOT NULL,
    counter_id INT         NOT NULL,
    PRIMARY KEY (reg_no)              -- the rule "one active pass per student" is enforced by the database itself
) ENGINE=InnoDB;
