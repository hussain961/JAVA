-- Run ONCE as the MySQL administrator (for example:  mysql -u root -p < db/setup_mysql_user.sql)
-- Creates a LOCAL TEST database and a test-only user. Nothing here touches any real data.
CREATE DATABASE IF NOT EXISTS transport_test CHARACTER SET utf8mb4;
CREATE USER IF NOT EXISTS 'transport'@'localhost' IDENTIFIED BY 'transport123';
CREATE USER IF NOT EXISTS 'transport'@'127.0.0.1' IDENTIFIED BY 'transport123';
GRANT ALL PRIVILEGES ON transport_test.* TO 'transport'@'localhost';
GRANT ALL PRIVILEGES ON transport_test.* TO 'transport'@'127.0.0.1';
FLUSH PRIVILEGES;
