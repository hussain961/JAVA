import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * Deterministic generator for bus-pass test data (same seed => same data,
 * so every run of every experiment sees identical input).
 */
public final class PassData {
    private PassData() { }

    static final String[] FIRST = {"Arun", "Divya", "Karthik", "Meena", "Suresh", "Priya", "Vignesh", "Lakshmi",
            "Hussain", "Anitha", "Ravi", "Sneha", "Naveen", "Pooja", "Manoj", "Kavya", "Harini", "Bharath"};
    static final String[] LAST = {"Kumar", "Raj", "Devi", "Babu", "Nair", "Reddy", "Sharma", "Iyer", "Rao", "Pillai"};
    static final String[] STOPS = {"Poonamallee", "Koyambedu", "Guindy", "Tambaram", "Avadi", "Ambattur", "Porur",
            "Vadapalani", "Perambur", "Velachery", "Anna Nagar", "T Nagar", "Chromepet", "Sholinganallur"};

    /** Pass id such as P000042 (i is 1-based). */
    public static String passId(int i) { return String.format("P%06d", i); }

    /** Generates n structured passes with ids P000001..P00000n. */
    public static List<BusPassFileStore.Pass> passes(int n) {
        Random r = new Random(20250914L);
        List<BusPassFileStore.Pass> list = new ArrayList<>(n);
        for (int i = 1; i <= n; i++) {
            String name = FIRST[r.nextInt(FIRST.length)] + " " + LAST[r.nextInt(LAST.length)];
            if (i % 97 == 0) name = LAST[r.nextInt(LAST.length)] + ", " + FIRST[r.nextInt(FIRST.length)]; // contains a comma
            if (i % 1009 == 0) name = FIRST[r.nextInt(FIRST.length)] + "|" + LAST[r.nextInt(LAST.length)]; // contains the delimiter
            int route = 1 + r.nextInt(40);
            list.add(new BusPassFileStore.Pass(
                    passId(i),
                    String.valueOf(192000000 + (int) ((i * 37L) % 100000)),
                    name,
                    route,
                    STOPS[r.nextInt(STOPS.length)],
                    LocalDate.of(2027, 3, 31),
                    new java.math.BigDecimal(String.valueOf(3000 + route * 50)).setScale(2)));
        }
        return list;
    }

    /** The five-field String[] rows used by PassLoader (pass id, reg no, name, route, amount). */
    public static List<String[]> rows(int n) {
        List<String[]> rows = new ArrayList<>(n);
        for (BusPassFileStore.Pass p : passes(n)) {
            rows.add(new String[] {p.passId(), p.regNo(), p.name(), String.valueOf(p.route()), p.amount().toPlainString()});
        }
        return rows;
    }
}
