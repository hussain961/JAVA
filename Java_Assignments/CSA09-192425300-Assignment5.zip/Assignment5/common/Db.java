import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * Small helper that opens JDBC connections for the LOCAL TEST DATABASE
 * (transport_test) created only for this assignment.
 *
 * Settings come from system properties or environment variables so that no
 * password is hard-coded in the task programs:
 *   DB_URL  (default: jdbc:mysql://localhost:3306/transport_test?rewriteBatchedStatements=true)
 *   DB_USER (default: transport)
 *   DB_PASS (default: transport123)
 */
public final class Db {
    private Db() { }

    private static String setting(String key, String envName, String def) {
        String v = System.getProperty(key);
        if (v == null || v.isEmpty()) v = System.getenv(envName);
        return (v == null || v.isEmpty()) ? def : v;
    }

    public static String url() {
        return setting("db.url", "DB_URL",
                "jdbc:mysql://localhost:3306/transport_test?rewriteBatchedStatements=true");
    }

    public static String user() { return setting("db.user", "DB_USER", "transport"); }

    public static String pass() { return setting("db.pass", "DB_PASS", "transport123"); }

    public static Connection connect() throws SQLException {
        return DriverManager.getConnection(url(), user(), pass());
    }

    /**
     * Connects with the same URL but WITHOUT rewriteBatchedStatements and WITH the extra parameters given
     * (for example "allowMultiQueries=true"). Used by the injection demo, where multi-statement behaviour matters.
     */
    public static Connection connectPlain(String... extraParams) throws SQLException {
        String u = url();
        int q = u.indexOf('?');
        String base = q < 0 ? u : u.substring(0, q);
        StringBuilder params = new StringBuilder();
        if (q >= 0) {
            for (String kv : u.substring(q + 1).split("&")) {
                if (kv.isEmpty() || kv.startsWith("rewriteBatchedStatements=") || kv.startsWith("allowMultiQueries=")) continue;
                params.append(params.length() == 0 ? "" : "&").append(kv);
            }
        }
        for (String kv : extraParams) params.append(params.length() == 0 ? "" : "&").append(kv);
        return DriverManager.getConnection(params.length() == 0 ? base : base + "?" + params, user(), pass());
    }
}
