import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.Arrays;

/** Tiny timing and CSV helper used by every measurement program. */
public final class Bench {
    private Bench() { }

    public interface Action { void run() throws Exception; }

    /** Runs the action once and returns the elapsed time in milliseconds. */
    public static double timeMs(Action a) {
        long t0 = System.nanoTime();
        try { a.run(); } catch (Exception e) { throw new RuntimeException(e); }
        return (System.nanoTime() - t0) / 1e6;
    }

    /** Runs the action {@code runs} times and returns the median time in ms. */
    public static double medianMs(int runs, Action a) {
        double[] t = new double[runs];
        for (int i = 0; i < runs; i++) t[i] = timeMs(a);
        Arrays.sort(t);
        return t[runs / 2];
    }

    /** Bytes allocated by the current thread so far (HotSpot only; -1 if unavailable). */
    public static long allocatedBytes() {
        try {
            java.lang.management.ThreadMXBean b = java.lang.management.ManagementFactory.getThreadMXBean();
            if (b instanceof com.sun.management.ThreadMXBean) {
                return ((com.sun.management.ThreadMXBean) b).getThreadAllocatedBytes(Thread.currentThread().getId());
            }
        } catch (Throwable ignored) { }
        return -1;
    }

    /** Directory for generated data files (ignored by git). */
    public static Path workDir() throws IOException {
        Path p = Paths.get(System.getProperty("work.dir", "work"));
        Files.createDirectories(p);
        return p;
    }

    /** Appends one line to results/<name> (creates the folder if needed). */
    public static void csv(String name, String line) {
        try {
            Path dir = Paths.get(System.getProperty("results.dir", "results"));
            Files.createDirectories(dir);
            Files.writeString(dir.resolve(name), line + System.lineSeparator(), StandardCharsets.UTF_8,
                    StandardOpenOption.CREATE, StandardOpenOption.APPEND);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    /** Starts results/<name> afresh with a header line, so a re-run never mixes old and new numbers. */
    public static void resetCsv(String name, String header) {
        try {
            Path f = Paths.get(System.getProperty("results.dir", "results")).resolve(name);
            Files.deleteIfExists(f);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        csv(name, header);
    }
}
