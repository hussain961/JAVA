import java.awt.BorderLayout;
import java.awt.Button;
import java.awt.Choice;
import java.awt.EventQueue;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Frame;
import java.awt.Label;
import java.awt.Panel;
import java.awt.TextField;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.ArrayList;
import java.util.List;

/**
 * Task 3 - Campus Library Search Screen.
 *
 * Containment tree (layout manager in brackets):
 *   Frame [BorderLayout]
 *    +- NORTH  : top Panel [BorderLayout]
 *    |            +- NORTH  : title Label
 *    |            +- CENTER : searchRow Panel [FlowLayout] = TextField, Choice, Button "Search"
 *    +- CENTER : results java.awt.List            <- takes ALL the extra space
 *    +- SOUTH  : bottom Panel [BorderLayout]
 *                 +- CENTER : buttonRow Panel [FlowLayout] = Prev, Next, Reserve
 *                 +- SOUTH  : status Label
 */
public class LibrarySearch extends Frame {

    static final int PAGE_SIZE = 5;

    // package-private so the layout test driver can measure the regions
    final Label title = new Label("Campus Library - Search", Label.CENTER);
    final TextField query = new TextField(20);
    final Choice category = new Choice();
    final Button search = new Button("Search");
    final java.awt.List results = new java.awt.List(8, false);
    final Button prev = new Button("Prev");
    final Button next = new Button("Next");
    final Button reserve = new Button("Reserve");
    final Label status = new Label("Type a title or author and press Search.");
    final Panel top = new Panel(new BorderLayout());
    final Panel searchRow = new Panel(new FlowLayout());
    final Panel bottom = new Panel(new BorderLayout());
    final Panel buttonRow = new Panel(new FlowLayout());

    private final LibraryCatalog catalog = new LibraryCatalog();
    private List<LibraryCatalog.Book> matches = new ArrayList<>();
    private int page = 0;

    public LibrarySearch() {
        super("Campus Library");
        title.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 18));
        for (String c : LibraryCatalog.CATEGORIES) category.add(c);

        searchRow.add(query);
        searchRow.add(category);
        searchRow.add(search);
        top.add(title, BorderLayout.NORTH);
        top.add(searchRow, BorderLayout.CENTER);

        buttonRow.add(prev);
        buttonRow.add(next);
        buttonRow.add(reserve);
        bottom.add(buttonRow, BorderLayout.CENTER);
        bottom.add(status, BorderLayout.SOUTH);

        add(top, BorderLayout.NORTH);
        add(results, BorderLayout.CENTER);
        add(bottom, BorderLayout.SOUTH);

        search.addActionListener(e -> doSearch());
        query.addActionListener(e -> doSearch());           // Enter key
        prev.addActionListener(e -> { page--; showPage(); });
        next.addActionListener(e -> { page++; showPage(); });
        reserve.addActionListener(e -> doReserve());
        addWindowListener(new WindowAdapter() {
            @Override public void windowClosing(WindowEvent e) { dispose(); }
        });

        prev.setEnabled(false);
        next.setEnabled(false);
        setSize(560, 380);
    }

    void doSearch() {
        matches = catalog.search(query.getText(), category.getSelectedItem());
        page = 0;
        showPage();
    }

    private void showPage() {
        results.removeAll();
        int from = page * PAGE_SIZE;
        int to = Math.min(from + PAGE_SIZE, matches.size());
        for (int i = from; i < to; i++) {
            LibraryCatalog.Book b = matches.get(i);
            results.add(b.title + "  -  " + b.author + "  [" + b.category + "]"
                    + (b.available ? "" : "  (on loan)"));
        }
        prev.setEnabled(page > 0);
        next.setEnabled(to < matches.size());
        status.setText(matches.isEmpty() ? "No books found."
                : "Showing " + (from + 1) + "-" + to + " of " + matches.size() + " result(s).");
    }

    private void doReserve() {
        int idx = results.getSelectedIndex();
        if (idx < 0) { status.setText("Select a book in the list first."); return; }
        LibraryCatalog.Book b = matches.get(page * PAGE_SIZE + idx);
        boolean ok = catalog.reserve(b);
        showPage();
        status.setText(ok ? "Reserved: " + b.title : "Sorry, \"" + b.title + "\" is already on loan.");
    }

    public static void main(String[] args) {
        EventQueue.invokeLater(() -> new LibrarySearch().setVisible(true));
    }
}
