import java.awt.EventQueue;
import java.awt.Rectangle;
import java.awt.Robot;
import java.awt.event.ActionEvent;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.PrintWriter;
import javax.imageio.ImageIO;

/**
 * Task 3.4 - resizing test. Opens the real window at three sizes, takes a screenshot at each
 * and measures every region. The requirement is checked by code, not by eye:
 *   - results area must GROW with the window
 *   - search row and button row must KEEP their height, and their buttons must keep their size.
 * Usage: java Task03Shots <output-folder>
 */
public class Task03Shots {
    static LibrarySearch w;

    static void ui(Runnable r) throws Exception { EventQueue.invokeAndWait(r); }

    public static void main(String[] args) throws Exception {
        File out = new File(args[0]);
        out.mkdirs();
        int[][] sizes = {{480, 320}, {760, 520}, {1000, 640}};
        String[] names = {"small", "medium", "large"};

        ui(() -> { w = new LibrarySearch(); w.setLocation(0, 0); w.setVisible(true); });
        Thread.sleep(500);
        ui(() -> {                                   // fill the results area with a real search
            w.query.setText("");
            w.category.select("Computer Science");
            w.search.dispatchEvent(new ActionEvent(w.search, ActionEvent.ACTION_PERFORMED, "Search"));
            w.results.select(1);
        });

        StringBuilder table = new StringBuilder();
        table.append(String.format("%-8s %-10s | %-12s %-12s | %-12s %-12s | %-12s %-8s | %-9s %-9s%n",
                "Size", "Frame", "TitleBar H", "SearchRow", "Results", "ButtonRow", "Status H",
                "", "Search btn", "Reserve btn"));
        int[] first = null;
        boolean allOk = true;
        int prevResW = 0, prevResH = 0;
        for (int i = 0; i < sizes.length; i++) {
            final int[] s = sizes[i];
            ui(() -> w.setSize(s[0], s[1]));
            Thread.sleep(700);
            final int[][] m = new int[1][];
            ui(() -> m[0] = new int[]{
                    w.title.getHeight(),                                        // 0
                    w.searchRow.getWidth(), w.searchRow.getHeight(),            // 1,2
                    w.results.getWidth(), w.results.getHeight(),                // 3,4
                    w.buttonRow.getWidth(), w.buttonRow.getHeight(),            // 5,6
                    w.status.getHeight(),                                       // 7
                    w.search.getWidth(), w.search.getHeight(),                  // 8,9
                    w.reserve.getWidth(), w.reserve.getHeight(),                // 10,11
                    w.query.getWidth()});                                       // 12
            int[] v = m[0];
            if (first == null) first = v;
            boolean grew = v[3] >= prevResW && v[4] >= prevResH && (i == 0 || v[3] > prevResW || v[4] > prevResH);
            boolean keptRows = v[2] == first[2] && v[6] == first[6] && v[0] == first[0] && v[7] == first[7];
            boolean keptButtons = v[8] == first[8] && v[9] == first[9] && v[10] == first[10]
                    && v[11] == first[11] && v[12] == first[12];
            allOk &= grew && keptRows && keptButtons;
            prevResW = v[3]; prevResH = v[4];

            table.append(String.format("%-8s %-10s | %-12s %-12s | %-12s %-12s | %-12s %-8s | %-9s %-9s  grew=%b rowsKept=%b buttonsKept=%b%n",
                    names[i], s[0] + "x" + s[1], v[0], v[1] + "x" + v[2], v[3] + "x" + v[4],
                    v[5] + "x" + v[6], v[7], "", v[8] + "x" + v[9], v[10] + "x" + v[11], grew, keptRows, keptButtons));

            Rectangle r = w.getBounds();
            BufferedImage img = new Robot().createScreenCapture(r);
            ImageIO.write(img, "png", new File(out, "task03_" + (i + 1) + "_" + names[i] + ".png"));
        }
        table.append(allOk ? "RESULT: every region behaved as designed.\n" : "RESULT: a region did NOT behave as designed.\n");
        System.out.print(table);
        try (PrintWriter pw = new PrintWriter(new File(out, "resize_report.txt"))) { pw.print(table); }
        ui(() -> w.dispose());
        if (!allOk) System.exit(1);
    }
}
