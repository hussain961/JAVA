import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Data and search/reserve rules for the library screen. No AWT imports. */
public class LibraryCatalog {

    public static class Book {
        final String title, author, category;
        boolean available = true;
        Book(String title, String author, String category) {
            this.title = title; this.author = author; this.category = category;
        }
    }

    public static final String ALL = "All categories";
    public static final String[] CATEGORIES = {ALL, "Computer Science", "Mathematics", "Physics", "Literature"};

    private final List<Book> books = new ArrayList<>();

    public LibraryCatalog() {
        add("Data Structures in Java", "Weiss", "Computer Science");
        add("Operating System Concepts", "Silberschatz", "Computer Science");
        add("Database System Concepts", "Korth", "Computer Science");
        add("Computer Networks", "Tanenbaum", "Computer Science");
        add("Java: The Complete Reference", "Schildt", "Computer Science");
        add("Introduction to Algorithms", "Cormen", "Computer Science");
        add("Discrete Mathematics", "Rosen", "Mathematics");
        add("Linear Algebra Done Right", "Axler", "Mathematics");
        add("Calculus", "Thomas", "Mathematics");
        add("Probability and Statistics", "Walpole", "Mathematics");
        add("Concepts of Physics", "H. C. Verma", "Physics");
        add("University Physics", "Young", "Physics");
        add("Godan", "Premchand", "Literature");
        add("Wings of Fire", "A. P. J. Abdul Kalam", "Literature");
    }

    private void add(String t, String a, String c) { books.add(new Book(t, a, c)); }

    public List<Book> search(String text, String category) {
        String q = text == null ? "" : text.trim().toLowerCase(Locale.ROOT);
        List<Book> result = new ArrayList<>();
        for (Book b : books) {
            boolean catOk = category == null || ALL.equals(category) || b.category.equals(category);
            boolean textOk = q.isEmpty() || b.title.toLowerCase(Locale.ROOT).contains(q)
                    || b.author.toLowerCase(Locale.ROOT).contains(q);
            if (catOk && textOk) result.add(b);
        }
        return result;
    }

    /** @return false if the book is already on loan or reserved */
    public boolean reserve(Book b) {
        if (!b.available) return false;
        b.available = false;
        return true;
    }
}
