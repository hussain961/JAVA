import java.awt.Component;
import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.BorderLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import javax.swing.JLabel;
import javax.swing.JPanel;

/**
 * Alternative concept (Task 3): nested BorderLayout/FlowLayout panels versus one
 * GridBagLayout versus absolute positioning (setLayout(null) + setBounds).
 * Measures the time to re-lay-out the screen after a resize and counts container objects.
 * Runs headless:  java -Djava.awt.headless=true LayoutBenchmark
 */
public class LayoutBenchmark {

    static final int PER_ROW = 10;

    static void layoutAll(Container c) {            // what the AWT does after a resize
        c.doLayout();
        for (Component k : c.getComponents()) if (k instanceof Container) layoutAll((Container) k);
    }

    static JPanel nested(int n) {
        JPanel root = new JPanel(new BorderLayout());
        JPanel rows = new JPanel(new java.awt.GridLayout(0, 1));
        JPanel row = null;
        for (int i = 0; i < n; i++) {
            if (i % PER_ROW == 0) { row = new JPanel(new FlowLayout()); rows.add(row); }
            row.add(new JLabel("item " + i));
        }
        root.add(rows, BorderLayout.CENTER);
        return root;
    }

    static JPanel gridBag(int n) {
        JPanel root = new JPanel(new GridBagLayout());
        GridBagConstraints g = new GridBagConstraints();
        g.fill = GridBagConstraints.BOTH;
        g.weightx = 1; g.weighty = 1;
        for (int i = 0; i < n; i++) {
            g.gridx = i % PER_ROW; g.gridy = i / PER_ROW;
            root.add(new JLabel("item " + i), g);
        }
        return root;
    }

    static JPanel absolute(int n) {
        JPanel root = new JPanel(null);
        for (int i = 0; i < n; i++) {
            JLabel l = new JLabel("item " + i);
            l.setBounds((i % PER_ROW) * 70, (i / PER_ROW) * 22, 65, 20);
            root.add(l);
        }
        return root;
    }

    static int containers(Container c) {
        int count = 1;
        for (Component k : c.getComponents()) if (k instanceof Container && ((Container) k).getComponentCount() > 0) count += containers((Container) k);
        return count;
    }

    static double time(JPanel p, int reps) {
        int[][] sizes = {{700, 400}, {900, 600}};
        for (int i = 0; i < reps / 5 + 5; i++) { p.setSize(sizes[i & 1][0], sizes[i & 1][1]); layoutAll(p); }   // warm-up
        long t0 = System.nanoTime();
        for (int i = 0; i < reps; i++) { p.setSize(sizes[i & 1][0], sizes[i & 1][1]); layoutAll(p); }
        return (System.nanoTime() - t0) / 1000.0 / reps;      // microseconds per resize
    }

    public static void main(String[] args) {
        int[] ns = {30, 300, 3000};
        System.out.printf("%7s | %-26s | %-26s | %-26s%n", "leaves", "nested Border+Flow", "GridBagLayout", "null + setBounds");
        System.out.printf("%7s | %-12s %-13s | %-12s %-13s | %-12s %-13s%n", "n", "us/resize", "containers", "us/resize", "containers", "us/resize", "containers");
        for (int n : ns) {
            int reps = n <= 300 ? 4000 : 400;
            JPanel a = nested(n), b = gridBag(n), c = absolute(n);
            double ta = time(a, reps), tb = time(b, reps), tc = time(c, reps);
            System.out.printf("%7d | %-12.1f %-13d | %-12.1f %-13d | %-12.1f %-13d%n",
                    n, ta, containers(a), tb, containers(b), tc, containers(c));
        }
    }
}
