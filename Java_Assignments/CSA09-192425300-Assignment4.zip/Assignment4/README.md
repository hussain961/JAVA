# CSA09 – Programming in Java · Assignment 4 (CO4) · Event-Driven GUI Design

| | |
|---|---|
| **Name** | D.HUSSAINAIAH |
| **Register number** | 192425300 |
| **Java version** | Java 17 or later (developed and tested with OpenJDK 21.0.12) |
| **Report** | `report/Assignment4_Report.docx` |

Every task has its own folder with the source code. The folder `evidence/` holds every output file and screenshot
that the report quotes (`evidence/task01` … `evidence/task06`).

## Before you submit – checklist (the assignment requires these from you)
- [ ] Fill in your name, register number and GitHub link here and on the report's cover page.
- [ ] **Run every program yourself** on your computer and keep your own screenshots (the supplied ones were taken on a virtual display with no title bars).
- [ ] Task 4: take the *before / after minimising* screenshots with the real window (`Task04/DrawPad.java`).
- [ ] Task 6: run `sql/schema.sql` on MySQL, create `db.properties`, run the application and `ServiceTests --jdbc`; keep screenshots of the MySQL run.
- [ ] Commit **after finishing each task** (suggested messages are at the end). The commit history is checked – do not upload everything in one commit.
- [ ] Share the repository with the course faculty.

## How to compile and run
Open a terminal **inside the task folder**. `javac -d out *.java` creates the class files in `out/`.

| Task | Compile | Run | Result |
|---|---|---|---|
| **1** Fee window | `javac -d out *.java` | window: `java -cp out FeeWindow` · tests: `java -cp out FeeServiceTest` · benchmark: `java -cp out DispatchBenchmark` | Window only collects input; `FeeService` validates and pays; 16/16 tests pass; EDT stays responsive during payment. |
| **2** Appointment desk | `javac -d out *.java` | `java -cp out AppointmentDesk` · event trace: `java -cp out Task02Trace ../evidence/task02` · `java -cp out DoctorMapBenchmark` | Doctor list follows the department; confirmation / error shown; close asks for confirmation; 16-line event trace recorded. |
| **3** Library screen | `javac -d out *.java` | `java -cp out LibrarySearch` · resize test: `java -cp out Task03Shots ../evidence/task03` · `java -Djava.awt.headless=true -cp out LayoutBenchmark` | Results area grows, search row and buttons keep their size (checked by code at three window sizes). |
| **4** Draw pad | `javac -d out *.java` | broken: `DrawPadBroken` · step 1: `DrawPadStep1` · **Complete the Code: `java -cp out DrawPad`** · `java -cp out Task04Shots ../evidence/task04` · `java -Djava.awt.headless=true -cp out RepaintBenchmark` | Defect reproduced; repaired program keeps its dots after repaint. `@Override` experiment: `cd experiment && javac OverrideCheck.java` → compile error. |
| **5** Converter | `javac -d out Converter.java ConverterAction.java Task05Test.java` and `javac -d out_v1 v1/*.java` and `javac -d out_v2 v2/*.java` | **Complete the Code: `java -cp out Converter`** · styles: `java -cp out_v1 ConverterD` · changed requirement: `java -cp out_v2 ConverterD` · shared Action: `java -cp out ConverterAction` | Four styles × two requirement versions; change effort measured in `evidence/task05/change_effort.txt`. |
| **6** Event registration | `javac -d out $(find src -name "*.java")` (Windows: see below) | demo without a database: `java -cp out eventreg.app.Main --demo` · MySQL: see below · tests: `java -cp out eventreg.test.ServiceTests` | Layered Swing + JDBC application; 21/21 tests; paging, filter, CSV export, duplicate rejection. |

Windows (cmd) for Task 6: `dir /s /b src\*.java > files.txt` then `javac -d out @files.txt`; use `;` instead of `:` in `-cp`.
The test drivers (`Task0xShots`, `Task02Trace`, `Task05Test`, `eventreg.test.Task06Shots`) need a screen; on a Linux server use `xvfb-run`.

### Task 6 with MySQL
1. Install MySQL 8 (or MariaDB) and download the **MySQL Connector/J** jar into `Task06/lib/`.
2. `mysql -u root -p < sql/schema.sql` then `mysql -u root -p < sql/seed.sql`.
3. Copy `db.properties.example` to `db.properties`; set `db.user`, and either `db.password` or the environment variable `EVENTREG_DB_PASSWORD`. `db.properties` is in `.gitignore` – never commit a password.
4. `java -cp out:lib/mysql-connector-j-<version>.jar eventreg.app.Main`
5. Tests on the real database (use an **empty** test database: `schema.sql` plus only the six events from `seed.sql`):
   `java -cp out:lib/mysql-connector-j-<version>.jar eventreg.test.ServiceTests --jdbc`

## What is in each task (short notes)
- **Task 1** – 10 deficiencies diagnosed (`FeeWindow_original.txt`); redesign `FeeWindow` → `FeeService` → `PaymentRepository` (JDBC / in-memory). Money is `BigDecimal`, SQL uses `PreparedStatement`, slow work runs on a worker thread.
- **Task 2** – `AppointmentService` (rules, doctors in a `Map` loaded once) and `AppointmentDesk` (AWT events). Every listener logs a line, giving the trace of Task 2.4.
- **Task 3** – `BorderLayout` frame; north/south panels (`BorderLayout`) hold `FlowLayout` rows; the results list is the only region in the CENTER.
- **Task 4** – three versions: given program, spelling fixed only, final program (stores points, draws them in `paint()`); `DrawPadBuffered` is the alternative.
- **Task 5** – `v1/` = original requirement, `v2/` = Enter key + dialog. Amount rule: plain non-negative decimal only (rejects `NaN`, `1e3`, `1d`, negatives).
- **Task 6** – packages `eventreg.ui` (Swing, `SwingWorker` for every database call), `eventreg.service` (validation, duplicate rule, CSV), `eventreg.dao` (JDBC with `LIMIT/OFFSET`, `UNIQUE(student_reg, event_id)` handled via MySQL error 1062), `eventreg.model`.

## Suggested commit messages (commit when each task is really done)
1. `Task01: diagnose fee window, add FeeService and repository, tests`
2. `Task02: appointment desk with event trace`
3. `Task03: library search layout and resize test`
4. `Task04: draw pad defects, repaired program, @Override experiment`
5. `Task05: four listener styles, changed requirement, complete-the-code`
6. `Task06: layered Swing+JDBC registration app, SQL script, tests`
7. `Add report and README`
