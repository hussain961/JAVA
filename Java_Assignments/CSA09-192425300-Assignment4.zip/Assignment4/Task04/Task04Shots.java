import java.awt.EventQueue;
import java.awt.Frame;
import java.awt.Rectangle;
import java.awt.Robot;
import java.awt.event.InputEvent;
import java.awt.image.BufferedImage;
import java.io.File;
import java.lang.reflect.Field;
import javax.imageio.ImageIO;

/**
 * Evidence driver for Task 4. Uses a REAL mouse (java.awt.Robot) to click three times in each
 * version of the draw pad, then forces a repaint - the same thing the AWT does when a minimised
 * window is restored - and photographs the window before and after.
 * Usage: java Task04Shots <output-folder>
 */
public class Task04Shots {
    static File out;
    static Robot robot;

    static void ui(Runnable r) throws Exception { EventQueue.invokeAndWait(r); }

    static void shot(Frame f, String name) throws Exception {
        Thread.sleep(400);
        Rectangle r = f.getBounds();
        BufferedImage img = robot.createScreenCapture(r);
        ImageIO.write(img, "png", new File(out, name));
    }

    static void click(int x, int y) throws Exception {
        robot.mouseMove(x, y);
        robot.delay(120);
        robot.mousePress(InputEvent.BUTTON1_DOWN_MASK);
        robot.delay(60);
        robot.mouseRelease(InputEvent.BUTTON1_DOWN_MASK);
        robot.delay(200);
    }

    static String label(Frame f) throws Exception {
        Field fld = null;
        for (Field x : f.getClass().getDeclaredFields()) if (x.getType() == java.awt.Label.class) fld = x;
        fld.setAccessible(true);
        return ((java.awt.Label) fld.get(f)).getText();
    }

    static void run(String tag, Frame f) throws Exception {
        ui(() -> { f.setLocation(0, 0); f.setVisible(true); });
        Thread.sleep(700);
        click(100, 80); click(200, 150); click(300, 100);
        shot(f, "task04_" + tag + "_a_after_3_clicks.png");
        String before = label(f);
        ui(f::repaint);                                  // == what happens when the window is restored
        shot(f, "task04_" + tag + "_b_after_repaint.png");
        System.out.println(tag + ": label after 3 clicks = \"" + before + "\"");
        ui(f::dispose);
    }

    public static void main(String[] args) throws Exception {
        out = new File(args[0]);
        out.mkdirs();
        robot = new Robot();
        Frame[] f = new Frame[3];
        ui(() -> { f[0] = new DrawPadBroken(); f[1] = new DrawPadStep1(); f[2] = new DrawPad(); });
        run("1_broken", f[0]);
        run("2_step1", f[1]);
        run("3_fixed", f[2]);
    }
}
