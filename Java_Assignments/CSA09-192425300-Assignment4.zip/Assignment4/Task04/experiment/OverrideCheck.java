import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

/**
 * Task 4.4 experiment. The method name is deliberately misspelt but @Override is present.
 * The compiler must refuse to compile this file:
 *     javac OverrideCheck.java
 * The message is saved in evidence/task04/override_compile_error.txt.
 */
public class OverrideCheck {
    public static void main(String[] args) {
        MouseAdapter a = new MouseAdapter() {
            @Override
            public void mouseclicked(MouseEvent e) {     // misspelt -> does not override anything
                System.out.println("clicked");
            }
        };
    }
}
