import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.image.BufferedImage;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * Alternative concept (Task 4): redraw n stored points in paint()  vs  copy one BufferedImage.
 * Run headless:  java -Djava.awt.headless=true RepaintBenchmark
 * Both versions draw into BufferedImages so that no screen is needed; the work per repaint
 * (n x fillOval  vs  one drawImage) is what is being compared.
 */
public class RepaintBenchmark {
    static final int W = 1280, H = 720;

    static long usedHeap() {
        for (int i = 0; i < 4; i++) { System.gc(); try { Thread.sleep(40); } catch (InterruptedException ignored) { } }
        Runtime r = Runtime.getRuntime();
        return r.totalMemory() - r.freeMemory();
    }

    public static void main(String[] args) {
        int[] ns = {100, 1_000, 10_000, 100_000, 1_000_000};
        BufferedImage screen = new BufferedImage(W, H, BufferedImage.TYPE_INT_RGB);
        BufferedImage canvas = new BufferedImage(W, H, BufferedImage.TYPE_INT_RGB);
        Random rnd = new Random(42);

        System.out.printf("Window %dx%d.  Image memory = %d x %d x 4 bytes = %d KB (constant)%n",
                W, H, W, H, W * H * 4 / 1024);
        System.out.printf("%10s | %-22s | %-22s | %-24s | %s%n", "n clicks",
                "repaint, stored points", "repaint, one image", "memory: n Points (KB)", "ratio");

        for (int n : ns) {
            long before = usedHeap();
            List<Point> points = new ArrayList<>(n);
            for (int i = 0; i < n; i++) points.add(new Point(rnd.nextInt(W), rnd.nextInt(H)));
            long listKb = Math.max(0, usedHeap() - before) / 1024;

            Graphics2D g = screen.createGraphics();
            g.setColor(Color.BLACK);
            Graphics2D gc = canvas.createGraphics();
            gc.setColor(Color.BLACK);
            for (Point p : points) gc.fillOval(p.x - 3, p.y - 3, 6, 6);    // build the cached image

            int repsPoints = Math.max(3, 3_000_000 / n);
            int repsImage = 2000;
            for (int w = 0; w < 3; w++) { for (Point p : points) g.fillOval(p.x - 3, p.y - 3, 6, 6); g.drawImage(canvas, 0, 0, null); }

            long t0 = System.nanoTime();
            for (int r = 0; r < repsPoints; r++) for (Point p : points) g.fillOval(p.x - 3, p.y - 3, 6, 6);
            double us1 = (System.nanoTime() - t0) / 1000.0 / repsPoints;
            long t1 = System.nanoTime();
            for (int r = 0; r < repsImage; r++) g.drawImage(canvas, 0, 0, null);
            double us2 = (System.nanoTime() - t1) / 1000.0 / repsImage;
            g.dispose(); gc.dispose();
            System.out.printf("%10d | %-19.1f us | %-19.1f us | %-24d | %.1fx%n", n, us1, us2, listKb, us1 / us2);
        }
    }
}
