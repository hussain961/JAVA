import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Frame;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Label;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.image.BufferedImage;

/**
 * Alternative concept (Task 4): draw each dot ONCE onto an off-screen BufferedImage and let
 * paint() copy that one image to the screen.
 *   paint():  O(1) in the number of clicks (one drawImage of width x height pixels)
 *   memory :  width x height x 4 bytes, independent of n - but it must be re-created on resize
 *             and it forgets WHERE the dots were (no undo, no export of coordinates).
 */
public class DrawPadBuffered extends Frame {
    private BufferedImage canvas = new BufferedImage(400, 300, BufferedImage.TYPE_INT_RGB);
    private final Label status = new Label("Clicks: 0");
    private int count = 0;

    public DrawPadBuffered() {
        super("Draw Pad (BufferedImage)");
        clear(canvas);
        add(status, BorderLayout.SOUTH);
        addMouseListener(new MouseAdapter() {
            @Override public void mouseClicked(MouseEvent e) {
                Graphics2D g = canvas.createGraphics();      // draw the dot ONCE, into the image
                g.setColor(Color.BLACK);
                g.fillOval(e.getX() - 3, e.getY() - 3, 6, 6);
                g.dispose();
                status.setText("Clicks: " + (++count));
                repaint();
            }
        });
        addComponentListener(new ComponentAdapter() {         // keep the image as large as the window
            @Override public void componentResized(ComponentEvent e) {
                int w = Math.max(1, getWidth()), h = Math.max(1, getHeight());
                if (w > canvas.getWidth() || h > canvas.getHeight()) {
                    BufferedImage bigger = new BufferedImage(Math.max(w, canvas.getWidth()),
                            Math.max(h, canvas.getHeight()), BufferedImage.TYPE_INT_RGB);
                    clear(bigger);
                    Graphics2D g = bigger.createGraphics();
                    g.drawImage(canvas, 0, 0, null);          // keep what was already drawn
                    g.dispose();
                    canvas = bigger;
                }
            }
        });
        addWindowListener(new WindowAdapter() {
            @Override public void windowClosing(WindowEvent e) { dispose(); }
        });
        setSize(400, 300);
    }

    private static void clear(BufferedImage img) {
        Graphics2D g = img.createGraphics();
        g.setColor(new Color(238, 238, 238));
        g.fillRect(0, 0, img.getWidth(), img.getHeight());
        g.dispose();
    }

    @Override public void paint(Graphics g) {
        g.drawImage(canvas, 0, 0, null);                      // one copy, whatever n is
        status.repaint();
    }

    public static void main(String[] args) { new DrawPadBuffered().setVisible(true); }
}
