import java.awt.BorderLayout;
import java.awt.Frame;
import java.awt.Graphics;
import java.awt.Label;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

/**
 * THE DEFECTIVE PROGRAM FROM THE ASSIGNMENT (Task 4) - imports and a main() added only so that
 * it compiles and can be run to reproduce the problem. Do not "fix" this file.
 *
 *  Defect 1: the method is spelt "mouseclicked" (lower-case c). MouseAdapter declares
 *            mouseClicked(MouseEvent). A differently spelt method is a NEW method, not an
 *            override, so Java never calls it -> nothing is drawn.
 *  Defect 2: count++ changes a variable only. Nothing calls status.setText(), so the label
 *            keeps showing "Clicks: 0".
 *  Defect 3: (hidden until defect 1 is fixed) drawing with getGraphics() is not persistent -
 *            see DrawPadStep1.
 */
public class DrawPadBroken extends Frame {
    int count = 0;
    Label status = new Label("Clicks: 0");

    public DrawPadBroken() {
        add(status, BorderLayout.SOUTH);
        addMouseListener(new MouseAdapter() {
            public void mouseclicked(MouseEvent e) {          // <-- misspelt, never called
                count++;
                Graphics g = getGraphics();
                g.fillOval(e.getX(), e.getY(), 6, 6);
            }
        });
        setSize(400, 300);
        setVisible(true);
    }

    public static void main(String[] args) { new DrawPadBroken(); }
}
