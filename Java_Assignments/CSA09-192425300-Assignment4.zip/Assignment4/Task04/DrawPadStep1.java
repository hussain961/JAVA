import java.awt.BorderLayout;
import java.awt.Frame;
import java.awt.Graphics;
import java.awt.Label;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

/**
 * Task 4.2 - the program after ONLY the first defect is fixed (name spelt correctly, label updated).
 * Clicks now work, but the dots are drawn with getGraphics(): they exist only as pixels on the
 * screen. The AWT calls paint() again whenever the window is restored, uncovered or resized,
 * paint() draws nothing, and the pixels are lost. See DrawPad.java for the real fix.
 */
public class DrawPadStep1 extends Frame {
    int count = 0;
    Label status = new Label("Clicks: 0");

    public DrawPadStep1() {
        super("Draw Pad - step 1 (dots not stored)");
        add(status, BorderLayout.SOUTH);
        addMouseListener(new MouseAdapter() {
            @Override public void mouseClicked(MouseEvent e) {
                count++;
                status.setText("Clicks: " + count);
                Graphics g = getGraphics();
                g.fillOval(e.getX() - 3, e.getY() - 3, 6, 6);   // pixels only - nothing remembers them
                g.dispose();
            }
        });
        addWindowListener(new WindowAdapter() {
            @Override public void windowClosing(WindowEvent e) { dispose(); }
        });
        setSize(400, 300);
    }

    public static void main(String[] args) { new DrawPadStep1().setVisible(true); }
}
