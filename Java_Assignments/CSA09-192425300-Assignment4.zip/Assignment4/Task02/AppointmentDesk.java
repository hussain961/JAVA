import java.awt.BorderLayout;
import java.awt.Button;
import java.awt.Choice;
import java.awt.Dialog;
import java.awt.EventQueue;
import java.awt.FlowLayout;
import java.awt.Frame;
import java.awt.GridLayout;
import java.awt.Label;
import java.awt.Panel;
import java.awt.TextField;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Task 2 - Hospital Outpatient Appointment Desk (AWT).
 * Every listener method writes a line to {@link #trace}, so the order of calls
 * asked for in Task 2.4 can be printed from a real run.
 */
public class AppointmentDesk extends Frame {

    final TextField patientId = new TextField(12);
    final Choice dept = new Choice();
    final Choice doctor = new Choice();
    final Choice slot = new Choice();
    final Button book = new Button("Book Appointment");
    final Label status = new Label("Enter the patient ID and choose a department.");

    Dialog confirmDialog;                       // package-private for the test driver
    Button confirmYes, confirmNo;

    final List<String> trace = Collections.synchronizedList(new ArrayList<>());
    private final AppointmentService service;
    private boolean bookingInProgress = false;

    public AppointmentDesk(AppointmentService service) {
        super("Outpatient Appointment Desk");
        log("constructor AppointmentDesk()");
        this.service = service;

        dept.add(AppointmentService.PLEASE_SELECT);
        for (String d : service.departments()) dept.add(d);
        doctor.add(AppointmentService.PLEASE_SELECT);
        slot.add(AppointmentService.PLEASE_SELECT);
        for (String s : service.slots()) slot.add(s);

        Panel form = new Panel(new GridLayout(4, 2, 6, 8));
        form.add(new Label("Patient ID:"));    form.add(patientId);
        form.add(new Label("Department:"));    form.add(dept);
        form.add(new Label("Doctor:"));        form.add(doctor);
        form.add(new Label("Time slot:"));     form.add(slot);

        Panel buttonRow = new Panel(new FlowLayout());
        buttonRow.add(book);
        Panel south = new Panel(new BorderLayout());
        south.add(buttonRow, BorderLayout.NORTH);
        south.add(status, BorderLayout.SOUTH);

        add(form, BorderLayout.CENTER);
        add(south, BorderLayout.SOUTH);

        // ---- event sources and their listeners (the table in Task 2.1) ----
        dept.addItemListener(e -> {
            log("ItemListener.itemStateChanged   source=dept   item=" + e.getItem());
            refreshDoctors();
            bookingInProgress = true;
        });
        patientId.addTextListener(e -> {
            log("TextListener.textValueChanged   source=patientId");
            bookingInProgress = true;
        });
        book.addActionListener(e -> {
            log("ActionListener.actionPerformed  source=book");
            onBook();
        });
        addWindowListener(new WindowAdapter() {
            @Override public void windowOpened(WindowEvent e)      { log("WindowListener.windowOpened"); }
            @Override public void windowActivated(WindowEvent e)   { log("WindowListener.windowActivated"); }
            @Override public void windowDeactivated(WindowEvent e) { log("WindowListener.windowDeactivated"); }
            @Override public void windowIconified(WindowEvent e)   { log("WindowListener.windowIconified"); }
            @Override public void windowDeiconified(WindowEvent e) { log("WindowListener.windowDeiconified"); }
            @Override public void windowClosing(WindowEvent e)     { log("WindowListener.windowClosing"); onClosing(); }
            @Override public void windowClosed(WindowEvent e)      { log("WindowListener.windowClosed"); }
        });
        setSize(430, 280);
        log("constructor AppointmentDesk() finished");
    }

    void log(String line) {
        trace.add(line);
        System.out.println("[trace " + String.format("%02d", trace.size()) + "] " + line);
    }

    /** Task 2.3(a): refresh the doctor list when the department changes. */
    private void refreshDoctors() {
        doctor.removeAll();
        doctor.add(AppointmentService.PLEASE_SELECT);
        for (AppointmentService.Doctor d : service.doctorsFor(dept.getSelectedItem())) doctor.add(d.name());
        status.setText(doctor.getItemCount() - 1 + " doctor(s) in " + dept.getSelectedItem());
    }

    /** Task 2.3(b): validate and book. All rules are inside the service. */
    private void onBook() {
        try {
            AppointmentService.Confirmation c = service.book(patientId.getText(),
                    dept.getSelectedItem(), doctor.getSelectedItem(), slot.getSelectedItem());
            status.setText("Booked " + c);
            bookingInProgress = false;
        } catch (AppointmentService.BookingException ex) {
            status.setText("Error: " + ex.getMessage());
        }
    }

    private void onClosing() {
        if (bookingInProgress && !confirm("A booking is in progress. Close the window anyway?")) {
            log("close cancelled by user");
            return;
        }
        dispose();
    }

    private boolean confirm(String question) {
        boolean[] answer = {false};
        Dialog d = new Dialog(this, "Confirm close", true);
        d.setLayout(new BorderLayout(10, 10));
        d.add(new Label(question, Label.CENTER), BorderLayout.CENTER);
        Button yes = new Button("Yes, close");
        Button no = new Button("No, keep editing");
        yes.addActionListener(e -> { answer[0] = true; d.dispose(); });
        no.addActionListener(e -> d.dispose());
        d.addWindowListener(new WindowAdapter() {
            @Override public void windowClosing(WindowEvent e) { d.dispose(); }
        });
        Panel p = new Panel(new FlowLayout());
        p.add(yes); p.add(no);
        d.add(p, BorderLayout.SOUTH);
        d.pack();
        d.setLocationRelativeTo(this);
        confirmDialog = d; confirmYes = yes; confirmNo = no;
        d.setVisible(true);                      // modal: blocks here (event loop keeps running)
        confirmDialog = null;
        return answer[0];
    }

    public static void main(String[] args) {
        EventQueue.invokeLater(() -> {
            AppointmentDesk desk = new AppointmentDesk(new AppointmentService());
            desk.log("setVisible(true)");
            desk.setVisible(true);
        });
    }
}
