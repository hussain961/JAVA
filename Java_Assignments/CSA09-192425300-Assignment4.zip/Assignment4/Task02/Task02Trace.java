import java.awt.Dialog;
import java.awt.EventQueue;
import java.awt.Rectangle;
import java.awt.Robot;
import java.awt.event.ActionEvent;
import java.awt.event.ItemEvent;
import java.awt.event.WindowEvent;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.PrintWriter;
import javax.imageio.ImageIO;

/**
 * Evidence driver for Task 2. Opens the real window, fires real AWT events on the
 * real components, saves screenshots and writes the call-order trace (Task 2.4).
 * Usage: java Task02Trace <output-folder>      (needs a display; xvfb-run on a server)
 */
public class Task02Trace {
    static AppointmentDesk d;
    static File out;

    static void ui(Runnable r) throws Exception { EventQueue.invokeAndWait(r); }

    static void shot(String name, boolean withDialog) throws Exception {
        Thread.sleep(300);
        Rectangle r = d.getBounds();
        Dialog dlg = d.confirmDialog;
        if (withDialog && dlg != null) r = r.union(dlg.getBounds());
        BufferedImage img = new Robot().createScreenCapture(r);
        ImageIO.write(img, "png", new File(out, name));
        System.out.println("saved " + name);
    }

    static void choose(java.awt.Choice c, String item) throws Exception {
        ui(() -> {
            c.select(item);
            c.dispatchEvent(new ItemEvent(c, ItemEvent.ITEM_STATE_CHANGED, item, ItemEvent.SELECTED));
        });
    }

    static void click(java.awt.Button b) throws Exception {
        ui(() -> b.dispatchEvent(new ActionEvent(b, ActionEvent.ACTION_PERFORMED, b.getLabel())));
    }

    public static void main(String[] args) throws Exception {
        out = new File(args[0]);
        out.mkdirs();
        ui(() -> {
            d = new AppointmentDesk(new AppointmentService());
            d.setLocation(0, 0);
            d.log("setVisible(true)");
            d.setVisible(true);
        });
        Thread.sleep(700);
        shot("task02_1_opened.png", false);

        click(d.book);                                              // nothing entered
        shot("task02_2_error_empty.png", false);

        ui(() -> d.patientId.setText("P10234"));
        choose(d.dept, "Orthopaedics");                             // doctor list refreshes
        shot("task02_3_doctors_refreshed.png", false);
        ui(() -> { d.doctor.select("Dr. R. Fernandes"); d.slot.select("10:00"); });
        click(d.book);
        shot("task02_4_booked.png", false);

        ui(() -> d.patientId.setText("P20456"));                    // different patient, same doctor+slot
        click(d.book);
        shot("task02_5_error_double_booking.png", false);

        // Close while a booking is in progress -> confirmation dialog
        EventQueue.invokeLater(() -> d.dispatchEvent(new WindowEvent(d, WindowEvent.WINDOW_CLOSING)));
        for (int i = 0; i < 50 && (d.confirmDialog == null || !d.confirmDialog.isShowing()); i++) Thread.sleep(100);
        shot("task02_6_confirm_close.png", true);
        ui(() -> d.confirmNo.dispatchEvent(new ActionEvent(d.confirmNo, ActionEvent.ACTION_PERFORMED, "no")));
        Thread.sleep(300);

        // Close again and confirm
        EventQueue.invokeLater(() -> d.dispatchEvent(new WindowEvent(d, WindowEvent.WINDOW_CLOSING)));
        for (int i = 0; i < 50 && (d.confirmDialog == null || !d.confirmDialog.isShowing()); i++) Thread.sleep(100);
        ui(() -> d.confirmYes.dispatchEvent(new ActionEvent(d.confirmYes, ActionEvent.ACTION_PERFORMED, "yes")));
        Thread.sleep(500);

        try (PrintWriter pw = new PrintWriter(new File(out, "trace.txt"))) {
            int i = 1;
            for (String line : d.trace) pw.printf("%02d  %s%n", i++, line);
        }
        System.out.println("trace saved (" + d.trace.size() + " lines)");
    }
}
