import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Alternative concept (Task 2): doctor list loaded ONCE into Map<String, List<Doctor>>.
 * Measures (a) the time of a department-change lookup and (b) the heap used by the map
 * for d departments and m doctors. The "query the database on every change" alternative needs a
 * database and is analysed in the report, not measured here.
 */
public class DoctorMapBenchmark {

    record Doctor(String name, String department) { }

    static long usedHeap() {
        for (int i = 0; i < 4; i++) { System.gc(); try { Thread.sleep(50); } catch (InterruptedException ignored) { } }
        Runtime r = Runtime.getRuntime();
        return r.totalMemory() - r.freeMemory();
    }

    public static void main(String[] args) {
        int[][] cases = {{10, 100}, {50, 1_000}, {200, 10_000}, {1_000, 100_000}};
        System.out.printf("%6s %9s | %-18s | %-18s%n", "d", "m", "lookup (ns)", "map memory (KB)");
        for (int[] c : cases) {
            int d = c[0], m = c[1];
            long before = usedHeap();
            Map<String, List<Doctor>> map = new HashMap<>();
            for (int i = 0; i < d; i++) map.put("Dept-" + i, new ArrayList<>());
            for (int i = 0; i < m; i++) {
                String dept = "Dept-" + (i % d);
                map.get(dept).add(new Doctor("Dr. " + i, dept));
            }
            long after = usedHeap();
            String[] keys = new String[d];
            for (int i = 0; i < d; i++) keys[i] = "Dept-" + i;
            long sink = 0;
            int reps = 2_000_000;
            for (int i = 0; i < reps; i++) sink += map.get(keys[i % d]).size();     // warm-up
            long t0 = System.nanoTime();
            for (int i = 0; i < reps; i++) sink += map.get(keys[i % d]).size();
            double ns = (System.nanoTime() - t0) / (double) reps;
            System.out.printf("%6d %9d | %-18.1f | %-18d   (sink %d)%n", d, m, ns, Math.max(0, after - before) / 1024, sink);
        }
    }
}
