import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Pattern;

/** Doctor data and booking rules for the outpatient desk. No AWT imports. */
public class AppointmentService {

    public record Doctor(String name, String department) { }
    public record Confirmation(int number, String patientId, String doctor, String slot) {
        @Override public String toString() {
            return "#" + number + " " + patientId + " with " + doctor + " at " + slot;
        }
    }
    public static class BookingException extends Exception {
        public BookingException(String message) { super(message); }
    }

    public static final String PLEASE_SELECT = "-- Select --";
    private static final Pattern PATIENT_ID = Pattern.compile("P[0-9]{5}");

    /** Loaded ONCE; a department change is then a map lookup, not a database query. */
    private final Map<String, List<Doctor>> doctorsByDepartment = new LinkedHashMap<>();
    private final List<String> slots = List.of("09:00", "09:30", "10:00", "10:30", "11:00");
    private final Set<String> bookedDoctorSlots = new HashSet<>();   // "doctor|slot"
    private final Set<String> bookedPatientSlots = new HashSet<>();  // "patient|slot"
    private int nextNumber = 1;

    public AppointmentService() {
        add("Cardiology", "Dr. Meena Rao", "Dr. Arun Kumar");
        add("Orthopaedics", "Dr. S. Iyer", "Dr. R. Fernandes", "Dr. L. Das");
        add("Paediatrics", "Dr. N. Banerjee");
        add("ENT", "Dr. K. Menon", "Dr. P. Joseph");
    }

    private void add(String dept, String... names) {
        List<Doctor> list = new ArrayList<>();
        for (String n : names) list.add(new Doctor(n, dept));
        doctorsByDepartment.put(dept, list);
    }

    public List<String> departments() { return new ArrayList<>(doctorsByDepartment.keySet()); }
    public List<String> slots() { return slots; }

    public List<Doctor> doctorsFor(String department) {
        return doctorsByDepartment.getOrDefault(department, Collections.emptyList());
    }

    public synchronized Confirmation book(String patientId, String dept, String doctor, String slot)
            throws BookingException {
        String id = patientId == null ? "" : patientId.trim();
        if (id.isEmpty()) throw new BookingException("Patient ID is required.");
        if (!PATIENT_ID.matcher(id).matches())
            throw new BookingException("Patient ID must look like P12345.");
        if (dept == null || PLEASE_SELECT.equals(dept)) throw new BookingException("Select a department.");
        if (doctor == null || PLEASE_SELECT.equals(doctor)) throw new BookingException("Select a doctor.");
        boolean belongs = doctorsFor(dept).stream().anyMatch(d -> d.name().equals(doctor));
        if (!belongs) throw new BookingException(doctor + " does not work in " + dept + ".");
        if (slot == null || PLEASE_SELECT.equals(slot)) throw new BookingException("Select a time slot.");
        if (!slots.contains(slot)) throw new BookingException("Unknown time slot.");
        if (!bookedDoctorSlots.add(doctor + "|" + slot))
            throw new BookingException(doctor + " is already booked at " + slot + ".");
        if (!bookedPatientSlots.add(id + "|" + slot)) {
            bookedDoctorSlots.remove(doctor + "|" + slot);          // roll back
            throw new BookingException("Patient " + id + " already has an appointment at " + slot + ".");
        }
        return new Confirmation(nextNumber++, id, doctor, slot);
    }
}
