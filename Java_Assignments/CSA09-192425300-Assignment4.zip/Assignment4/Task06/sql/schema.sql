-- Cultural Fest registration database (MySQL 5.7+ / 8.x, MariaDB 10.x)
-- Run:  mysql -u root -p < sql/schema.sql
CREATE DATABASE IF NOT EXISTS eventreg CHARACTER SET utf8mb4;
USE eventreg;

CREATE TABLE IF NOT EXISTS events (
    id          INT           NOT NULL AUTO_INCREMENT,
    name        VARCHAR(100)  NOT NULL,
    event_date  DATE          NOT NULL,
    venue       VARCHAR(100)  NOT NULL,
    PRIMARY KEY (id),
    UNIQUE KEY uq_event_name (name)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS registrations (
    id             BIGINT        NOT NULL AUTO_INCREMENT,
    student_reg    VARCHAR(12)   NOT NULL,
    student_name   VARCHAR(60)   NOT NULL,
    email          VARCHAR(100)  NOT NULL,
    event_id       INT           NOT NULL,
    registered_at  TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    CONSTRAINT fk_reg_event FOREIGN KEY (event_id) REFERENCES events (id),
    -- THE duplicate rule, enforced by the database itself: one student, one registration per event.
    -- (MySQL reports a violation as error code 1062, which JdbcRegistrationDao turns into
    --  DuplicateRegistrationException.)  It also creates the index used by the exists() lookup.
    CONSTRAINT uq_student_event UNIQUE (student_reg, event_id),
    KEY idx_reg_event (event_id)             -- fast "filter by event" and its COUNT(*)
) ENGINE=InnoDB;
