USE eventreg;
INSERT IGNORE INTO events (id, name, event_date, venue) VALUES
 (1, 'Battle of Bands',             '2026-12-05', 'Open Air Theatre'),
 (2, 'Classical Dance Night',       '2026-12-06', 'Main Auditorium'),
 (3, 'Cultural Fest Inauguration',  '2026-12-04', 'Main Auditorium'),
 (4, 'Hackathon 24h',               '2026-12-07', 'CS Block Lab 3'),
 (5, 'Photography Walk',            '2026-12-05', 'Campus Gate 2'),
 (6, 'Quiz League',                 '2026-12-06', 'Seminar Hall');

INSERT IGNORE INTO registrations (student_reg, student_name, email, event_id) VALUES
 ('192425301', 'Sample Student', 'sample.student@saveetha.com', 1),
 ('192425302', 'Meera Nair',     'meera.nair@saveetha.com',     2),
 ('192425303', 'Rohan Das',      'rohan.das@saveetha.com',      4);
