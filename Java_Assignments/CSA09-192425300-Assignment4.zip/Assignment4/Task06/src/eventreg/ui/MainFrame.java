package eventreg.ui;

import eventreg.model.Event;
import eventreg.model.Page;
import eventreg.model.Registration;
import eventreg.service.RegistrationService;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import java.io.File;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.time.format.DateTimeFormatter;
import java.util.List;
import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JProgressBar;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.KeyStroke;
import javax.swing.table.DefaultTableModel;

/**
 * Main window of the Cultural Fest registration desk (PRESENTATION layer).
 * It never touches SQL: it calls RegistrationService, always through Background.run()
 * (a SwingWorker), so the window stays responsive while the database works.
 */
public class MainFrame extends JFrame {

    public static final int PAGE_SIZE = 25;
    private static final Event ALL_EVENTS = new Event(-1, "All events");
    private static final String[] COLUMNS = {"ID", "Register No", "Name", "Email", "Event", "Registered at"};
    private static final DateTimeFormatter STAMP = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");

    private final RegistrationService service;
    private final DefaultTableModel model = new DefaultTableModel(COLUMNS, 0) {
        @Override public boolean isCellEditable(int row, int col) { return false; }
    };
    private final JTable table = new JTable(model);
    private final JComboBox<Event> eventFilter = new JComboBox<>();
    private final JButton prevButton = new JButton("< Prev");
    private final JButton nextButton = new JButton("Next >");
    private final JLabel pageLabel = new JLabel(" ");
    private final JLabel statusLabel = new JLabel(" ");
    private final JProgressBar busyBar = new JProgressBar();

    private List<Event> events = List.of();
    private int page = 0;
    private int totalPages = 1;
    private int requestSeq = 0;               // ignore answers to out-of-date requests
    private boolean populating = false;
    private volatile boolean loading = false;
    private long totalRows = 0;

    private final Action newRegistration = new AbstractAction("New Registration...") {
        @Override public void actionPerformed(ActionEvent e) { openNewRegistration(); }
    };
    private final Action exportCsv = new AbstractAction("Export CSV...") {
        @Override public void actionPerformed(ActionEvent e) { chooseAndExport(); }
    };
    private final Action refresh = new AbstractAction("Refresh") {
        @Override public void actionPerformed(ActionEvent e) { reload(); }
    };

    public MainFrame(RegistrationService service) {
        super("Cultural Fest - Event Registration");
        this.service = service;

        int shortcut = Toolkit.getDefaultToolkit().getMenuShortcutKeyMaskEx();
        newRegistration.putValue(Action.ACCELERATOR_KEY, KeyStroke.getKeyStroke(KeyEvent.VK_N, shortcut));
        exportCsv.putValue(Action.ACCELERATOR_KEY, KeyStroke.getKeyStroke(KeyEvent.VK_E, shortcut));
        refresh.putValue(Action.ACCELERATOR_KEY, KeyStroke.getKeyStroke(KeyEvent.VK_F5, 0));

        JMenuBar bar = new JMenuBar();
        JMenu file = new JMenu("File");
        file.setMnemonic(KeyEvent.VK_F);
        file.add(new JMenuItem(newRegistration));
        file.add(new JMenuItem(exportCsv));
        file.addSeparator();
        JMenuItem exit = new JMenuItem("Exit");
        exit.addActionListener(e -> dispose());
        file.add(exit);
        JMenu view = new JMenu("View");
        view.add(new JMenuItem(refresh));
        JMenu help = new JMenu("Help");
        JMenuItem about = new JMenuItem("About");
        about.addActionListener(e -> JOptionPane.showMessageDialog(this,
                "Cultural Fest Registration Desk\nSwing + JDBC, layered (UI / service / DAO).", "About",
                JOptionPane.INFORMATION_MESSAGE));
        help.add(about);
        bar.add(file); bar.add(view); bar.add(help);
        setJMenuBar(bar);

        JPanel top = new JPanel(new FlowLayout(FlowLayout.LEFT));
        top.add(new JLabel("Event:"));
        top.add(eventFilter);
        top.add(new JButton(newRegistration));
        top.add(new JButton(refresh));
        busyBar.setIndeterminate(true);
        busyBar.setVisible(false);
        busyBar.setPreferredSize(new java.awt.Dimension(110, 14));
        top.add(busyBar);

        table.setFillsViewportHeight(true);
        table.setAutoCreateRowSorter(false);          // sorting one page would mislead; sorting is done by the DB
        table.getColumnModel().getColumn(0).setPreferredWidth(50);
        table.getColumnModel().getColumn(1).setPreferredWidth(110);
        table.getColumnModel().getColumn(2).setPreferredWidth(150);
        table.getColumnModel().getColumn(3).setPreferredWidth(230);
        table.getColumnModel().getColumn(4).setPreferredWidth(170);
        table.getColumnModel().getColumn(5).setPreferredWidth(130);

        JPanel nav = new JPanel(new FlowLayout(FlowLayout.CENTER));
        nav.add(prevButton); nav.add(pageLabel); nav.add(nextButton);
        JPanel south = new JPanel(new BorderLayout());
        south.add(nav, BorderLayout.NORTH);
        statusLabel.setBorder(BorderFactory.createEmptyBorder(2, 8, 4, 8));
        south.add(statusLabel, BorderLayout.SOUTH);

        add(top, BorderLayout.NORTH);
        add(new JScrollPane(table), BorderLayout.CENTER);
        add(south, BorderLayout.SOUTH);

        prevButton.addActionListener(e -> { if (page > 0) { page--; reload(); } });
        nextButton.addActionListener(e -> { if (page < totalPages - 1) { page++; reload(); } });
        eventFilter.addActionListener(e -> { if (!populating) { page = 0; reload(); } });

        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setSize(880, 560);
        setLocationRelativeTo(null);
        updateNav();
        loadEventsThenRows();
    }

    // ------------------------------------------------------------------ loading

    private void loadEventsThenRows() {
        setBusy(true);
        setStatus("Connecting...", Color.DARK_GRAY);
        Background.run(service::events, list -> {
            events = list;
            populating = true;
            eventFilter.removeAllItems();
            eventFilter.addItem(ALL_EVENTS);
            for (Event e : list) eventFilter.addItem(e);
            populating = false;
            reload();
        }, err -> { setBusy(false); showError("Could not load the event list", err); });
    }

    /** Loads the current page of the current filter. Never blocks the EDT. */
    public void reload() {
        final int seq = ++requestSeq;
        final Integer eventId = selectedEventId();
        final int wantedPage = page;
        final long started = System.nanoTime();
        setBusy(true);
        Background.run(() -> service.page(eventId, wantedPage, PAGE_SIZE), result -> {
            if (seq != requestSeq) return;                         // a newer request is on its way
            show(result, (System.nanoTime() - started) / 1_000_000);
            setBusy(false);
        }, err -> {
            if (seq != requestSeq) return;
            setBusy(false);
            showError("Could not load registrations", err);
        });
    }

    private void show(Page<Registration> p, long millis) {
        model.setRowCount(0);
        for (Registration r : p.rows()) {
            model.addRow(new Object[]{r.id(), r.studentReg(), r.studentName(), r.email(), r.eventName(),
                    r.registeredAt().format(STAMP)});
        }
        totalRows = p.totalRows();
        totalPages = p.totalPages();
        if (page > totalPages - 1) page = totalPages - 1;
        pageLabel.setText("Page " + (p.pageIndex() + 1) + " of " + totalPages + "   (" + totalRows + " registrations)");
        updateNav();
        setStatus("Loaded " + p.rows().size() + " row(s) in " + millis + " ms (page size " + PAGE_SIZE + ").", Color.DARK_GRAY);
    }

    private Integer selectedEventId() {
        Event e = (Event) eventFilter.getSelectedItem();
        return e == null || e.id() < 0 ? null : e.id();
    }

    private void setBusy(boolean busy) {
        loading = busy;
        busyBar.setVisible(busy);
        eventFilter.setEnabled(!busy);
        if (busy) { prevButton.setEnabled(false); nextButton.setEnabled(false); }
        else updateNav();
    }

    private void updateNav() {
        prevButton.setEnabled(!loading && page > 0);
        nextButton.setEnabled(!loading && page < totalPages - 1);
    }

    private void setStatus(String text, Color colour) { statusLabel.setForeground(colour); statusLabel.setText(text); }

    private void showError(String what, Throwable err) {
        if (err.getCause() != null) err.getCause().printStackTrace(); else err.printStackTrace();
        setStatus(what + " - the database may be unavailable.", new Color(0xB00020));
        JOptionPane.showMessageDialog(this, what + ".\nCheck that the database is running and db.properties is correct.",
                "Database problem", JOptionPane.ERROR_MESSAGE);
    }

    // ------------------------------------------------------------------ actions

    public void openNewRegistration() {
        newRegistrationDialog().setVisible(true);
    }

    /** Builds (does not show) the registration form. */
    public RegistrationDialog newRegistrationDialog() {
        return new RegistrationDialog(this, service, events, () -> {
            setStatus("Registration saved.", new Color(0x1B6E2E));
            reload();
        });
    }

    private void chooseAndExport() {
        JFileChooser chooser = new JFileChooser();
        chooser.setSelectedFile(new File("registrations.csv"));
        if (chooser.showSaveDialog(this) == JFileChooser.APPROVE_OPTION) exportTo(chooser.getSelectedFile());
    }

    /** Exports the current filter to a UTF-8 CSV file, in the background. */
    public void exportTo(File file) {
        final Integer eventId = selectedEventId();
        setStatus("Exporting...", Color.DARK_GRAY);
        Background.run(() -> {
            try (Writer w = Files.newBufferedWriter(file.toPath(), StandardCharsets.UTF_8)) {
                return service.exportCsv(eventId, w);
            }
        }, n -> setStatus("Exported " + n + " registration(s) to " + file.getName(), new Color(0x1B6E2E)),
           err -> showError("Export failed", err));
    }

    // ------------------------------------------------------------------ hooks for tests / screenshots

    public boolean isLoading() { return loading; }
    public JTable table() { return table; }
    public long totalRows() { return totalRows; }
    public String statusText() { return statusLabel.getText(); }
    public void selectEvent(String name) {
        for (int i = 0; i < eventFilter.getItemCount(); i++)
            if (eventFilter.getItemAt(i).name().equals(name)) eventFilter.setSelectedIndex(i);
    }
}
