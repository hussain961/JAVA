package eventreg.ui;

import eventreg.dao.DataAccessException;
import eventreg.dao.DuplicateRegistrationException;
import eventreg.model.Event;
import eventreg.model.NewRegistration;
import eventreg.service.RegistrationService;
import eventreg.service.ValidationException;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Frame;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.util.List;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

/** Modal form for one new registration. Validation is instant; saving runs in the background. */
public class RegistrationDialog extends JDialog {

    private static final Event PLACEHOLDER = new Event(-1, "-- Select event --");
    private static final Color ERROR = new Color(0xB00020), OK = new Color(0x1B6E2E);

    private final JTextField regField = new JTextField(16);
    private final JTextField nameField = new JTextField(24);
    private final JTextField emailField = new JTextField(24);
    private final JComboBox<Event> eventCombo = new JComboBox<>();
    private final JButton registerButton = new JButton("Register");
    private final JButton cancelButton = new JButton("Cancel");
    private final JLabel message = new JLabel(" ");

    private final RegistrationService service;
    private final Runnable onSuccess;
    private volatile boolean saving;

    public RegistrationDialog(Frame owner, RegistrationService service, List<Event> events, Runnable onSuccess) {
        super(owner, "New Registration", true);
        this.service = service;
        this.onSuccess = onSuccess;

        eventCombo.addItem(PLACEHOLDER);
        for (Event e : events) eventCombo.addItem(e);

        JPanel form = new JPanel(new GridBagLayout());
        form.setBorder(BorderFactory.createEmptyBorder(12, 14, 6, 14));
        GridBagConstraints c = new GridBagConstraints();
        c.insets = new Insets(4, 4, 4, 4);
        c.anchor = GridBagConstraints.WEST;
        addRow(form, c, 0, "Register No:", regField);
        addRow(form, c, 1, "Name:", nameField);
        addRow(form, c, 2, "Email:", emailField);
        addRow(form, c, 3, "Event:", eventCombo);

        message.setVerticalAlignment(JLabel.TOP);
        message.setBorder(BorderFactory.createEmptyBorder(0, 18, 0, 14));
        message.setPreferredSize(new java.awt.Dimension(420, 84));

        JPanel buttons = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        buttons.add(registerButton);
        buttons.add(cancelButton);

        add(form, BorderLayout.NORTH);
        add(message, BorderLayout.CENTER);
        add(buttons, BorderLayout.SOUTH);

        registerButton.addActionListener(e -> submit());
        cancelButton.addActionListener(e -> dispose());
        getRootPane().setDefaultButton(registerButton);              // Enter = Register
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        pack();
        setLocationRelativeTo(owner);
    }

    private static void addRow(JPanel p, GridBagConstraints c, int row, String label, java.awt.Component field) {
        c.gridy = row; c.gridx = 0; p.add(new JLabel(label), c);
        c.gridx = 1; p.add(field, c);
    }

    /** Called by the Register button (EDT). Public so the test driver can press it. */
    public void submit() {
        if (saving) return;
        NewRegistration request;
        try {
            request = service.validate(regField.getText(), nameField.getText(), emailField.getText(),
                    (Event) eventCombo.getSelectedItem());
        } catch (ValidationException ex) {
            StringBuilder html = new StringBuilder("<html>");
            for (String p : ex.problems()) html.append("&bull; ").append(escape(p)).append("<br>");
            show(html.append("</html>").toString(), ERROR);
            return;
        }
        setSaving(true);
        show("Saving...", Color.DARK_GRAY);
        Background.run(() -> { service.register(request); return Boolean.TRUE; },
            ok -> { onSuccess.run(); dispose(); },
            err -> {
                setSaving(false);
                if (err instanceof DuplicateRegistrationException) {
                    show("<html>&bull; " + escape(err.getMessage()) + "</html>", ERROR);
                } else {
                    if (err instanceof DataAccessException && err.getCause() != null) err.getCause().printStackTrace();
                    show("<html>&bull; The database is not available right now. Nothing was saved - please try again.</html>", ERROR);
                }
            });
    }

    private void setSaving(boolean s) {
        saving = s;
        registerButton.setEnabled(!s);
    }

    private void show(String text, Color colour) { message.setForeground(colour); message.setText(text); }

    private static String escape(String s) { return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;"); }

    // ---- hooks used by the screenshot / test driver ----
    public void fill(String reg, String name, String email, String eventName) {
        regField.setText(reg); nameField.setText(name); emailField.setText(email);
        for (int i = 0; i < eventCombo.getItemCount(); i++)
            if (eventCombo.getItemAt(i).name().equals(eventName)) eventCombo.setSelectedIndex(i);
    }
    public String messageText() { return message.getText().replace("&bull;", "-").replaceAll("<[^>]*>", " ").replaceAll("\\s+", " ").trim(); }
    public boolean isSaving() { return saving; }
}
