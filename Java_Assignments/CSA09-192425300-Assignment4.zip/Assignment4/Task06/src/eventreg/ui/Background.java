package eventreg.ui;

import java.util.concurrent.ExecutionException;
import java.util.function.Consumer;
import javax.swing.SwingWorker;

/**
 * The ONE place where slow work leaves the event-dispatch thread.
 * task runs on a SwingWorker thread; onSuccess / onError run back on the EDT.
 */
final class Background {
    interface Task<T> { T call() throws Exception; }

    private Background() { }

    static <T> void run(Task<T> task, Consumer<T> onSuccess, Consumer<Throwable> onError) {
        new SwingWorker<T, Void>() {
            @Override protected T doInBackground() throws Exception { return task.call(); }
            @Override protected void done() {
                try {
                    onSuccess.accept(get());
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                    onError.accept(e);
                } catch (ExecutionException e) {
                    onError.accept(e.getCause());
                }
            }
        }.execute();
    }
}
