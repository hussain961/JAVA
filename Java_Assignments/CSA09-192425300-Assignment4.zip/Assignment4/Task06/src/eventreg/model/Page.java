package eventreg.model;

import java.util.List;

/** One page of results plus the total row count (so the UI can show "Page 3 of 40"). */
public record Page<T>(List<T> rows, int pageIndex, int pageSize, long totalRows) {
    public int totalPages() { return (int) Math.max(1, (totalRows + pageSize - 1) / pageSize); }
}
