package eventreg.model;

import java.time.LocalDateTime;

/** One stored registration (a row of the table shown to the committee). */
public record Registration(long id, String studentReg, String studentName, String email,
                           int eventId, String eventName, LocalDateTime registeredAt) { }
