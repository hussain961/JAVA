package eventreg.model;

/** A validated, normalised request to register one student for one event. */
public record NewRegistration(String studentReg, String studentName, String email, int eventId) { }
