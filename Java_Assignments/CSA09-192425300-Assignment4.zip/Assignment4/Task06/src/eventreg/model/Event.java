package eventreg.model;

/** A cultural event students can register for. toString() is what a JComboBox displays. */
public record Event(int id, String name) {
    @Override public String toString() { return name; }
}
