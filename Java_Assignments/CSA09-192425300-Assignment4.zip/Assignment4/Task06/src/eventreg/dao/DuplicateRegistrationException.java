package eventreg.dao;

/** The student is already registered for that event (UNIQUE (student_reg, event_id) violated). */
public class DuplicateRegistrationException extends Exception {
    private static final long serialVersionUID = 1L;
    public DuplicateRegistrationException(String message) { super(message); }
}
