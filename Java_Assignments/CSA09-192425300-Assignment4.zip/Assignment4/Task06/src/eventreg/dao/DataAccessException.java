package eventreg.dao;

/** Any storage failure (connection lost, SQL error). The cause is kept for the log, never shown raw to the user. */
public class DataAccessException extends Exception {
    private static final long serialVersionUID = 1L;
    public DataAccessException(String message, Throwable cause) { super(message, cause); }
}
