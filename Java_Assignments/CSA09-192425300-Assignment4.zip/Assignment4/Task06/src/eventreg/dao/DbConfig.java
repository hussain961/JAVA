package eventreg.dao;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;

/**
 * Connection settings. They live in db.properties (NOT in the source code, and not in Git):
 *   db.url=jdbc:mysql://localhost:3306/eventreg
 *   db.user=...
 *   db.password=...
 * The password can instead come from the environment variable EVENTREG_DB_PASSWORD.
 * Use -Ddb.config=path/to/file to read a different file.
 */
public record DbConfig(String url, String user, String password) {

    public static DbConfig load() throws IOException {
        Path path = Path.of(System.getProperty("db.config", "db.properties"));
        Properties p = new Properties();
        try (InputStream in = Files.newInputStream(path)) {
            p.load(in);
        }
        String env = System.getenv("EVENTREG_DB_PASSWORD");
        String password = env != null ? env : p.getProperty("db.password", "");
        String url = p.getProperty("db.url");
        if (url == null || url.isBlank()) throw new IOException("db.url is missing in " + path);
        return new DbConfig(url.trim(), p.getProperty("db.user", "root").trim(), password);
    }
}
