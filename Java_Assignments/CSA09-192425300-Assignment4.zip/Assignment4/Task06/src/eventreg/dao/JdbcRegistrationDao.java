package eventreg.dao;

import eventreg.model.Event;
import eventreg.model.NewRegistration;
import eventreg.model.Page;
import eventreg.model.Registration;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 * JDBC implementation for MySQL.
 *  - Every value goes through a PreparedStatement placeholder (no SQL injection).
 *  - Every Connection / PreparedStatement / ResultSet is closed by try-with-resources.
 *  - Duplicates are decided by the DATABASE (UNIQUE key uq_student_event), not only by a
 *    SELECT-then-INSERT check, which two users could both pass at the same moment.
 *  - Paging uses LIMIT ? OFFSET ? so only one page crosses the network.
 * Needs the MySQL Connector/J jar on the class path (JDBC 4 drivers register themselves).
 */
public class JdbcRegistrationDao implements RegistrationDao {

    private static final int MYSQL_DUPLICATE_ENTRY = 1062;

    private static final String SELECT_ROWS =
            "SELECT r.id, r.student_reg, r.student_name, r.email, e.id AS event_id, e.name AS event_name, "
          + "r.registered_at FROM registrations r JOIN events e ON e.id = r.event_id";

    private final DbConfig config;

    public JdbcRegistrationDao(DbConfig config) { this.config = config; }

    private Connection open() throws SQLException {
        return DriverManager.getConnection(config.url(), config.user(), config.password());
    }

    @Override
    public List<Event> listEvents() throws DataAccessException {
        String sql = "SELECT id, name FROM events ORDER BY name";
        try (Connection c = open(); PreparedStatement ps = c.prepareStatement(sql); ResultSet rs = ps.executeQuery()) {
            List<Event> list = new ArrayList<>();
            while (rs.next()) list.add(new Event(rs.getInt("id"), rs.getString("name")));
            return list;
        } catch (SQLException e) {
            throw new DataAccessException("Could not load the event list", e);
        }
    }

    @Override
    public boolean exists(String studentReg, int eventId) throws DataAccessException {
        String sql = "SELECT 1 FROM registrations WHERE student_reg = ? AND event_id = ? LIMIT 1";
        try (Connection c = open(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, studentReg);
            ps.setInt(2, eventId);
            try (ResultSet rs = ps.executeQuery()) { return rs.next(); }
        } catch (SQLException e) {
            throw new DataAccessException("Could not check for an existing registration", e);
        }
    }

    @Override
    public void insert(NewRegistration r) throws DuplicateRegistrationException, DataAccessException {
        String sql = "INSERT INTO registrations (student_reg, student_name, email, event_id) VALUES (?, ?, ?, ?)";
        try (Connection c = open(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, r.studentReg());
            ps.setString(2, r.studentName());
            ps.setString(3, r.email());
            ps.setInt(4, r.eventId());
            ps.executeUpdate();
        } catch (SQLException e) {
            if (e.getErrorCode() == MYSQL_DUPLICATE_ENTRY) {        // UNIQUE (student_reg, event_id)
                throw new DuplicateRegistrationException(
                        "Student " + r.studentReg() + " is already registered for this event.");
            }
            throw new DataAccessException("Could not save the registration", e);
        }
    }

    @Override
    public Page<Registration> findPage(Integer eventId, int pageIndex, int pageSize) throws DataAccessException {
        String where = eventId == null ? "" : " WHERE r.event_id = ?";
        String countSql = "SELECT COUNT(*) FROM registrations r" + where;
        String rowsSql = SELECT_ROWS + where + " ORDER BY r.id LIMIT ? OFFSET ?";
        try (Connection c = open()) {
            long total;
            try (PreparedStatement ps = c.prepareStatement(countSql)) {
                if (eventId != null) ps.setInt(1, eventId);
                try (ResultSet rs = ps.executeQuery()) { rs.next(); total = rs.getLong(1); }
            }
            List<Registration> rows = new ArrayList<>();
            try (PreparedStatement ps = c.prepareStatement(rowsSql)) {
                int i = 1;
                if (eventId != null) ps.setInt(i++, eventId);
                ps.setInt(i++, pageSize);
                ps.setLong(i, (long) pageIndex * pageSize);
                try (ResultSet rs = ps.executeQuery()) { while (rs.next()) rows.add(map(rs)); }
            }
            return new Page<>(rows, pageIndex, pageSize, total);
        } catch (SQLException e) {
            throw new DataAccessException("Could not load registrations", e);
        }
    }

    @Override
    public List<Registration> findAll(Integer eventId) throws DataAccessException {
        String sql = SELECT_ROWS + (eventId == null ? "" : " WHERE r.event_id = ?") + " ORDER BY r.id";
        try (Connection c = open(); PreparedStatement ps = c.prepareStatement(sql)) {
            if (eventId != null) ps.setInt(1, eventId);
            List<Registration> rows = new ArrayList<>();
            try (ResultSet rs = ps.executeQuery()) { while (rs.next()) rows.add(map(rs)); }
            return rows;
        } catch (SQLException e) {
            throw new DataAccessException("Could not read registrations for export", e);
        }
    }

    private static Registration map(ResultSet rs) throws SQLException {
        return new Registration(rs.getLong("id"), rs.getString("student_reg"), rs.getString("student_name"),
                rs.getString("email"), rs.getInt("event_id"), rs.getString("event_name"),
                rs.getTimestamp("registered_at").toLocalDateTime());
    }
}
