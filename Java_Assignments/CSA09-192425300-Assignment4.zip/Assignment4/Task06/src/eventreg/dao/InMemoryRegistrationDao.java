package eventreg.dao;

import eventreg.model.Event;
import eventreg.model.NewRegistration;
import eventreg.model.Page;
import eventreg.model.Registration;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Random;
import java.util.Set;

/**
 * In-memory stand-in for MySQL: used for --demo mode and for tests that must run without a database.
 * It enforces the same rule as the real UNIQUE key, atomically, and can simulate slow queries
 * (latencyMillis) so that responsiveness of the window can be tested.
 */
public class InMemoryRegistrationDao implements RegistrationDao {

    public static final List<Event> DEFAULT_EVENTS = List.of(
            new Event(1, "Battle of Bands"), new Event(2, "Classical Dance Night"),
            new Event(3, "Cultural Fest Inauguration"), new Event(4, "Hackathon 24h"),
            new Event(5, "Photography Walk"), new Event(6, "Quiz League"));

    private final List<Event> events = new ArrayList<>(DEFAULT_EVENTS);
    private final List<Registration> rows = new ArrayList<>();
    private final Set<String> keys = new HashSet<>();
    private final long latencyMillis;
    private long nextId = 1;

    public InMemoryRegistrationDao(long latencyMillis) { this.latencyMillis = latencyMillis; }

    private void delay() {
        if (latencyMillis <= 0) return;
        try { Thread.sleep(latencyMillis); } catch (InterruptedException e) { Thread.currentThread().interrupt(); }
    }

    /** Fills the store with n unique, realistic-looking registrations (for demos and benchmarks). */
    public synchronized void seed(int n) {
        String[] first = {"Aarav", "Diya", "Karthik", "Meera", "Rohan", "Sneha", "Vikram", "Anjali", "Harini", "Naveen"};
        String[] last = {"Kumar", "Raj", "Iyer", "Nair", "Reddy", "Sharma", "Pillai", "Menon", "Das", "Ghosh"};
        Random rnd = new Random(7);
        int made = 0;
        while (made < n) {
            String reg = String.valueOf(192400000 + rnd.nextInt(90000));
            Event ev = events.get(rnd.nextInt(events.size()));
            if (!keys.add(reg + "|" + ev.id())) continue;
            String name = first[rnd.nextInt(first.length)] + " " + last[rnd.nextInt(last.length)];
            String mail = (name.toLowerCase().replace(' ', '.') + "." + reg.substring(5) + "@saveetha.com");
            rows.add(new Registration(nextId++, reg, name, mail, ev.id(), ev.name(),
                    LocalDateTime.now().minusMinutes(n - made)));
            made++;
        }
    }

    @Override public List<Event> listEvents() {
        delay();
        return new ArrayList<>(events);
    }

    @Override public boolean exists(String studentReg, int eventId) {
        delay();
        synchronized (this) { return keys.contains(studentReg + "|" + eventId); }
    }

    @Override public void insert(NewRegistration r) throws DuplicateRegistrationException, DataAccessException {
        delay();
        synchronized (this) {                                         // check-and-insert is one atomic step
            if (!keys.add(r.studentReg() + "|" + r.eventId()))
                throw new DuplicateRegistrationException(
                        "Student " + r.studentReg() + " is already registered for this event.");
            String eventName = events.stream().filter(e -> e.id() == r.eventId()).map(Event::name).findFirst()
                    .orElseThrow(() -> new DataAccessException("Unknown event id " + r.eventId(), null));
            rows.add(new Registration(nextId++, r.studentReg(), r.studentName(), r.email(),
                    r.eventId(), eventName, LocalDateTime.now()));
        }
    }

    private List<Registration> filtered(Integer eventId) {
        List<Registration> out = new ArrayList<>();
        for (Registration r : rows) if (eventId == null || r.eventId() == eventId) out.add(r);
        return out;
    }

    @Override public Page<Registration> findPage(Integer eventId, int pageIndex, int pageSize) {
        delay();
        synchronized (this) {
            List<Registration> all = filtered(eventId);
            int from = (int) Math.min((long) pageIndex * pageSize, all.size());
            int to = Math.min(from + pageSize, all.size());
            return new Page<>(new ArrayList<>(all.subList(from, to)), pageIndex, pageSize, all.size());
        }
    }

    @Override public List<Registration> findAll(Integer eventId) {
        delay();
        synchronized (this) { return filtered(eventId); }
    }
}
