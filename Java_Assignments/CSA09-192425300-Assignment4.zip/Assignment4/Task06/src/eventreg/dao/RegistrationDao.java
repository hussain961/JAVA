package eventreg.dao;

import eventreg.model.Event;
import eventreg.model.NewRegistration;
import eventreg.model.Page;
import eventreg.model.Registration;
import java.util.List;

/**
 * DATA-ACCESS LAYER contract. The service layer depends only on this interface, so the
 * application can run on MySQL (JdbcRegistrationDao) or on memory (InMemoryRegistrationDao,
 * used for the demo and for tests that need no database).
 */
public interface RegistrationDao {
    List<Event> listEvents() throws DataAccessException;

    boolean exists(String studentReg, int eventId) throws DataAccessException;

    /** Must be atomic: two simultaneous inserts of the same pair - exactly one succeeds. */
    void insert(NewRegistration r) throws DuplicateRegistrationException, DataAccessException;

    /** @param eventId null = all events;  @param pageIndex 0-based */
    Page<Registration> findPage(Integer eventId, int pageIndex, int pageSize) throws DataAccessException;

    /** Everything (for CSV export). */
    List<Registration> findAll(Integer eventId) throws DataAccessException;
}
