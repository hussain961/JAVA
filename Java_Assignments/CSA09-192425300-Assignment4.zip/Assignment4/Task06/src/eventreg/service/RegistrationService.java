package eventreg.service;

import eventreg.dao.DataAccessException;
import eventreg.dao.DuplicateRegistrationException;
import eventreg.dao.RegistrationDao;
import eventreg.model.Event;
import eventreg.model.NewRegistration;
import eventreg.model.Page;
import eventreg.model.Registration;
import java.io.IOException;
import java.io.Writer;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.regex.Pattern;

/**
 * SERVICE (business-rule) LAYER: validation, normalisation, duplicate rule, CSV export.
 * No Swing and no SQL in here - it can be tested with the in-memory DAO.
 */
public class RegistrationService {

    private static final Pattern REG_NO = Pattern.compile("[0-9]{9,12}");
    private static final Pattern NAME = Pattern.compile("[A-Za-z][A-Za-z .'-]{1,59}");
    private static final Pattern EMAIL = Pattern.compile("[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}");
    private static final DateTimeFormatter STAMP = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

    private final RegistrationDao dao;

    public RegistrationService(RegistrationDao dao) { this.dao = dao; }

    public List<Event> events() throws DataAccessException { return dao.listEvents(); }

    /** Fast, no I/O: safe on the event-dispatch thread. Reports all problems at once. */
    public NewRegistration validate(String regNo, String name, String email, Event event) throws ValidationException {
        List<String> problems = new ArrayList<>();
        String reg = regNo == null ? "" : regNo.trim();
        String nm = name == null ? "" : name.trim().replaceAll("\\s+", " ");
        String mail = email == null ? "" : email.trim().toLowerCase(Locale.ROOT);

        if (reg.isEmpty()) problems.add("Register number is required.");
        else if (!REG_NO.matcher(reg).matches()) problems.add("Register number must be 9 to 12 digits.");

        if (nm.isEmpty()) problems.add("Name is required.");
        else if (!NAME.matcher(nm).matches()) problems.add("Name may contain only letters, spaces, . ' and - (2 to 60 characters).");

        if (mail.isEmpty()) problems.add("Email is required.");
        else if (mail.length() > 100 || !EMAIL.matcher(mail).matches()) problems.add("Email address is not valid.");

        if (event == null || event.id() < 0) problems.add("Select an event.");

        if (!problems.isEmpty()) throw new ValidationException(problems);
        return new NewRegistration(reg, nm, mail, event.id());
    }

    /** Slow (I/O): call from a background thread. */
    public void register(NewRegistration r) throws DuplicateRegistrationException, DataAccessException {
        if (dao.exists(r.studentReg(), r.eventId()))               // friendly early answer ...
            throw new DuplicateRegistrationException(
                    "Student " + r.studentReg() + " is already registered for this event.");
        dao.insert(r);                                              // ... the UNIQUE key is the real guard
    }

    public Page<Registration> page(Integer eventId, int pageIndex, int pageSize) throws DataAccessException {
        return dao.findPage(eventId, pageIndex, pageSize);
    }

    /** Writes the CSV and returns the number of data rows written. */
    public int exportCsv(Integer eventId, Writer out) throws DataAccessException, IOException {
        List<Registration> all = dao.findAll(eventId);
        out.write("id,register_no,name,email,event,registered_at\r\n");
        for (Registration r : all) {
            out.write(r.id() + "," + csv(r.studentReg()) + "," + csv(r.studentName()) + "," + csv(r.email())
                    + "," + csv(r.eventName()) + "," + r.registeredAt().format(STAMP) + "\r\n");
        }
        out.flush();
        return all.size();
    }

    static String csv(String s) {
        if (s.indexOf(',') >= 0 || s.indexOf('"') >= 0 || s.indexOf('\n') >= 0 || s.indexOf('\r') >= 0)
            return "\"" + s.replace("\"", "\"\"") + "\"";
        return s;
    }
}
