package eventreg.service;

import java.util.List;

/** Carries EVERY problem found in a form, so the user can fix them all in one go. */
public class ValidationException extends Exception {
    private static final long serialVersionUID = 1L;
    private final List<String> problems;

    public ValidationException(List<String> problems) {
        super(String.join("; ", problems));
        this.problems = List.copyOf(problems);
    }

    public List<String> problems() { return problems; }
}
