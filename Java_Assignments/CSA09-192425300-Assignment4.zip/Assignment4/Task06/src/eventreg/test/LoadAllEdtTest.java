package eventreg.test;

import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

/**
 * Task 6 alternative: what does "load everything into the JTable at once" do to the window?
 * Rows are added to a JTable that is ON SCREEN, on the event-dispatch thread (where a SwingWorker's
 * done() / process() must put them), and the time the EDT is busy is measured.
 * Database/network time is NOT included - it only makes the "load all" case worse.
 * Needs a display:  xvfb-run java -cp out eventreg.test.LoadAllEdtTest
 */
public class LoadAllEdtTest {
    static Object[] row(int i) {
        return new Object[]{Long.valueOf(i), "1924" + String.format("%05d", i % 100000), new String("Student Name " + i),
                new String("student." + i + "@saveetha.com"), new String("Event " + (i % 6)), "2026-11-14 10:00"};
    }

    static long timeOnEdt(Runnable r) throws Exception {
        long[] t = new long[1];
        EventQueue.invokeAndWait(() -> { long s = System.nanoTime(); r.run(); t[0] = (System.nanoTime() - s) / 1_000_000; });
        return t[0];
    }

    public static void main(String[] args) throws Exception {
        DefaultTableModel model = new DefaultTableModel(new String[]{"ID", "Reg", "Name", "Email", "Event", "At"}, 0);
        JFrame[] f = new JFrame[1];
        EventQueue.invokeAndWait(() -> { f[0] = new JFrame("t"); f[0].add(new JScrollPane(new JTable(model))); f[0].setSize(800, 400); f[0].setVisible(true); });
        Thread.sleep(500);
        System.out.printf("%10s | %-34s | %-34s | %s%n", "rows", "add row by row into visible JTable", "one bulk setDataVector call", "one page of 25");
        for (int n : new int[]{1_000, 10_000, 100_000}) {
            EventQueue.invokeAndWait(() -> model.setRowCount(0));
            long perRow = timeOnEdt(() -> { for (int i = 0; i < n; i++) model.addRow(row(i)); });
            EventQueue.invokeAndWait(() -> model.setRowCount(0));
            java.util.Vector<java.util.Vector<Object>> data = new java.util.Vector<>();
            for (int i = 0; i < n; i++) { java.util.Vector<Object> v = new java.util.Vector<>(); for (Object o : row(i)) v.add(o); data.add(v); }
            long bulk = timeOnEdt(() -> model.setDataVector(data, new java.util.Vector<>(java.util.List.of("ID", "Reg", "Name", "Email", "Event", "At"))));
            EventQueue.invokeAndWait(() -> model.setRowCount(0));
            long page = timeOnEdt(() -> { for (int i = 0; i < 25; i++) model.addRow(row(i)); });
            System.out.printf("%10d | EDT busy %-24s | EDT busy %-24s | EDT busy %d ms%n", n, perRow + " ms", bulk + " ms", page);
        }
        EventQueue.invokeAndWait(() -> f[0].dispose());
    }
}
