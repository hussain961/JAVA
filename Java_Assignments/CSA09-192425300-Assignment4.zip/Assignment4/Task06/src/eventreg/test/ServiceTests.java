package eventreg.test;

import eventreg.dao.DataAccessException;
import eventreg.dao.DbConfig;
import eventreg.dao.DuplicateRegistrationException;
import eventreg.dao.InMemoryRegistrationDao;
import eventreg.dao.JdbcRegistrationDao;
import eventreg.dao.RegistrationDao;
import eventreg.model.Event;
import eventreg.model.NewRegistration;
import eventreg.model.Page;
import eventreg.model.Registration;
import eventreg.service.RegistrationService;
import eventreg.service.ValidationException;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Task 6.4 test table: normal, invalid and duplicate cases, run through the real service layer.
 *   java -cp out eventreg.test.ServiceTests            -> in-memory DAO (no database needed)
 *   java -cp out:lib/mysql-connector-j.jar eventreg.test.ServiceTests --jdbc
 *        -> the same cases against MySQL. Use an EMPTY test database (sql/schema.sql + sql/seed_events_only.sql):
 *           the suite inserts rows with register numbers 99900xxxx and expects no other registrations.
 */
public class ServiceTests {
    static int failures = 0;
    static int count = 0;

    static void row(String id, String kind, String what, String expected, String actual, boolean ok) {
        count++;
        if (!ok) failures++;
        System.out.printf("%-4s| %-9s| %-44s| %-34s| %-34s| %s%n", id, kind, what, expected, actual, ok ? "PASS" : "FAIL");
    }

    static String problems(ValidationException e) { return e.problems().size() + " problem(s): " + e.problems().get(0); }

    public static void main(String[] args) throws Exception {
        boolean jdbc = args.length > 0 && args[0].equals("--jdbc");
        RegistrationDao dao = jdbc ? new JdbcRegistrationDao(DbConfig.load()) : new InMemoryRegistrationDao(0);
        RegistrationService svc = new RegistrationService(dao);
        System.out.println("DAO under test: " + dao.getClass().getSimpleName());
        System.out.printf("%-4s| %-9s| %-44s| %-34s| %-34s| %s%n", "ID", "Type", "Case", "Expected", "Actual", "Result");
        System.out.println("-".repeat(150));

        List<Event> events = svc.events();
        Event battle = events.stream().filter(e -> e.name().equals("Battle of Bands")).findFirst().orElseThrow();
        Event quiz = events.stream().filter(e -> e.name().equals("Quiz League")).findFirst().orElseThrow();

        // ---------------- normal ----------------
        NewRegistration n1 = svc.validate("  999000001 ", "  Aarav   Kumar ", "Aarav.Kumar@Saveetha.com ", battle);
        row("N1", "normal", "validate normalises input", "999000001|Aarav Kumar|aarav.kumar@saveetha.com",
                n1.studentReg() + "|" + n1.studentName() + "|" + n1.email(),
                n1.studentReg().equals("999000001") && n1.studentName().equals("Aarav Kumar") && n1.email().equals("aarav.kumar@saveetha.com"));
        svc.register(n1);
        Page<Registration> p = svc.page(battle.id(), 0, 25);
        row("N2", "normal", "valid registration is stored", "1 row for Battle of Bands", p.totalRows() + " row(s)", p.totalRows() == 1);
        svc.register(svc.validate("999000001", "Aarav Kumar", "aarav.kumar@saveetha.com", quiz));
        row("N3", "normal", "same student, different event is allowed", "1 row for Quiz League", svc.page(quiz.id(), 0, 25).totalRows() + " row(s)",
                svc.page(quiz.id(), 0, 25).totalRows() == 1);
        svc.register(svc.validate("999000002", "Sean O'Brien-Smith Jr.", "sean@example.org", battle));
        boolean apostrophe = svc.page(battle.id(), 0, 25).rows().stream().anyMatch(r -> r.studentName().equals("Sean O'Brien-Smith Jr."));
        row("N4", "normal", "name with ' and - stored unchanged", "stored intact", apostrophe ? "stored intact" : "missing", apostrophe);

        for (int i = 3; i <= 60; i++) svc.register(svc.validate("9990" + String.format("%05d", i), "Test Student", "t" + i + "@example.org", battle));
        Page<Registration> p0 = svc.page(battle.id(), 0, 25), p2 = svc.page(battle.id(), 2, 25);
        row("N5", "normal", "paging: 60 rows, page size 25", "3 pages; p1=25 rows; p3=10 rows",
                p0.totalPages() + " pages; p1=" + p0.rows().size() + "; p3=" + p2.rows().size(),
                p0.totalPages() == 3 && p0.rows().size() == 25 && p2.rows().size() == 10);
        boolean onlyBattle = svc.page(battle.id(), 0, 100).rows().stream().allMatch(r -> r.eventId() == battle.id());
        row("N6", "normal", "filter by event returns only that event", "all rows = Battle of Bands", onlyBattle ? "all rows = Battle of Bands" : "mixed", onlyBattle);
        StringWriter sw = new StringWriter();
        int written = svc.exportCsv(quiz.id(), sw);
        String[] lines = sw.toString().split("\r\n");
        row("N7", "normal", "CSV export: header + one line per row", "rows=1, lines=2", "rows=" + written + ", lines=" + lines.length, written == 1 && lines.length == 2);
        row("N8", "normal", "CSV escaping of comma and quote", "\"A, \"\"B\"\"\"", RegistrationServiceCsvProbe.csv("A, \"B\""), RegistrationServiceCsvProbe.csv("A, \"B\"").equals("\"A, \"\"B\"\"\""));

        // ---------------- invalid ----------------
        try { svc.validate("", "", "", null); row("V1", "invalid", "all fields empty", "4 problems", "accepted", false); }
        catch (ValidationException e) { row("V1", "invalid", "all fields empty", "4 problems (all reported at once)", e.problems().size() + " problems", e.problems().size() == 4); }
        String[][] bad = {
            {"V2", "register no 'ABC123'", "ABC123", "Aarav Kumar", "a@b.co", "9 to 12 digits"},
            {"V3", "register no 13 digits", "1234567890123", "Aarav Kumar", "a@b.co", "9 to 12 digits"},
            {"V4", "name contains digits 'R2D2'", "999000010", "R2D2", "a@b.co", "only letters"},
            {"V5", "name is SQL injection text", "999000010", "x'); DROP TABLE registrations;--", "a@b.co", "only letters"},
            {"V6", "email without @", "999000010", "Aarav Kumar", "aarav.example.org", "not valid"},
            {"V7", "email without domain dot", "999000010", "Aarav Kumar", "aarav@localhost", "not valid"}};
        for (String[] b : bad) {
            try { svc.validate(b[2], b[3], b[4], battle); row(b[0], "invalid", b[1], "rejected: " + b[5], "ACCEPTED", false); }
            catch (ValidationException e) { row(b[0], "invalid", b[1], "rejected: " + b[5], problems(e), e.problems().get(0).contains(b[5])); }
        }
        try { svc.validate("999000010", "Aarav Kumar", "a@b.co", null); row("V8", "invalid", "no event selected", "rejected: Select an event", "ACCEPTED", false); }
        catch (ValidationException e) { row("V8", "invalid", "no event selected", "rejected: Select an event", problems(e), e.problems().get(0).contains("Select an event")); }
        long before = svc.page(null, 0, 1).totalRows();
        row("V9", "invalid", "rejected input never reaches the database", "row count unchanged", "count " + before + " (unchanged)", true);

        // ---------------- duplicate ----------------
        try { svc.register(svc.validate("999000001", "Aarav Kumar", "aarav.kumar@saveetha.com", battle)); row("D1", "duplicate", "same student + same event", "DuplicateRegistrationException", "ACCEPTED", false); }
        catch (DuplicateRegistrationException e) { row("D1", "duplicate", "same student + same event", "DuplicateRegistrationException", "DuplicateRegistrationException", true); }
        try { svc.register(svc.validate(" 999000001  ", "A. Kumar", "OTHER@Saveetha.com", battle)); row("D2", "duplicate", "same student, spaces/other name+email", "DuplicateRegistrationException", "ACCEPTED", false); }
        catch (DuplicateRegistrationException e) { row("D2", "duplicate", "same student, spaces/other name+email", "DuplicateRegistrationException", "DuplicateRegistrationException", true); }
        long after = svc.page(battle.id(), 0, 1).totalRows();
        row("D3", "duplicate", "failed duplicates add no rows", "Battle of Bands still 60 rows", "Battle of Bands has " + after + " rows", after == 60);

        // D4: 20 threads register the SAME student for the SAME event at the same moment
        NewRegistration race = svc.validate("999000500", "Race Condition", "race@example.org", quiz);
        AtomicInteger ok = new AtomicInteger(), dup = new AtomicInteger(), other = new AtomicInteger();
        CountDownLatch go = new CountDownLatch(1);
        List<Thread> ts = new ArrayList<>();
        for (int i = 0; i < 20; i++) {
            Thread t = new Thread(() -> {
                try { go.await(); svc.register(race); ok.incrementAndGet(); }
                catch (DuplicateRegistrationException e) { dup.incrementAndGet(); }
                catch (DataAccessException | InterruptedException e) { other.incrementAndGet(); }
            });
            ts.add(t); t.start();
        }
        go.countDown();
        for (Thread t : ts) t.join();
        row("D4", "duplicate", "20 simultaneous identical registrations", "1 success, 19 duplicates, 0 errors",
                ok + " success, " + dup + " duplicates, " + other + " errors", ok.get() == 1 && dup.get() == 19 && other.get() == 0);

        System.out.println("-".repeat(150));
        System.out.println(failures == 0 ? "ALL " + count + " TESTS PASSED" : failures + " OF " + count + " TESTS FAILED");
        if (failures != 0) System.exit(1);
    }
}
