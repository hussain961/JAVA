package eventreg.test;

import eventreg.dao.InMemoryRegistrationDao;
import eventreg.service.RegistrationService;
import eventreg.ui.MainFrame;
import java.awt.EventQueue;

/**
 * Task 6 key requirement: the window must not freeze while the database works.
 * Measures how long the event-dispatch thread is unable to answer, while a 1.5 s "database query" runs:
 *   A) through MainFrame.reload()  (SwingWorker - the real code)
 *   B) the same query run directly on the EDT  (what a beginner's listener would do)
 * Needs a display:  xvfb-run java -cp out eventreg.test.ResponsivenessTest
 */
public class ResponsivenessTest {

    static long maxEdtDelay(long millis) throws Exception {
        long max = 0, end = System.currentTimeMillis() + millis;
        while (System.currentTimeMillis() < end) {
            long sent = System.nanoTime();
            EventQueue.invokeAndWait(() -> { });                 // round trip to the EDT
            max = Math.max(max, (System.nanoTime() - sent) / 1_000_000);
            Thread.sleep(20);
        }
        return max;
    }

    public static void main(String[] args) throws Exception {
        InMemoryRegistrationDao dao = new InMemoryRegistrationDao(1500);   // each DAO call takes 1.5 s
        dao.seed(1000);
        RegistrationService svc = new RegistrationService(dao);
        MainFrame[] f = new MainFrame[1];
        EventQueue.invokeAndWait(() -> { f[0] = new MainFrame(svc); f[0].setVisible(true); });
        while (f[0].isLoading()) Thread.sleep(100);                       // initial load (2 DAO calls = 3 s)
        Thread.sleep(300);

        EventQueue.invokeAndWait(() -> f[0].reload());                    // A
        long a = maxEdtDelay(1700);
        while (f[0].isLoading()) Thread.sleep(50);

        EventQueue.invokeLater(() -> {                                    // B: blocking call ON the EDT
            try { svc.page(null, 0, MainFrame.PAGE_SIZE); } catch (Exception e) { e.printStackTrace(); }
        });
        Thread.sleep(50);
        long b = maxEdtDelay(300);

        System.out.println("Simulated database query time : 1500 ms");
        System.out.println("A) SwingWorker (MainFrame.reload)  : longest EDT stall = " + a + " ms   -> " + (a < 100 ? "RESPONSIVE" : "FROZEN"));
        System.out.println("B) query run directly on the EDT   : longest EDT stall = " + b + " ms   -> " + (b < 100 ? "RESPONSIVE" : "FROZEN"));
        EventQueue.invokeAndWait(() -> f[0].dispose());
        System.exit(a < 100 && b > 1000 ? 0 : 1);
    }
}
