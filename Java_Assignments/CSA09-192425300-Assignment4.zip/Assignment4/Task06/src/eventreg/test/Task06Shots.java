package eventreg.test;

import eventreg.dao.InMemoryRegistrationDao;
import eventreg.service.RegistrationService;
import eventreg.ui.MainFrame;
import eventreg.ui.RegistrationDialog;
import java.awt.EventQueue;
import java.awt.Rectangle;
import java.awt.Robot;
import java.awt.image.BufferedImage;
import java.io.File;
import java.nio.file.Files;
import javax.imageio.ImageIO;
import javax.swing.JMenu;

/**
 * Screenshot driver for Task 6 (demo data, no database). Needs a display (xvfb-run on a server).
 * Usage: java -cp out eventreg.test.Task06Shots <output-folder>
 */
public class Task06Shots {
    static File out;
    static MainFrame f;
    static RegistrationDialog dlg;

    static void ui(Runnable r) throws Exception { EventQueue.invokeAndWait(r); }

    static void waitIdle() throws Exception {
        Thread.sleep(300);
        while (f.isLoading()) Thread.sleep(50);
        Thread.sleep(300);
    }

    static void shot(String name) throws Exception {
        Thread.sleep(300);
        Rectangle r = f.getBounds();
        if (dlg != null && dlg.isShowing()) r = r.union(dlg.getBounds());
        BufferedImage img = new Robot().createScreenCapture(r);
        ImageIO.write(img, "png", new File(out, name));
        System.out.println("saved " + name + "   status: " + f.statusText());
    }

    static void waitDialogClosed() throws Exception {
        for (int i = 0; i < 60 && dlg.isShowing(); i++) Thread.sleep(100);
    }

    public static void main(String[] args) throws Exception {
        out = new File(args[0]);
        out.mkdirs();
        InMemoryRegistrationDao dao = new InMemoryRegistrationDao(400);
        dao.seed(1234);
        RegistrationService svc = new RegistrationService(dao);

        ui(() -> { f = new MainFrame(svc); f.setLocation(0, 0); f.setVisible(true); });
        waitIdle();
        shot("task06_1_main_page1.png");
        System.out.println("rows on screen: " + f.table().getRowCount() + " of " + f.totalRows());

        ui(() -> f.selectEvent("Hackathon 24h"));
        waitIdle();
        shot("task06_2_filtered_by_event.png");
        ui(() -> f.selectEvent("All events"));
        waitIdle();

        ui(() -> { JMenu m = f.getJMenuBar().getMenu(0); m.doClick(0); });
        shot("task06_3_menu_open.png");
        ui(() -> { JMenu m = f.getJMenuBar().getMenu(0); m.setSelected(false); m.getPopupMenu().setVisible(false); });

        // --- invalid input: all problems shown at once, nothing saved ---
        ui(() -> dlg = f.newRegistrationDialog());
        EventQueue.invokeLater(() -> dlg.setVisible(true));
        Thread.sleep(500);
        ui(() -> { dlg.fill("ABC", "R2D2", "not-an-email", "-- Select event --"); dlg.submit(); });
        shot("task06_4_dialog_invalid.png");
        System.out.println("dialog message: " + dlg.messageText());

        // --- valid registration ---
        long totalBefore = f.totalRows();
        ui(() -> { dlg.fill("192425301", "Sample Student", "sample.student@saveetha.com", "Hackathon 24h"); dlg.submit(); });
        Thread.sleep(250);
        shot("task06_5_dialog_saving.png");
        waitDialogClosed();
        waitIdle();
        shot("task06_6_saved_main_refreshed.png");
        System.out.println("total rows before=" + totalBefore + " after=" + f.totalRows());

        // --- duplicate ---
        ui(() -> dlg = f.newRegistrationDialog());
        EventQueue.invokeLater(() -> dlg.setVisible(true));
        Thread.sleep(500);
        ui(() -> { dlg.fill(" 192425301 ", "Sample Student", "sample.student@saveetha.com", "Hackathon 24h"); dlg.submit(); });
        for (int i = 0; i < 40 && dlg.isSaving(); i++) Thread.sleep(100);
        Thread.sleep(300);
        shot("task06_7_duplicate_rejected.png");
        System.out.println("dialog message: " + dlg.messageText());
        ui(() -> dlg.dispose());
        Thread.sleep(300);
        dlg = null;

        // --- CSV export ---
        File csv = new File(out, "registrations_export.csv");
        ui(() -> f.exportTo(csv));
        for (int i = 0; i < 40 && !f.statusText().startsWith("Exported"); i++) Thread.sleep(100);
        shot("task06_8_exported.png");
        System.out.println("CSV lines: " + Files.readAllLines(csv.toPath()).size() + " (header + " + (Files.readAllLines(csv.toPath()).size() - 1) + " rows)");
        ui(() -> f.dispose());
    }
}
