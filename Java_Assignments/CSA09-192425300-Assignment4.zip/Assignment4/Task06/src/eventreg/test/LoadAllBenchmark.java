package eventreg.test;

import javax.swing.table.DefaultTableModel;

/**
 * Alternative concept (Task 6): load EVERY registration into the table at once, versus one page.
 * Measures the client-side part only: time to build the table model and the heap it holds.
 * (The database/network part depends on your MySQL server and is analysed in the report, not measured here.)
 */
public class LoadAllBenchmark {
    static final String[] COLS = {"ID", "Register No", "Name", "Email", "Event", "Registered at"};

    static long usedHeap() {
        for (int i = 0; i < 4; i++) { System.gc(); try { Thread.sleep(50); } catch (InterruptedException ignored) { } }
        Runtime r = Runtime.getRuntime();
        return r.totalMemory() - r.freeMemory();
    }

    static DefaultTableModel build(int n) {
        DefaultTableModel m = new DefaultTableModel(COLS, 0);
        for (int i = 0; i < n; i++) {
            m.addRow(new Object[]{Long.valueOf(i), "1924" + String.format("%05d", i % 100000),
                    new String("Student Name " + i), new String("student." + i + "@saveetha.com"),
                    new String("Event " + (i % 6)), new String("2026-11-14 10:" + String.format("%02d", i % 60))});
        }
        return m;
    }

    public static void main(String[] args) {
        int[] ns = {1_000, 10_000, 100_000, 500_000};
        System.out.printf("%10s | %-24s | %-24s | %s%n", "rows", "load ALL: time / heap", "one page (25): time / heap", "heap ratio");
        DefaultTableModel warm = build(20_000); warm.setRowCount(0);
        for (int n : ns) {
            long h0 = usedHeap();
            long t0 = System.nanoTime();
            DefaultTableModel all = build(n);
            double msAll = (System.nanoTime() - t0) / 1e6;
            long hAll = usedHeap() - h0;
            all.getRowCount();                                    // keep it reachable until measured

            long h1 = usedHeap();
            long t1 = System.nanoTime();
            DefaultTableModel page = build(25);
            double msPage = (System.nanoTime() - t1) / 1e6;
            long hPage = Math.max(1, usedHeap() - h1);
            page.getRowCount();
            System.out.printf("%10d | %8.1f ms / %7d KB | %8.3f ms / %6d KB | %.0fx%n", n, msAll, hAll / 1024, msPage, hPage / 1024, hAll / (double) hPage);
        }
    }
}
