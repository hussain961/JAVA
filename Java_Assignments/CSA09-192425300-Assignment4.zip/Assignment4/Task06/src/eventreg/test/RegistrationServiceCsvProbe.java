package eventreg.test;

/** Tiny bridge so the test can call the package-private CSV escaper through the public export path. */
final class RegistrationServiceCsvProbe {
    private RegistrationServiceCsvProbe() { }

    static String csv(String s) {
        try {
            java.lang.reflect.Method m = eventreg.service.RegistrationService.class.getDeclaredMethod("csv", String.class);
            m.setAccessible(true);
            return (String) m.invoke(null, s);
        } catch (ReflectiveOperationException e) {
            throw new IllegalStateException(e);
        }
    }
}
