package eventreg.app;

import eventreg.dao.DbConfig;
import eventreg.dao.InMemoryRegistrationDao;
import eventreg.dao.JdbcRegistrationDao;
import eventreg.dao.RegistrationDao;
import eventreg.service.RegistrationService;
import eventreg.ui.MainFrame;
import java.io.IOException;
import java.util.Arrays;
import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;

/**
 * Entry point.
 *   java -cp out:lib/mysql-connector-j.jar eventreg.app.Main            -> MySQL (reads db.properties)
 *   java -cp out eventreg.app.Main --demo                               -> in-memory demo data, no database
 */
public class Main {
    public static void main(String[] args) {
        RegistrationDao dao;
        if (Arrays.asList(args).contains("--demo")) {
            InMemoryRegistrationDao demo = new InMemoryRegistrationDao(400);   // 0.4 s "network" delay
            demo.seed(1234);
            dao = demo;
        } else {
            try {
                dao = new JdbcRegistrationDao(DbConfig.load());
            } catch (IOException e) {
                String msg = "Could not read the database settings:\n" + e.getMessage()
                        + "\n\nCopy db.properties.example to db.properties and edit it,\nor start with --demo.";
                System.err.println(msg);
                JOptionPane.showMessageDialog(null, msg, "Configuration problem", JOptionPane.ERROR_MESSAGE);
                return;
            }
        }
        final RegistrationService service = new RegistrationService(dao);
        SwingUtilities.invokeLater(() -> new MainFrame(service).setVisible(true));
    }
}
