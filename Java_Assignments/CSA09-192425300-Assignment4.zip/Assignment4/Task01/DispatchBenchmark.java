import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.HashMap;
import java.util.Map;

/**
 * Alternative concept (Task 1): one shared listener with an if-else chain on the
 * action command versus one listener object per button.
 * Measures the cost of choosing the handler for the LAST of k buttons (worst case).
 */
public class DispatchBenchmark {

    static long sink;                                  // stops the JIT removing the work

    static void chain(String cmd, String[] names) {   // up to k string comparisons
        for (int i = 0; i < names.length; i++) {
            if (names[i].equals(cmd)) { sink += i; return; }
        }
    }

    public static void main(String[] args) {
        int[] ks = {3, 10, 50, 200, 1000};
        int reps = 2_000_000;
        System.out.printf("%6s | %-34s | %-30s | %s%n", "k", "if-else chain, last button (ns)",
                "own listener object (ns)", "space for k listeners");
        for (int k : ks) {
            String[] names = new String[k];
            ActionListener[] listeners = new ActionListener[k];
            for (int i = 0; i < k; i++) {
                final int id = i;
                names[i] = "Button-" + i;
                listeners[i] = e -> sink += id;
            }
            String last = new String("Button-" + (k - 1));   // not interned: forces a real equals()
            ActionEvent ev = new ActionEvent(new Object(), ActionEvent.ACTION_PERFORMED, last);

            for (int w = 0; w < 3; w++) {                    // warm-up
                for (int i = 0; i < reps; i++) chain(last, names);
                for (int i = 0; i < reps; i++) listeners[k - 1].actionPerformed(ev);
            }
            long t0 = System.nanoTime();
            for (int i = 0; i < reps; i++) chain(last, names);
            long t1 = System.nanoTime();
            for (int i = 0; i < reps; i++) listeners[k - 1].actionPerformed(ev);
            long t2 = System.nanoTime();
            System.out.printf("%6d | %34.2f | %30.2f | O(k) = %d objects%n",
                    k, (t1 - t0) / (double) reps, (t2 - t1) / (double) reps, k);
        }
        System.out.println("(sink=" + sink + ")");
    }
}
