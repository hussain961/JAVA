import java.math.BigDecimal;

/** Console tests for FeeService - runs with no window and no database. */
public class FeeServiceTest {
    static int failures = 0;

    static void expectError(String id, String reg, String amt, String expectedPart) {
        try {
            new FeeService(new InMemoryPaymentRepository(0)).pay(reg, amt);
            report(id, "rejected with \"" + expectedPart + "\"", "ACCEPTED", false);
        } catch (FeeService.ValidationException e) {
            report(id, "rejected with \"" + expectedPart + "\"", e.getMessage(),
                    e.getMessage().contains(expectedPart));
        } catch (Exception e) {
            report(id, "ValidationException", e.toString(), false);
        }
    }

    static void report(String id, String expected, String actual, boolean ok) {
        if (!ok) failures++;
        System.out.printf("%-4s | %-45s | %-52s | %s%n", id, expected, actual, ok ? "PASS" : "FAIL");
    }

    public static void main(String[] args) throws Exception {
        System.out.printf("%-4s | %-45s | %-52s | %s%n", "ID", "Expected", "Actual", "Result");
        System.out.println("-".repeat(115));

        InMemoryPaymentRepository repo = new InMemoryPaymentRepository(0);
        FeeService svc = new FeeService(repo);

        FeeService.Receipt r = svc.pay("192425301", "1500.50");
        report("T1", "valid payment saved, receipt #1", "receipt #" + r.receiptNo() + ", rows=" + repo.rows().size(),
                r.receiptNo() == 1 && repo.rows().size() == 1);
        FeeService.Receipt r2 = svc.pay("192425301", "10");
        report("T2", "second receipt number is 2", "receipt #" + r2.receiptNo(), r2.receiptNo() == 2);

        expectError("T3", "", "100", "Register number is required");
        expectError("T4", "ABC123", "100", "9 to 12 digits");
        expectError("T5", "192425301", "", "Amount is required");
        expectError("T6", "192425301", "abc", "number with at most 2 decimals");
        expectError("T7", "192425301", "NaN", "number with at most 2 decimals");
        expectError("T8", "192425301", "1e3", "number with at most 2 decimals");
        expectError("T9", "192425301", "-50", "number with at most 2 decimals");
        expectError("T10", "192425301", "0", "greater than zero");
        expectError("T11", "192425301", "10.999", "at most 2 decimals");
        expectError("T12", "192425301", "500000.01", "cannot exceed");
        expectError("T13", "1' OR '1'='1", "100", "9 to 12 digits");   // injection attempt never reaches SQL

        FeeService.Receipt edge = svc.pay("192425301", "500000");
        report("T14", "boundary Rs 500000 accepted", "Rs " + edge.amount(), edge.amount().compareTo(new BigDecimal("500000")) == 0);

        repo.failNext = true;
        try {
            svc.pay("192425301", "20");
            report("T15", "PaymentException when storage fails", "no exception", false);
        } catch (FeeService.PaymentException e) {
            report("T15", "PaymentException when storage fails", e.getMessage(), true);
        }
        int before = repo.rows().size();
        svc.pay("192425301", "20");
        report("T16", "retry after failure succeeds", "rows " + before + " -> " + repo.rows().size(),
                repo.rows().size() == before + 1);

        System.out.println("-".repeat(115));
        System.out.println(failures == 0 ? "ALL TESTS PASSED" : failures + " TEST(S) FAILED");
        if (failures != 0) System.exit(1);
    }
}
