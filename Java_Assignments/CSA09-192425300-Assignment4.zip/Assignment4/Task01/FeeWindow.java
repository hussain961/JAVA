import java.awt.BorderLayout;
import java.awt.Button;
import java.awt.Dialog;
import java.awt.EventQueue;
import java.awt.FlowLayout;
import java.awt.Frame;
import java.awt.GridLayout;
import java.awt.Label;
import java.awt.Panel;
import java.awt.TextField;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

/**
 * Task 1.2 - the repaired window. It ONLY collects input and shows results.
 * Validation and payment live in FeeService; storage lives in a repository.
 *
 * Fields are package-private (not private) only so the screenshot/test driver
 * in the same folder can read them.
 */
public class FeeWindow extends Frame {

    final TextField regNo = new TextField(14);
    final TextField amount = new TextField(10);
    final Button pay = new Button("Pay");
    final Button clear = new Button("Clear");
    final Button receipt = new Button("Receipt");
    final Label status = new Label("Enter register number and amount.");

    private final FeeService service;
    private FeeService.Receipt lastReceipt;

    public FeeWindow(FeeService service) {
        super("Student Fee Payment");
        this.service = service;

        Panel form = new Panel(new GridLayout(2, 2, 6, 6));
        form.add(new Label("Register No:"));
        form.add(regNo);
        form.add(new Label("Amount (Rs):"));
        form.add(amount);

        Panel buttons = new Panel(new FlowLayout());
        buttons.add(pay);
        buttons.add(clear);
        buttons.add(receipt);

        add(form, BorderLayout.NORTH);
        add(buttons, BorderLayout.CENTER);
        add(status, BorderLayout.SOUTH);
        receipt.setEnabled(false);               // nothing to show until a payment succeeds

        // One listener object per button - no if/else on the action command string.
        pay.addActionListener(e -> onPay());
        clear.addActionListener(e -> onClear());
        receipt.addActionListener(e -> onReceipt());

        // The window can now be closed.
        addWindowListener(new WindowAdapter() {
            @Override public void windowClosing(WindowEvent e) { dispose(); }
        });
        setSize(460, 190);
    }

    private void onPay() {                                  // runs on the EDT
        final FeeService.PaymentRequest request;
        try {
            request = service.validate(regNo.getText(), amount.getText());   // fast
        } catch (FeeService.ValidationException ex) {
            status.setText("Error: " + ex.getMessage());
            return;
        }
        pay.setEnabled(false);                              // prevent double submit
        status.setText("Processing payment...");
        new Thread(() -> {                                  // slow work OFF the EDT
            try {
                FeeService.Receipt r = service.pay(request);
                EventQueue.invokeLater(() -> paymentSucceeded(r));
            } catch (FeeService.PaymentException ex) {
                EventQueue.invokeLater(() -> paymentFailed(ex.getMessage()));
            }
        }, "payment-worker").start();
    }

    private void paymentSucceeded(FeeService.Receipt r) {   // back on the EDT
        lastReceipt = r;
        receipt.setEnabled(true);
        pay.setEnabled(true);
        status.setText("Payment successful. Receipt #" + r.receiptNo() + " (click Receipt for details)");
    }

    private void paymentFailed(String message) {
        pay.setEnabled(true);
        status.setText("Error: " + message);
    }

    private void onClear() {
        regNo.setText("");
        amount.setText("");
        status.setText("Cleared.");
        regNo.requestFocus();
    }

    private void onReceipt() {
        if (lastReceipt == null) return;
        showMessage("Receipt", lastReceipt.toString());
    }

    /** Small modal AWT dialog (AWT has no JOptionPane). */
    private void showMessage(String title, String text) {
        Dialog d = new Dialog(this, title, true);
        d.setLayout(new BorderLayout(10, 10));
        d.add(new Label(text, Label.CENTER), BorderLayout.CENTER);
        Button ok = new Button("OK");
        ok.addActionListener(e -> d.dispose());
        Panel p = new Panel();
        p.add(ok);
        d.add(p, BorderLayout.SOUTH);
        d.addWindowListener(new WindowAdapter() {
            @Override public void windowClosing(WindowEvent e) { d.dispose(); }
        });
        d.pack();
        d.setLocationRelativeTo(this);
        d.setVisible(true);
    }

    public static void main(String[] args) {
        FeeService.PaymentRepository repo = System.getProperty("db.url") != null
                ? new JdbcPaymentRepository(System.getProperty("db.url"),
                        System.getProperty("db.user"), System.getProperty("db.password"))
                : new InMemoryPaymentRepository(1500);      // simulated 1.5 s bank confirmation
        EventQueue.invokeLater(() -> new FeeWindow(new FeeService(repo)).setVisible(true));
    }
}
