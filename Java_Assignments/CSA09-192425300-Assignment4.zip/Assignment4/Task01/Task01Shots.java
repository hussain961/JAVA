import java.awt.EventQueue;
import java.awt.Rectangle;
import java.awt.Robot;
import java.awt.event.ActionEvent;
import java.awt.image.BufferedImage;
import java.io.File;
import javax.imageio.ImageIO;

/**
 * Evidence driver for Task 1. Needs a display (on a headless Linux box run it with xvfb-run).
 * It sets the text fields, fires real ActionEvents on the buttons, captures screenshots and
 * measures how long the event-dispatch thread is blocked while a payment is processed.
 * Usage: java Task01Shots <output-folder>
 */
public class Task01Shots {
    static FeeWindow w;
    static File out;

    static void shot(String name) throws Exception {
        Thread.sleep(250);
        Rectangle r = w.getBounds();
        BufferedImage img = new Robot().createScreenCapture(r);
        ImageIO.write(img, "png", new File(out, name));
        System.out.println("saved " + name);
    }

    static void ui(Runnable r) throws Exception { EventQueue.invokeAndWait(r); }

    static void click(java.awt.Button b) throws Exception {
        ui(() -> b.dispatchEvent(new ActionEvent(b, ActionEvent.ACTION_PERFORMED, b.getLabel())));
    }

    public static void main(String[] args) throws Exception {
        out = new File(args[0]);
        out.mkdirs();
        ui(() -> { w = new FeeWindow(new FeeService(new InMemoryPaymentRepository(1500))); w.setLocation(0, 0); w.setVisible(true); });
        Thread.sleep(500);

        // Scenario 1: invalid input (empty amount) -> clear message, nothing saved
        ui(() -> { w.regNo.setText("192425301"); w.amount.setText(""); });
        click(w.pay);
        shot("task01_1_invalid_amount.png");

        // Scenario 2: injection attempt in the register-number field
        ui(() -> { w.regNo.setText("1' OR '1'='1"); w.amount.setText("100"); });
        click(w.pay);
        shot("task01_2_injection_rejected.png");

        // Scenario 3: valid payment; window stays responsive during the 1.5 s bank wait
        ui(() -> { w.regNo.setText("192425301"); w.amount.setText("1500.50"); });
        click(w.pay);
        long maxGap = 0;
        long end = System.currentTimeMillis() + 1300;
        boolean shotTaken = false;
        while (System.currentTimeMillis() < end) {
            final long sent = System.nanoTime();
            final long[] got = {0};
            ui(() -> got[0] = System.nanoTime());          // round trip to the EDT
            maxGap = Math.max(maxGap, (got[0] - sent) / 1_000_000);
            if (!shotTaken) { shot("task01_3_processing.png"); shotTaken = true; }
            Thread.sleep(50);
        }
        System.out.println("Max EDT response delay while payment was processing: " + maxGap + " ms"
                + "  (original code would block ~3000 ms)");
        Thread.sleep(600);
        shot("task01_4_success.png");
        System.out.println("Receipt button enabled after success: " + w.receipt.isEnabled());

        // Scenario 4: Clear button
        click(w.clear);
        shot("task01_5_cleared.png");
        ui(() -> w.dispose());
    }
}
