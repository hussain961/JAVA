import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/** Two implementations of FeeService.PaymentRepository. */
class JdbcPaymentRepository implements FeeService.PaymentRepository {
    private final String url, user, password;

    JdbcPaymentRepository(String url, String user, String password) {
        this.url = url; this.user = user; this.password = password;
    }

    @Override
    public void save(String regNo, BigDecimal amount) throws FeeService.PaymentException {
        // PreparedStatement: values are bound, never concatenated -> no SQL injection.
        // try-with-resources: connection and statement are closed even if an exception occurs.
        String sql = "INSERT INTO fees(reg_no, amount) VALUES (?, ?)";
        try (Connection c = DriverManager.getConnection(url, user, password);
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, regNo);
            ps.setBigDecimal(2, amount);
            ps.executeUpdate();
        } catch (SQLException e) {
            throw new FeeService.PaymentException("Payment could not be saved. Please try again.", e);
        }
    }
}

class InMemoryPaymentRepository implements FeeService.PaymentRepository {
    private final List<String> rows = Collections.synchronizedList(new ArrayList<>());
    private final long delayMillis;
    volatile boolean failNext = false;

    /** @param delayMillis simulated bank/database latency (runs on the caller's thread) */
    InMemoryPaymentRepository(long delayMillis) { this.delayMillis = delayMillis; }

    @Override
    public void save(String regNo, BigDecimal amount) throws FeeService.PaymentException {
        try { Thread.sleep(delayMillis); } catch (InterruptedException e) { Thread.currentThread().interrupt(); }
        if (failNext) {
            failNext = false;
            throw new FeeService.PaymentException("Payment could not be saved. Please try again.",
                    new RuntimeException("simulated failure"));
        }
        rows.add(regNo + "," + amount.toPlainString());
    }

    List<String> rows() { return new ArrayList<>(rows); }
}
