import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.concurrent.atomic.AtomicLong;
import java.util.regex.Pattern;

/**
 * Business logic for the student fee-payment window (Task 1.2).
 *
 * Deliberately has NO java.awt / javax.swing imports: it can be unit-tested
 * without a screen, and the window can be replaced without touching it.
 */
public class FeeService {

    /** Storage abstraction: JDBC in production, in-memory in tests. */
    public interface PaymentRepository {
        void save(String regNo, BigDecimal amount) throws PaymentException;
    }

    /** Input rejected by validation - the message is safe to show to the user. */
    public static class ValidationException extends Exception {
        public ValidationException(String message) { super(message); }
    }

    /** Storage / bank failure - the user can retry. */
    public static class PaymentException extends Exception {
        public PaymentException(String message, Throwable cause) { super(message, cause); }
    }

    /** Already-validated input. Money is BigDecimal, never double. */
    public record PaymentRequest(String regNo, BigDecimal amount) { }

    public record Receipt(long receiptNo, String regNo, BigDecimal amount, LocalDateTime paidAt) {
        @Override public String toString() {
            return "Receipt #" + receiptNo + " | " + regNo + " | Rs " + amount.toPlainString()
                    + " | " + paidAt.withNano(0);
        }
    }

    private static final Pattern REG_NO = Pattern.compile("[0-9]{9,12}");
    private static final Pattern AMOUNT = Pattern.compile("[0-9]{1,7}(\\.[0-9]{1,2})?");
    public static final BigDecimal MAX_AMOUNT = new BigDecimal("500000");

    private final PaymentRepository repository;
    private final AtomicLong receiptCounter = new AtomicLong(1);

    public FeeService(PaymentRepository repository) {
        this.repository = repository;
    }

    /** Fast, no I/O - safe to call on the event-dispatch thread. */
    public PaymentRequest validate(String regNoText, String amountText) throws ValidationException {
        String reg = regNoText == null ? "" : regNoText.trim();
        String amt = amountText == null ? "" : amountText.trim();
        if (reg.isEmpty()) throw new ValidationException("Register number is required.");
        if (!REG_NO.matcher(reg).matches())
            throw new ValidationException("Register number must be 9 to 12 digits.");
        if (amt.isEmpty()) throw new ValidationException("Amount is required.");
        // Regex first: Double.parseDouble would also accept "NaN", "Infinity", "1e3", "5d".
        if (!AMOUNT.matcher(amt).matches())
            throw new ValidationException("Amount must be a number with at most 2 decimals.");
        BigDecimal value = new BigDecimal(amt);
        if (value.signum() <= 0) throw new ValidationException("Amount must be greater than zero.");
        if (value.compareTo(MAX_AMOUNT) > 0)
            throw new ValidationException("Amount cannot exceed Rs " + MAX_AMOUNT.toPlainString() + ".");
        return new PaymentRequest(reg, value);
    }

    /** Slow (I/O) - must be called from a background thread, never the EDT. */
    public Receipt pay(PaymentRequest request) throws PaymentException {
        repository.save(request.regNo(), request.amount());
        return new Receipt(receiptCounter.getAndIncrement(), request.regNo(),
                request.amount(), LocalDateTime.now());
    }

    /** Convenience for tests and console use. */
    public Receipt pay(String regNoText, String amountText) throws ValidationException, PaymentException {
        return pay(validate(regNoText, amountText));
    }
}
