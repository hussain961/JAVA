# Viva preparation – questions you should be able to answer about your own submission

You may be asked to explain a design, trace an event, or change a handler live. Open the code and practise these.

## Task 1
1. Why is `getActionCommand() == "Pay"` wrong? *(== compares references; use `equals` – or better, one listener per button.)*
2. Why must `Thread.sleep` / JDBC not run on the event-dispatch thread? What does the user see? *(the EDT paints and dispatches events; blocking it freezes the window.)*
3. Where in `FeeWindow.onPay()` does the code leave the EDT, and how does the result get back? *(`new Thread` … `EventQueue.invokeLater`.)*
4. Why `BigDecimal` for money, and why a regex before parsing the amount?
5. What does `PreparedStatement` prevent? Show the injection input from the report.

## Task 2
6. Name the listener interface and event class for a `Choice`, a `TextField`, a `Button`, and the window close button.
7. Which window-event methods run between opening and closing, and why can `windowActivated` / `windowOpened` come in either order?
8. How does `windowClosing` decide whether to ask for confirmation? *(the `bookingInProgress` flag.)*
9. Map the applet life cycle (init, start, paint, stop, destroy) to a Frame.

## Task 3
10. Why does `BorderLayout` give "results grow, rows keep size"? Why not `GridLayout`?
11. What does `FlowLayout` do with a component's size when the window is widened?
12. Which region in your frame grows, and how did you prove it? *(Task03Shots measures every region.)*

## Task 4
13. Why was `mouseclicked` never called? What would `@Override` have done? Show the compiler error.
14. Why do dots disappear after minimise/restore with `getGraphics()`? Who calls `paint()` and when?
15. What is the difference between `repaint()` and `paint()`?
16. When is a `BufferedImage` better than a list of points – and when worse? *(break-even about 300 dots here.)*

## Task 5
17. Show the four ways of attaching the handler. Which needed the biggest change when Enter + dialog was added, and why? *(anonymous class – it has no name to reuse.)*
18. In a lambda `this` means the frame; in an anonymous class it means the listener. Why does that matter?
19. What does one shared `Action` give you that four separate listeners do not? *(one place for text, enabled state and handler.)*

## Task 6
20. Draw the three layers and say which one is allowed to import `java.sql`. *(only `JdbcRegistrationDao`.)*
21. Why is a `SELECT` check before `INSERT` not enough to prevent duplicates? What does the `UNIQUE` key add? *(two users can both pass the check; the key is atomic. MySQL error 1062.)*
22. Walk through what happens, thread by thread, when the user presses Register. *(validate on EDT → `SwingWorker.doInBackground` → `done()` on EDT.)*
23. What is the `requestSeq` counter in `MainFrame` for? *(ignores answers to outdated requests.)*
24. Why `LIMIT ? OFFSET ?` and a separate `COUNT(*)`? What is the weakness of large `OFFSET` and what is the alternative? *(MySQL still skips the rows; keyset paging `WHERE id > ?`.)*
25. What did you measure, and what could you not measure? *(client-side time and memory, EDT stalls; database and network time were not measured.)*
