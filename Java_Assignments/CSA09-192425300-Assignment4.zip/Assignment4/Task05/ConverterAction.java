import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JTextField;
import javax.swing.KeyStroke;
import javax.swing.SwingUtilities;

/**
 * Alternative concept (Task 5): ONE shared Action object drives the button, a menu item,
 * the Enter key in the text field and a keyboard shortcut (Ctrl+Enter).
 * Adding another trigger is one line; the Action is the only listener object created.
 */
public class ConverterAction extends JFrame {
    final JTextField amount = new JTextField(10);
    final JComboBox<String> target = new JComboBox<>(new String[]{"USD", "EUR"});
    final JLabel result = new JLabel(" ");

    private final Action convertAction = new AbstractAction("Convert") {
        @Override public void actionPerformed(ActionEvent e) { convert(); }
    };

    private static double rate(String currency) { return currency.equals("USD") ? 0.012 : 0.011; }

    public ConverterAction() {
        super("Currency Converter (shared Action)");
        setLayout(new FlowLayout());
        JButton button = new JButton(convertAction);              // trigger 1: button (text comes from the Action)
        add(new JLabel("INR")); add(amount); add(target); add(button); add(result);

        amount.addActionListener(convertAction);                  // trigger 2: Enter key
        JMenuBar bar = new JMenuBar();                            // trigger 3: menu item
        JMenu menu = new JMenu("Actions");
        menu.add(new JMenuItem(convertAction));
        bar.add(menu);
        setJMenuBar(bar);
        getRootPane().getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW)   // trigger 4: Ctrl+Enter
                .put(KeyStroke.getKeyStroke(KeyEvent.VK_ENTER, KeyEvent.CTRL_DOWN_MASK), "convert");
        getRootPane().getActionMap().put("convert", convertAction);

        setDefaultCloseOperation(EXIT_ON_CLOSE);
        pack();
    }

    private void convert() {
        String text = amount.getText().trim();
        if (!text.matches("[0-9]+(\\.[0-9]+)?")) { result.setText("Invalid amount"); return; }
        String c = (String) target.getSelectedItem();
        result.setText(String.format(java.util.Locale.ROOT, "%.2f %s", Double.parseDouble(text) * rate(c), c));
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new ConverterAction().setVisible(true));
    }
}
