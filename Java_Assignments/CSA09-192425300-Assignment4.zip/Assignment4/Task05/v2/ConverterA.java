import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;

/** Task 5 - style A: the frame itself implements ActionListener  (5.2 changed requirement: Enter key + dialog box) */
public class ConverterA extends JFrame implements ActionListener {
    final JTextField amount = new JTextField(10);          // package-private: the test driver uses them
    final JComboBox<String> target = new JComboBox<>(new String[]{"USD", "EUR"});
    final JLabel result = new JLabel(" ");
    final JButton convertButton = new JButton("Convert");

    private static double rate(String currency) {
        return currency.equals("USD") ? 0.012 : 0.011;
    }

    public ConverterA() {
        super("Currency Converter");
        setLayout(new FlowLayout());
        add(new JLabel("INR")); add(amount); add(target);
        add(convertButton); add(result);
        convertButton.addActionListener(this);
        amount.addActionListener(this);
        setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
        addWindowListener(new WindowAdapter() {            // window closing handled by an adapter
            @Override public void windowClosing(WindowEvent e) { dispose(); }
        });
        pack();
    }

    @Override public void actionPerformed(ActionEvent e) { convert(); }

    private String compute() {
        String text = amount.getText().trim();
        if (!text.matches("[0-9]+(\\.[0-9]+)?")) return "Invalid amount";   // rejects "", "abc", "-5", "NaN", "1e3", "1d"
        String c = (String) target.getSelectedItem();
        return String.format(java.util.Locale.ROOT, "%.2f %s", Double.parseDouble(text) * rate(c), c);
    }

    private void convert() {
        result.setText(compute());
        JOptionPane.showMessageDialog(this, compute(), "Converted amount", JOptionPane.INFORMATION_MESSAGE);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new ConverterA().setVisible(true));
    }
}
