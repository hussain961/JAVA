import java.awt.EventQueue;
import java.awt.Rectangle;
import java.awt.Robot;
import java.awt.Window;
import java.awt.image.BufferedImage;
import java.io.File;
import java.lang.reflect.Field;
import javax.imageio.ImageIO;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

/**
 * Test + screenshot driver for Task 5. Works on ANY of the converter classes that is on the
 * classpath (Converter, ConverterA..D, ConverterAction) - the class name is the first argument.
 *   java Task05Test Converter  <screenshot-folder>      (the "Complete the Code" program)
 *   java Task05Test ConverterB                          (a style version)
 * Add the 3rd argument "enter" to also check the Enter key (+ dialog for the v2 versions).
 */
public class Task05Test {
    static int failures = 0;

    @SuppressWarnings("unchecked")
    static <T> T field(Object o, String name, Class<T> type) throws Exception {
        Field f = o.getClass().getDeclaredField(name);
        f.setAccessible(true);
        return type.cast(f.get(o));
    }

    static void ui(Runnable r) throws Exception { EventQueue.invokeAndWait(r); }

    static void check(String id, String expected, String actual) {
        boolean ok = expected.equals(actual);
        if (!ok) failures++;
        System.out.printf("%-4s | input -> expected %-16s | actual %-16s | %s%n", id, "\"" + expected + "\"", "\"" + actual + "\"", ok ? "PASS" : "FAIL");
    }

    static void shot(JFrame f, File dir, String name) throws Exception {
        if (dir == null) return;
        Thread.sleep(300);
        Rectangle r = f.getBounds();
        ImageIO.write(new Robot().createScreenCapture(r), "png", new File(dir, name));
    }

    public static void main(String[] args) throws Exception {
        String cls = args[0];
        File dir = args.length > 1 && !args[1].equals("-") ? new File(args[1]) : null;
        boolean enter = args.length > 2 && args[2].equals("enter");
        if (dir != null) dir.mkdirs();

        JFrame[] fr = new JFrame[1];
        ui(() -> {
            try { fr[0] = (JFrame) Class.forName(cls).getDeclaredConstructor().newInstance(); }
            catch (Exception e) { throw new RuntimeException(e); }
            fr[0].setLocation(0, 0);
            fr[0].setVisible(true);
        });
        Thread.sleep(500);
        JFrame f = fr[0];
        JTextField amount = field(f, "amount", JTextField.class);
        JLabel result = field(f, "result", JLabel.class);
        JComboBox<?> target = field(f, "target", JComboBox.class);
        JButton button = null;
        try { button = field(f, "convertButton", JButton.class); } catch (NoSuchFieldException ignored) { }
        final JButton btn = button;

        System.out.println("Testing " + cls);
        String[][] cases = {
            {"1000", "USD", "12.00 USD"}, {"1000", "EUR", "11.00 EUR"}, {"100.555", "USD", "1.21 USD"},
            {"0", "USD", "0.00 USD"}, {"abc", "USD", "Invalid amount"}, {"", "USD", "Invalid amount"},
            {"-5", "USD", "Invalid amount"}, {"NaN", "USD", "Invalid amount"}, {"1e3", "EUR", "Invalid amount"},
            {"12 34", "USD", "Invalid amount"}};
        int n = 1;
        for (String[] c : cases) {
            ui(() -> { amount.setText(c[0]); target.setSelectedItem(c[1]); result.setText(" "); });
            EventQueue.invokeLater(() -> { if (btn != null) btn.doClick(0); else amount.postActionEvent(); });
            dismissDialogs();
            String[] actual = new String[1];
            ui(() -> actual[0] = result.getText());
            check("C" + n++, c[2], actual[0]);
            if (c[0].equals("1000") && c[1].equals("USD")) shot(f, dir, "task05_" + cls + "_valid.png");
            if (c[0].equals("abc")) shot(f, dir, "task05_" + cls + "_invalid.png");
        }
        if (enter) {                                                   // Enter key in the amount field
            ui(() -> { amount.setText("500"); target.setSelectedItem("EUR"); result.setText(" "); });
            EventQueue.invokeLater(amount::postActionEvent);
            boolean dialogSeen = dismissDialogs();
            String[] actual = new String[1];
            ui(() -> actual[0] = result.getText());
            check("E1", "5.50 EUR", actual[0]);
            System.out.println("E2   | Enter key opened a result dialog: " + dialogSeen + "   (expected true only for v2 versions)");
        }
        ui(f::dispose);
        System.out.println(failures == 0 ? "ALL PASSED" : failures + " FAILED");
        if (failures != 0) System.exit(1);
        System.exit(0);                                                // Converter uses EXIT_ON_CLOSE anyway
    }

    /** A modal JOptionPane blocks the EDT; find it, photograph it, close it. */
    static final boolean EXPECT_DIALOG = Boolean.getBoolean("expect.dialog");   // true for the v2 versions

    static boolean dismissDialogs() throws Exception {
        boolean seen = false;
        for (int i = 0; i < (EXPECT_DIALOG ? 20 : 2); i++) {
            Thread.sleep(150);
            for (Window w : Window.getWindows()) {
                if (w instanceof JDialog && w.isShowing()) {
                    seen = true;
                    EventQueue.invokeAndWait(w::dispose);
                }
            }
            if (seen) break;
        }
        Thread.sleep(150);                                             // let the EDT finish the handler
        return seen;
    }
}
